# Plan 1: Rule-Based Logic + Structured ML Approach (Enhanced with Hereditary Risk)

This plan focuses on leveraging established clinical knowledge via rules combined with traditional machine learning models trained on structured patient data. **It now includes a quantitative Family History Score (FHS) to better assess hereditary risk.** It prioritizes interpretability and is often faster to implement for well-defined conditions.

**Focus:** Conditions with clear diagnostic criteria and risk factors identifiable in structured data, where family history is relevant (e.g., Diabetes[1], Hypertension[2], Hyperlipidemia, certain cancers).

**Workflow:**

1.  **Data Acquisition:** Focus on structured sources: Demographics, Diagnoses (ICD codes), Procedures (CPT codes), Medications (RxNorm), Lab Results (LOINC), Vitals. **Crucially, requires detailed Family History (Affected relatives, conditions, age of onset if possible).**
2.  **Preprocessing:** Standard steps (cleaning, normalization, standardization). Handle missing structured data. Encode categorical features.
3.  **Feature Engineering:**
    *   Calculate rolling averages, min/max, standard deviations for time-series data (vitals, labs).
    *   Create flags for presence/absence of key diagnoses, medications.
    *   Engineer domain-specific features (e.g., BMI, eGFR, pulse pressure).
    *   **NEW: Calculate Family History Score (FHS) per relevant condition:**
        *   *Define Rules:* E.g., for Diabetes FHS: +2 points per 1st-degree relative (parent, sibling, child) with T2DM; +1 point per 2nd-degree relative (grandparent, aunt/uncle) with T2DM. (Max score can be capped, e.g., at 5 or 6)[3].
        *   *E.g., for Hypertension FHS:* +2 points per 1st-degree relative with HTN onset <55yrs; +1 point per 2nd-degree relative with HTN onset <55yrs[4].
        *   Calculate the score based on the patient's reported family history.
4.  **Rule Engine Implementation:**
    *   Codify established clinical guidelines (e.g., ADA for diabetes[1], ACC/AHA for hypertension[2]).
    *   Define rules for identifying existing conditions, pre-conditions.
    *   *Optionally Add FHS-based rules:* `IF Diabetes_FHS >= 3 AND BMI >= 28 THEN Flag = 'HighHereditaryCombinedRisk_Diabetes'`
    *   *Example (Diabetes Status):* `IF (HbA1c >= 5.7 AND HbA1c < 6.5) OR (FastingGlucose >= 100 AND FastingGlucose < 126) THEN Status = 'Prediabetes'`[1]
    *   *Example (HTN Status):* `IF (AvgSystolicBP >= 130 AND AvgSystolicBP < 140) OR (AvgDiastolicBP >= 80 AND AvgDiastolicBP < 90) THEN Status = 'HTN Stage 1'`[2]
5.  **Machine Learning Model Development:**
    *   **Task:** Predict future risk probability (e.g., 5-year risk of T2DM[5], 5-year risk of HTN progression/event).
    *   **Models:** Logistic Regression, Random Forest, Gradient Boosting (XGBoost, LightGBM).
    *   **Features:** Include standard structured features **AND the calculated FHS scores** for relevant conditions.
    *   **Training:** Use historical data, temporal splitting.
    *   **Evaluation:** AUC-ROC, Precision-Recall, Calibration.
    *   **Output:** Risk probability (e.g., 0.35 = 35% risk).
6.  **Explainability:**
    *   **Rules:** Explanation is the rule itself.
    *   **ML Models:** Use SHAP or LIME to identify top contributing features, **including the FHS**. This shows *how much* family history contributes to the predicted risk alongside lifestyle/lab factors.
7.  **Recommendation Engine (Enhanced):**
    *   Map rule outputs, ML probability, **FHS level (e.g., Low/Med/High)**, and key contributing factors (from SHAP) to specific recommendations from a knowledge base (e.g., lifestyle changes based on DPP[5], DASH diet[6,7]).
    *   **Prioritize/Tailor based on FHS:** High FHS can increase urgency or intensity of recommendations (e.g., recommending earlier/more frequent screening).
    *   **Include Generational Advice:** Based on FHS and patient's status:
        *   *Patient Focus:* "Given your family history (FHS=X), these lifestyle changes are particularly important..."
        *   *Future Gen Focus:* "Consider discussing your family history and the importance of healthy habits/screening with your children/siblings."
        *   *Inform Relatives:* "If you are diagnosed with [condition], inform close relatives as they may also have increased risk."
8.  **Output Generation & UI:**
    *   Present clear risk summaries: Condition, **Risk Probability (%)**, Status (if applicable), Key Factors (including **FHS Score**).
    *   List prioritized, actionable recommendations, including tailored FHS-related advice.
    *   Simple HTML, CSS, JS frontend. Maybe simple bar chart showing contribution of factors (BMI, Labs, FHS, etc.) if using SHAP values.

**Updated Example Walkthroughs:**

**Patient 1: Enhanced Diabetes Risk**

*   **Input Features:** `Age=45`, `BMI=31`, **`Family Hx: Mother (T2DM), Maternal Grandfather (T2DM)`**, `AvgSystolicBP=135`, `AvgDiastolicBP=85`, `HbA1c=6.2`, `FastingGlucose=115`, `IsSedentary=1`.
*   **FHS Calculation:** `Diabetes_FHS` = 2 (Mother) + 1 (Grandfather) = **3**.
*   **Rule Engine Output:** `Status = 'Prediabetes'`. Potentially `Flag = 'HighHereditaryCombinedRisk_Diabetes'`.
*   **ML Model (T2DM 5yr Risk) Output:** `Probability = 0.35` (35% risk - FHS contributes).
*   **SHAP Explanation:** Top contributors: `HbA1c`, `FastingGlucose`, `BMI`, **`Diabetes_FHS`**.
*   **Recommendation Engine Output:** Diet change (Low GI), Exercise increase, PCP discussion, HbA1c monitoring. **PLUS:** "Your family history significantly increases your diabetes risk (FHS=3). Lifestyle changes are crucial to counteract this." and "Consider discussing healthy habits and potential screening with your children due to family history."
*   **Final UI Snippet:** "High Risk for Type 2 Diabetes (**35%** in 5 yrs). Key Factors: HbA1c (6.2), Glucose (115), BMI (31), **Family History Score (3)**. Recommendations: [List including tailored FHS advice]".

*   **Updated Mermaid Workflow (Patient 1 - Diabetes):**
    ```mermaid
    graph TD
        A[Start: P001 Structured Data + Family Hx] --> B{Preprocessing};
        B --> C{Feature Engineering};
        C -- Includes Vitals, Labs, BMI --> F{ML Model: T2DM 5yr Risk};
        C --> D{Calculate Family History Score (FHS)[3]};
        D -- Diabetes_FHS=3 --> F;
        B --> E{Rule Engine: Diabetes Checks[1]};
        E -- Prediabetes Status --> H{Recommendation Engine};
        F -- Risk Probability: 35% --> G{Explainability (SHAP)};
        G -- Key Factors: HbA1c, Glucose, BMI, FHS --> H;
        D -- FHS=3 --> H;
        H --> I[Generate Output: High Risk (35%), Recommendations + FHS Context[5]];
        I --> J[End: Display on UI];
    ```

**Patient 2: Enhanced Hypertension Risk**

*   **Input Features:** `Age=55`, `BMI=26`, **`Family Hx: Father (HTN @ 50), Paternal Uncle (HTN @ 52)`**, `AvgSystolicBP=138`, `AvgDiastolicBP=88`, `IsSmoker=0`, `HighSaltIntake=1`, `Creatinine=0.8`.
*   **FHS Calculation:** `Hypertension_FHS` = 2 (Father) + 1 (Uncle) = **3**[4].
*   **Rule Engine Output:** `Status = 'HTN Stage 1'`[2], `RiskFactor_Salt=True`.
*   **ML Model (HTN Progression 5yr Risk) Output:** `Probability = 0.24` (24% risk).
*   **SHAP Explanation:** Top contributors: `AvgSystolicBP`, `AvgDiastolicBP`, `Age`, **`Hypertension_FHS`**.
*   **Recommendation Engine Output:** DASH Diet/Sodium Reduction[6,7], BP Monitoring, PCP follow-up. **PLUS:** "Your family history (FHS=3) increases your HTN risk. Strict adherence to diet/monitoring is advised." and "Inform siblings/children about family HTN risk."
*   **Final UI Snippet:** "Elevated Hypertension Risk / Stage 1 (Current Avg BP 138/88, **24%** 5yr Progression Risk). Key Factors: BP Readings, Age, **Family History Score (3)**. Recommendations: [List including tailored FHS advice]".

*   **Updated Mermaid Workflow (Patient 2 - Hypertension):**
    ```mermaid
     graph TD
        A[Start: P002 Structured Data + Family Hx] --> B{Preprocessing};
        B --> C{Feature Engineering};
        C -- Includes Vitals, BMI etc --> F{ML Model: HTN Progression Risk};
        C --> D{Calculate Family History Score (FHS)[4]};
        D -- Hypertension_FHS=3 --> F;
        B --> E{Rule Engine: HTN Checks[2]};
        E -- HTN Stage 1 Status --> H{Recommendation Engine};
        F -- Risk Probability: 24% --> G{Explainability (SHAP)};
        G -- Key Factors: BP, Age, FHS --> H;
        D -- FHS=3 --> H;
        H --> I[Generate Output: Elevated Risk/Stage 1 (24%), Recommendations + FHS Context[6,7]];
        I --> J[End: Display on UI];
    ```

**Pros:**

*   **More Personalized:** Explicitly quantifies and utilizes hereditary risk.
*   **Improved Accuracy (Potentially):** FHS can be a strong predictor for many conditions.
*   **Actionable Generational Advice:** Provides relevant context for family members.
*   **Interpretability:** Still maintains good interpretability via rules and SHAP (showing FHS contribution).

**Cons:**

*   **Reliant on Accurate Family History:** Quality of input data is critical. Patients may not know or recall history accurately.
*   **Simplistic FHS:** The example FHS is basic. Real polygenic risk scores (PRS) require genetic data and are more complex but powerful.
*   **Rule Complexity:** Adding FHS to rules increases complexity.

**Verification & Validation:**

*   Similar to before, but specifically validate the impact of FHS. Does adding FHS significantly improve model performance (AUC, calibration)?
*   Clinical review should assess the appropriateness of the FHS calculation, the alignment with guidelines[1,2], and the resulting recommendations.

This enhanced Plan 1 provides a more nuanced and personalized risk assessment by integrating a quantitative measure of hereditary predisposition.

---

## References and Citations

1.  **American Diabetes Association.** Standards of Care in Diabetes—2025. *Diabetes Care* 2025;48(Supplement\_1):S1-S321. (Covers diagnosis criteria, prediabetes, prevention, risk factors, recommendations). Link: [https://diabetesjournals.org/care/issue/48/Supplement_1](https://diabetesjournals.org/care/issue/48/Supplement_1)
2.  **Whelton PK, Carey RM, Aronow WS, et al.** 2017 ACC/AHA/AAPA/ABC/ACPM/AGS/APhA/ASH/ASPC/NMA/PCNA Guideline for the Prevention, Detection, Evaluation, and Management of High Blood Pressure in Adults: A Report of the American College of Cardiology/American Heart Association Task Force on Clinical Practice Guidelines. *Hypertension*. 2018;71(6):e13-e115. (Covers HTN diagnosis, stages, risk factors, management). Link: [https://www.ahajournals.org/doi/10.1161/HYP.0000000000000065](https://www.ahajournals.org/doi/10.1161/HYP.0000000000000065)
3.  **Valdez R, Yoon PW, Qureshi N, Green RF, Khoury MJ.** Family history in public health practice: a genomic tool for disease prevention and control. *Annu Rev Public Health*. 2010;31:69-87. (General concept of using family history scoring for risk).
4.  **Ran T, Parati G.** Optimal blood pressure measurement for the diagnosis and management of hypertension: focus on the 2017 ACC/AHA guideline. *Curr Hypertens Rep*. 2018;20(9):72. (Discusses importance of family history in HTN).
5.  **Diabetes Prevention Program Research Group.** Reduction in the Incidence of Type 2 Diabetes with Lifestyle Intervention or Metformin. *N Engl J Med*. 2002;346(6):393-403. (Evidence for lifestyle intervention effectiveness in preventing T2DM). Link: [https://www.nejm.org/doi/full/10.1056/nejmoa012512](https://www.nejm.org/doi/full/10.1056/nejmoa012512)
6.  **Appel LJ, Moore TJ, Obarzanek E, et al.** A clinical trial of the effects of dietary patterns on blood pressure. DASH Collaborative Research Group. *N Engl J Med*. 1997;336(16):1117-1124. (Original DASH trial). Link: [https://www.nejm.org/doi/full/10.1056/nejm199704173361601](https://www.nejm.org/doi/full/10.1056/nejm199704173361601)
7.  **Challa HJ, Ameer MA, Uppaluri KR.** DASH Diet To Stop Hypertension. [Updated 2023 Jan 23]. In: StatPearls [Internet]. Treasure Island (FL): StatPearls Publishing; 2025 Jan-. Available from: [https://www.ncbi.nlm.nih.gov/books/NBK482514/](https://www.ncbi.nlm.nih.gov/books/NBK482514/) (Overview and effectiveness of DASH diet). 