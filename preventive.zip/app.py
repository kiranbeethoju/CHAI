from flask import Flask, render_template, request, jsonify
import json
import random

app = Flask(__name__)

# Sample patient data based on our examples
SAMPLE_PATIENTS = {
    "patient1": {
        "id": "P001",
        "name": "John Davis",
        "age": 45,
        "sex": "Male",
        "bmi": 31,
        "family_history": [
            {"relation": "Mother", "condition": "Type 2 Diabetes", "degree": 1},
            {"relation": "Maternal Grandfather", "condition": "Type 2 Diabetes", "degree": 2},
            {"relation": "Father", "condition": "Hypertension", "degree": 1},
            {"relation": "Sister", "condition": "Obesity", "degree": 1}
        ],
        "pmhx": [
            {"condition": "Gestational Diabetes", "year_diagnosed": 2018, "status": "Resolved"},
            {"condition": "Elevated Blood Pressure", "year_diagnosed": 2021, "status": "Active"},
            {"condition": "Hyperlipidemia", "year_diagnosed": 2020, "status": "Active"}
        ],
        "vitals": {
            "systolic_bp": 135,
            "diastolic_bp": 85
        },
        "labs": {
            "hba1c": 6.2,
            "fasting_glucose": 115,
            "total_cholesterol": 210,
            "hdl": 42,
            "ldl": 138,
            "triglycerides": 155
        },
        "lifestyle": {
            "is_sedentary": True,
            "smoking": False,
            "high_salt_intake": False
        }
    },
    "patient2": {
        "id": "P002",
        "name": "Sarah Johnson",
        "age": 55,
        "sex": "Female",
        "bmi": 26,
        "family_history": [
            {"relation": "Father", "condition": "Hypertension", "age_onset": 50, "degree": 1},
            {"relation": "Paternal Uncle", "condition": "Hypertension", "age_onset": 52, "degree": 2},
            {"relation": "Mother", "condition": "Breast Cancer", "age_onset": 65, "degree": 1},
            {"relation": "Maternal Aunt", "condition": "Type 2 Diabetes", "degree": 2}
        ],
        "pmhx": [
            {"condition": "Gestational Hypertension", "year_diagnosed": 2010, "status": "Resolved"},
            {"condition": "Migraines", "year_diagnosed": 2015, "status": "Active"},
            {"condition": "Osteoarthritis", "year_diagnosed": 2018, "status": "Active"}
        ],
        "vitals": {
            "systolic_bp": 138,
            "diastolic_bp": 88
        },
        "labs": {
            "creatinine": 0.8,
            "total_cholesterol": 195,
            "hdl": 48,
            "ldl": 125,
            "triglycerides": 120
        },
        "lifestyle": {
            "is_sedentary": False,
            "smoking": False,
            "high_salt_intake": True
        }
    }
}

# Calculate Family History Score (FHS)
def calculate_fhs(patient, condition):
    fhs = 0
    for relative in patient["family_history"]:
        if condition.lower() in relative["condition"].lower():
            # First-degree relatives (parents, siblings, children) get 2 points
            if relative["degree"] == 1:
                fhs += 2
            # Second-degree relatives (grandparents, aunts/uncles) get 1 point
            elif relative["degree"] == 2:
                fhs += 1
    return min(fhs, 5)  # Cap at 5 points

# PMHX Risk Score
def calculate_pmhx_risk_score(patient, condition_type):
    score = 0
    relevant_conditions = {
        "diabetes": ["diabetes", "gestational diabetes", "prediabetes", "insulin resistance"],
        "hypertension": ["hypertension", "elevated blood pressure", "gestational hypertension", "preeclampsia"]
    }
    
    target_conditions = relevant_conditions.get(condition_type.lower(), [])
    
    for history in patient.get("pmhx", []):
        condition = history["condition"].lower()
        for target in target_conditions:
            if target in condition:
                # Active conditions contribute more to risk
                if history["status"] == "Active":
                    score += 2
                else:
                    score += 1
                break
    
    return min(score, 3)  # Cap at 3 points

# Rule Engine for Diabetes
def evaluate_diabetes_status(patient):
    hba1c = patient["labs"].get("hba1c")
    fasting_glucose = patient["labs"].get("fasting_glucose")
    
    if hba1c is not None and hba1c >= 6.5:
        return "Diabetes"
    elif fasting_glucose is not None and fasting_glucose >= 126:
        return "Diabetes"
    elif (hba1c is not None and 5.7 <= hba1c < 6.5) or (fasting_glucose is not None and 100 <= fasting_glucose < 126):
        return "Prediabetes"
    else:
        return "Normal"

# Rule Engine for Hypertension
def evaluate_htn_status(patient):
    systolic = patient["vitals"]["systolic_bp"]
    diastolic = patient["vitals"]["diastolic_bp"]
    
    if systolic >= 140 or diastolic >= 90:
        return "HTN Stage 2"
    elif (systolic >= 130 and systolic < 140) or (diastolic >= 80 and diastolic < 90):
        return "HTN Stage 1"
    elif (systolic >= 120 and systolic < 130) and diastolic < 80:
        return "Elevated"
    else:
        return "Normal"

# ML Model Simulation for Diabetes Risk
def predict_diabetes_risk(patient):
    # In a real system, this would be a trained ML model
    # Here we simulate based on key risk factors
    
    risk_factors = {
        "hba1c": 0.15,  # Coefficient weights
        "fasting_glucose": 0.12,
        "bmi": 0.10,
        "fhs": 0.08,
        "pmhx": 0.07,  # Previous medical history now included
        "age": 0.05,
        "is_sedentary": 0.05
    }
    
    # Base risk
    risk = 0.05
    
    # Add weighted factors
    if patient["labs"].get("hba1c") is not None:
        risk += risk_factors["hba1c"] * (patient["labs"]["hba1c"] - 5.0) / 1.5
    
    if patient["labs"].get("fasting_glucose") is not None:
        risk += risk_factors["fasting_glucose"] * (patient["labs"]["fasting_glucose"] - 90) / 30
    
    risk += risk_factors["bmi"] * (patient["bmi"] - 25) / 5
    
    fhs = calculate_fhs(patient, "diabetes")
    risk += risk_factors["fhs"] * fhs / 3
    
    # Add PMHX factor
    pmhx_score = calculate_pmhx_risk_score(patient, "diabetes")
    risk += risk_factors["pmhx"] * pmhx_score / 2
    
    risk += risk_factors["age"] * (patient["age"] - 40) / 20
    
    if patient["lifestyle"]["is_sedentary"]:
        risk += risk_factors["is_sedentary"]
    
    # Clamp to a reasonable range
    risk = max(0.05, min(0.80, risk))
    
    # Key factors contributing to risk
    factors = []
    if patient["labs"].get("hba1c", 0) >= 5.7:
        factors.append(f"HbA1c ({patient['labs']['hba1c']}%)")
    if patient["labs"].get("fasting_glucose", 0) >= 100:
        factors.append(f"Fasting Glucose ({patient['labs']['fasting_glucose']} mg/dL)")
    if patient["bmi"] >= 25:
        factors.append(f"BMI ({patient['bmi']} kg/m²)")
    if fhs >= 2:
        factors.append(f"Family History Score ({fhs})")
    if pmhx_score >= 1:
        factors.append(f"Previous Medical History ({pmhx_score}/3)")
    if patient["lifestyle"]["is_sedentary"]:
        factors.append("Sedentary Lifestyle")
    
    # Create risk breakdown for visualization
    risk_breakdown = {
        "lab_values": min(35, (patient["labs"].get("hba1c", 5.7) - 5.0) / 2.0 * 100),
        "family_history": min(30, fhs * 6),
        "pmhx": min(25, pmhx_score * 8),
        "lifestyle": min(20, (10 if patient["lifestyle"]["is_sedentary"] else 0)),
        "demographics": min(15, (patient["bmi"] - 25) / 10 * 100 if patient["bmi"] > 25 else 0)
    }
    
    return {
        "risk_probability": risk,
        "factors": factors,
        "risk_breakdown": risk_breakdown
    }

# ML Model Simulation for Hypertension Risk
def predict_htn_risk(patient):
    # Simulated HTN risk prediction
    
    risk_factors = {
        "systolic_bp": 0.15,
        "diastolic_bp": 0.12,
        "age": 0.08,
        "fhs": 0.07,
        "pmhx": 0.06,  # Previous medical history now included
        "high_salt_intake": 0.05
    }
    
    # Base risk
    risk = 0.05
    
    # Add weighted factors
    risk += risk_factors["systolic_bp"] * (patient["vitals"]["systolic_bp"] - 120) / 20
    risk += risk_factors["diastolic_bp"] * (patient["vitals"]["diastolic_bp"] - 80) / 10
    risk += risk_factors["age"] * (patient["age"] - 40) / 20
    
    fhs = calculate_fhs(patient, "hypertension")
    risk += risk_factors["fhs"] * fhs / 3
    
    # Add PMHX factor
    pmhx_score = calculate_pmhx_risk_score(patient, "hypertension")
    risk += risk_factors["pmhx"] * pmhx_score / 2
    
    if patient["lifestyle"]["high_salt_intake"]:
        risk += risk_factors["high_salt_intake"]
    
    # Clamp to a reasonable range
    risk = max(0.05, min(0.80, risk))
    
    # Key factors contributing to risk
    factors = []
    if patient["vitals"]["systolic_bp"] >= 120:
        factors.append(f"Systolic BP ({patient['vitals']['systolic_bp']} mmHg)")
    if patient["vitals"]["diastolic_bp"] >= 80:
        factors.append(f"Diastolic BP ({patient['vitals']['diastolic_bp']} mmHg)")
    if patient["age"] >= 45:
        factors.append(f"Age ({patient['age']} years)")
    if fhs >= 2:
        factors.append(f"Family History Score ({fhs})")
    if pmhx_score >= 1:
        factors.append(f"Previous Medical History ({pmhx_score}/3)")
    if patient["lifestyle"]["high_salt_intake"]:
        factors.append("High Salt Intake")
    
    # Create risk breakdown for visualization
    risk_breakdown = {
        "bp_values": min(40, ((patient["vitals"]["systolic_bp"] - 120) / 20 + (patient["vitals"]["diastolic_bp"] - 80) / 10) * 100),
        "family_history": min(30, fhs * 6),
        "pmhx": min(25, pmhx_score * 8),
        "lifestyle": min(20, (15 if patient["lifestyle"]["high_salt_intake"] else 0)),
        "demographics": min(15, (patient["age"] - 40) / 40 * 100 if patient["age"] > 40 else 0)
    }
    
    return {
        "risk_probability": risk,
        "factors": factors,
        "risk_breakdown": risk_breakdown
    }

# Generate Recommendations
def generate_recommendations(patient, diabetes_status, diabetes_risk, htn_status, htn_risk):
    recommendations = []
    
    # Diabetes recommendations
    if diabetes_status == "Prediabetes" or diabetes_risk["risk_probability"] >= 0.20:
        fhs = calculate_fhs(patient, "diabetes")
        pmhx_score = calculate_pmhx_risk_score(patient, "diabetes")
        recommendations.append({
            "condition": "Diabetes",
            "priority": 1,
            "text": "Adopt a balanced diet with reduced refined carbohydrates and increased fiber intake.",
            "rationale": "Dietary changes can significantly reduce diabetes risk in prediabetic individuals [ADA Standards of Care 2025]."
        })
        
        recommendations.append({
            "condition": "Diabetes",
            "priority": 2,
            "text": "Aim for at least 150 minutes of moderate-intensity physical activity per week.",
            "rationale": "Regular physical activity improves insulin sensitivity and reduces diabetes risk [Diabetes Prevention Program]."
        })
        
        if fhs >= 3:
            recommendations.append({
                "condition": "Diabetes",
                "priority": 3,
                "text": f"Given your family history score of {fhs}, consider discussing diabetes risk with your first-degree relatives.",
                "rationale": "Family history is a significant risk factor. Family members may benefit from early screening [ADA Standards of Care 2025]."
            })
        
        if pmhx_score >= 2:
            recommendations.append({
                "condition": "Diabetes",
                "priority": 2,
                "text": f"With your medical history, get HbA1c tested every 6 months instead of annually.",
                "rationale": "Previous conditions like gestational diabetes increase risk and require more frequent monitoring [ADA Guidelines]."
            })
    
    # Hypertension recommendations
    if htn_status in ["HTN Stage 1", "HTN Stage 2"] or htn_risk["risk_probability"] >= 0.20:
        fhs = calculate_fhs(patient, "hypertension")
        pmhx_score = calculate_pmhx_risk_score(patient, "hypertension")
        recommendations.append({
            "condition": "Hypertension",
            "priority": 1,
            "text": "Follow the DASH (Dietary Approaches to Stop Hypertension) diet with reduced sodium intake.",
            "rationale": "The DASH diet has been proven to reduce blood pressure by 8-14 mmHg systolic [Appel et al., NEJM 1997]."
        })
        
        recommendations.append({
            "condition": "Hypertension",
            "priority": 2,
            "text": "Regular blood pressure monitoring at home, with a goal of <130/80 mmHg.",
            "rationale": "Home BP monitoring improves blood pressure control [ACC/AHA Hypertension Guidelines]."
        })
        
        if fhs >= 3:
            recommendations.append({
                "condition": "Hypertension",
                "priority": 3,
                "text": f"With your family history score of {fhs}, inform siblings and children about potential increased hypertension risk.",
                "rationale": "Early awareness can lead to preventive measures in family members [ACC/AHA Guidelines]."
            })
            
        if pmhx_score >= 2:
            recommendations.append({
                "condition": "Hypertension", 
                "priority": 2,
                "text": f"Based on your medical history, consider stress management techniques like meditation.",
                "rationale": "Prior hypertensive episodes increase future risk. Stress reduction has been shown to lower blood pressure [JNC 8]."
            })
    
    # General recommendations
    if patient["bmi"] >= 25:
        recommendations.append({
            "condition": "General",
            "priority": 1,
            "text": f"Work toward a 5-10% weight reduction through combined diet and exercise.",
            "rationale": "Even modest weight loss improves metabolic health and reduces cardiovascular risk [DPP Research Group]."
        })
    
    return recommendations

@app.route('/')
def home():
    return render_template('index.html', patients=SAMPLE_PATIENTS)

@app.route('/analyze/<patient_id>')
def analyze(patient_id):
    if patient_id not in SAMPLE_PATIENTS:
        return jsonify({"error": "Patient not found"}), 404
    
    patient = SAMPLE_PATIENTS[patient_id]
    
    # Calculate FHS scores
    diabetes_fhs = calculate_fhs(patient, "diabetes")
    htn_fhs = calculate_fhs(patient, "hypertension")
    
    # Calculate PMHX scores
    diabetes_pmhx = calculate_pmhx_risk_score(patient, "diabetes")
    htn_pmhx = calculate_pmhx_risk_score(patient, "hypertension")
    
    # Evaluate current status
    diabetes_status = evaluate_diabetes_status(patient)
    htn_status = evaluate_htn_status(patient)
    
    # Predict risks
    diabetes_risk = predict_diabetes_risk(patient)
    htn_risk = predict_htn_risk(patient)
    
    # Generate recommendations
    recommendations = generate_recommendations(
        patient, 
        diabetes_status, 
        diabetes_risk,
        htn_status,
        htn_risk
    )
    
    analysis = {
        "patient": patient,
        "diabetes": {
            "fhs": diabetes_fhs,
            "pmhx_score": diabetes_pmhx,
            "status": diabetes_status,
            "risk_probability": diabetes_risk["risk_probability"],
            "factors": diabetes_risk["factors"],
            "risk_breakdown": diabetes_risk["risk_breakdown"]
        },
        "hypertension": {
            "fhs": htn_fhs,
            "pmhx_score": htn_pmhx,
            "status": htn_status,
            "risk_probability": htn_risk["risk_probability"],
            "factors": htn_risk["factors"],
            "risk_breakdown": htn_risk["risk_breakdown"]
        },
        "recommendations": recommendations
    }
    
    return render_template('analysis.html', analysis=analysis)

if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0',port=5001)