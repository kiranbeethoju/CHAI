import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class BaseAgent:
    def __init__(self):
        api_key = os.getenv('OPENAI_API_KEY', 'MnkQNNp6hECvauZrUPUMdBPJLKfdddwt')
        self.client = OpenAI(
            api_key=api_key,
            base_url="https://api.deepinfra.com/v1/openai"
        )
        
    def get_completion(self, prompt):
        try:
            response = self.client.chat.completions.create(
                messages=[{
                    "role": "user",
                    "content": prompt
                }],
                model="meta-llama/Llama-3.3-70B-Instruct-Turbo"
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"API Error: {str(e)}")  # For debugging
            return f"Error communicating with the API: {str(e)}"
            
    def get_streaming_completion(self, prompt):
        try:
            response = self.client.chat.completions.create(
                messages=[{
                    "role": "user",
                    "content": prompt
                }],
                model="meta-llama/Llama-3.3-70B-Instruct-Turbo",
                stream=True
            )
            for chunk in response:
                if chunk.choices[0].delta.content is not None:
                    yield chunk.choices[0].delta.content
        except Exception as e:
            print(f"API Error: {str(e)}")
            yield f"Error communicating with the API: {str(e)}"

class Agent:
    def __init__(self):
        self._complete_response = ""
    
    def get_complete_response(self):
        return self._complete_response

class QuantitativeAgent(Agent):
    def __init__(self):
        super().__init__()
        self.base_agent = BaseAgent()
    
    def analyze(self, prompt):
        """Regular non-streaming analysis"""
        response = self.base_agent.get_completion(prompt)
        self._complete_response = response
        return response
    
    def analyze_stream(self, prompt):
        """Streaming analysis that yields chunks of text"""
        for chunk in self.base_agent.get_streaming_completion(prompt):
            self._complete_response += chunk
            yield chunk

class QualitativeAgent(Agent):
    def __init__(self):
        super().__init__()
        self.base_agent = BaseAgent()
    
    def analyze(self, prompt):
        """Regular non-streaming analysis"""
        response = self.base_agent.get_completion(prompt)
        self._complete_response = response
        return response
    
    def analyze_stream(self, prompt):
        """Streaming analysis that yields chunks of text"""
        for chunk in self.base_agent.get_streaming_completion(prompt):
            self._complete_response += chunk
            yield chunk

class MediatorAgent(Agent):
    def __init__(self):
        super().__init__()
        self.base_agent = BaseAgent()
    
    def get_consensus(self, quant_analysis, qual_analysis):
        """Generate consensus from both analyses using LLM"""
        prompt = f"""
        Based on the following quantitative and qualitative analyses, generate a detailed consensus that breaks down the implementation into specific tasks.

        Quantitative Analysis:
        {quant_analysis}

        Qualitative Analysis:
        {qual_analysis}

        Please provide a structured consensus with tasks in the following format:

        Title: [Task Title]
        Description: [Detailed description of what needs to be done]
        Hours: [Estimated hours as a number]
        Role: [Required role - Developer/Designer/QA/DevOps]
        Priority: [high/medium/low]

        Important Guidelines:
        1. Break down into specific, actionable tasks
        2. Provide realistic hour estimates
        3. Assign appropriate roles based on task nature
        4. Set priority based on dependencies and impact
        5. Include all necessary implementation details
        6. Consider both technical and non-technical aspects
        7. Account for testing and documentation
        8. Add buffer time for complexity

        Format each task clearly with a blank line between tasks.
        """
        
        try:
            response = self.base_agent.get_completion(prompt)
            self._complete_response = response
            return response
        except Exception as e:
            print(f"Error in consensus generation: {str(e)}")
            return "Error: Failed to generate consensus. Please try again."

    def analyze_stream(self, prompt):
        """Support streaming for consensus generation"""
        for chunk in self.base_agent.get_streaming_completion(prompt):
            self._complete_response += chunk
            yield chunk 