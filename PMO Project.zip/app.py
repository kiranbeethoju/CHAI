from flask import Flask, render_template, request, jsonify, Response, stream_with_context
from flask_migrate import Migrate
from flask_cors import CORS
from models import db, ProjectMemory, UserRequirement, Staff, Ticket
from agents import QuantitativeAgent, QualitativeAgent, MediatorAgent
from datetime import datetime, timedelta
from db_utils import backup_database, restore_database
from werkzeug.exceptions import RequestTimeout
from difflib import SequenceMatcher
from similarity_checker import SimilarityChecker
import json

app = Flask(__name__)
CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///project_memory.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
migrate = Migrate(app, db)  # Initialize Flask-Migrate

# Initialize similarity checker
similarity_checker = SimilarityChecker()

def similar(a, b):
    """Calculate text similarity ratio between two strings"""
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()

@app.route('/')
def index():
    memories = ProjectMemory.query.filter_by(is_active=True)\
        .order_by(ProjectMemory.created_at.desc())\
        .all()
    memory_count = ProjectMemory.query.filter_by(is_active=True).count()
    requirements = UserRequirement.query.order_by(UserRequirement.created_at.desc()).all()
    staff = Staff.query.filter_by(is_active=True).all()
    return render_template('index.html', 
                         memories=memories, 
                         memory_count=memory_count,
                         requirements=requirements,
                         staff=staff)

@app.route('/memory', methods=['POST'])
def add_memory():
    data = request.json
    content = data['content']
    memory_type = data['type']
    
    # Check for duplicate content
    existing_memory = ProjectMemory.query.filter_by(
        content=content,
        type=memory_type,
        is_active=True
    ).first()
    
    if existing_memory:
        return jsonify({
            'error': 'This content already exists in the project memory'
        }), 409  # HTTP 409 Conflict
    
    memory = ProjectMemory(
        content=content,
        type=memory_type,
        created_at=datetime.utcnow()
    )
    db.session.add(memory)
    db.session.commit()
    
    return jsonify({
        'id': memory.id,
        'timestamp': memory.created_at.strftime('%Y-%m-%d %H:%M:%S')
    })

@app.route('/memory/<int:id>', methods=['DELETE'])
def delete_memory(id):
    memory = ProjectMemory.query.get_or_404(id)
    memory.is_active = False
    db.session.commit()
    return jsonify({'success': True})

@app.route('/staff', methods=['POST'])
def add_staff():
    data = request.json
    name = data['name'].strip()  # Remove leading/trailing whitespace
    role = data['role'].strip()  # Remove leading/trailing whitespace
    
    if not name or not role:
        return jsonify({
            'error': 'Name and role are required'
        }), 400
    
    # Case-insensitive check for existing staff
    existing_staff = Staff.query.filter(
        db.func.lower(Staff.name) == db.func.lower(name),
        db.func.lower(Staff.role) == db.func.lower(role),
        Staff.is_active == True
    ).first()
    
    if existing_staff:
        return jsonify({
            'error': 'Staff member with this name and role already exists'
        }), 409
    
    staff = Staff(
        name=name.title(),  # Normalize name capitalization
        role=role.title()   # Normalize role capitalization
    )
    db.session.add(staff)
    db.session.commit()
    
    return jsonify({
        'id': staff.id,
        'name': staff.name,
        'role': staff.role
    })

@app.route('/staff/<int:id>', methods=['DELETE'])
def delete_staff(id):
    staff = Staff.query.get_or_404(id)
    staff.is_active = False
    db.session.commit()
    return jsonify({'success': True})

@app.route('/tickets', methods=['GET'])
def get_tickets():
    tickets = Ticket.query.order_by(Ticket.created_at.desc()).all()
    return jsonify([{
        'id': t.id,
        'title': t.title,
        'description': t.description,
        'status': t.status,
        'priority': t.priority,
        'estimated_hours': t.estimated_hours,
        'buffer_hours': t.buffer_hours,
        'assignee': t.assignee.name if t.assignee else None,
        'start_date': t.start_date.isoformat() if t.start_date else None,
        'due_date': t.due_date.isoformat() if t.due_date else None,
        'created_at': t.created_at.isoformat()
    } for t in tickets])

@app.route('/tickets/<int:id>', methods=['PUT'])
def update_ticket(id):
    ticket = Ticket.query.get_or_404(id)
    data = request.json
    
    if 'status' in data:
        ticket.status = data['status']
    if 'estimated_hours' in data:
        ticket.estimated_hours = data['estimated_hours']
    if 'buffer_hours' in data:
        ticket.buffer_hours = data['buffer_hours']
    if 'assignee_id' in data:
        ticket.assignee_id = data['assignee_id']
    if 'start_date' in data:
        ticket.start_date = datetime.fromisoformat(data['start_date'])
    if 'due_date' in data:
        ticket.due_date = datetime.fromisoformat(data['due_date'])
    
    db.session.commit()
    return jsonify({'success': True})

@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.get_json()
    problem = data.get('problem', '')
    force_analysis = request.headers.get('X-Force-Analysis', '').lower() == 'true'

    def generate():
        if not force_analysis:
            # Check for similar requirements using LLM
            existing_requirements = UserRequirement.query.order_by(UserRequirement.created_at.desc()).all()
            
            for req in existing_requirements:
                similarity_score, explanation = similarity_checker.check_similarity(req.content, problem)
                if similarity_score > 0.85:  # 85% semantic similarity threshold
                    yield json.dumps({
                        'type': 'duplicate',
                        'is_duplicate': True,
                        'similarity': f'{similarity_score:.1%}',
                        'similar_requirement': req.content,
                        'explanation': explanation,
                        'consensus': req.content,
                        'created_at': req.created_at.strftime('%Y-%m-%d %H:%M:%S')
                    }) + '\n'
                    return

        # Proceed with analysis
        try:
            # Create requirement entry
            requirement = UserRequirement(content=problem)
            db.session.add(requirement)
            db.session.commit()

            # Get active staff for prompt
            staff = Staff.query.filter_by(is_active=True).all()
            staff_text = "\n".join([f"- {s.name} ({s.role})" for s in staff])
            
            # Get context memories
            context = ProjectMemory.query.filter_by(
                is_active=True, 
                type='context'
            ).order_by(ProjectMemory.created_at.desc()).all()
            
            context_text = "\n".join([m.content for m in context])
            
            full_prompt = f"""
            Project Context:
            {context_text}
            
            Available Staff:
            {staff_text}
            
            New Feature Request:
            {problem}
            
            Please analyze this requirement considering:
            1. Task breakdown and estimation
            2. Resource allocation
            3. Technical feasibility
            4. Implementation approach
            5. Risk assessment
            6. Best practices
            """
            
            # Stream quantitative analysis
            yield json.dumps({
                'type': 'status',
                'message': 'Starting quantitative analysis...'
            }) + '\n'
            
            quant_agent = QuantitativeAgent()
            for chunk in quant_agent.analyze_stream(full_prompt):
                yield json.dumps({
                    'type': 'quantitative',
                    'content': chunk
                }) + '\n'
            
            # Stream qualitative analysis
            yield json.dumps({
                'type': 'status',
                'message': 'Starting qualitative analysis...'
            }) + '\n'
            
            qual_agent = QualitativeAgent()
            for chunk in qual_agent.analyze_stream(full_prompt):
                yield json.dumps({
                    'type': 'qualitative',
                    'content': chunk
                }) + '\n'
            
            # Generate consensus
            yield json.dumps({
                'type': 'status',
                'message': 'Generating consensus and creating tickets...'
            }) + '\n'
            
            mediator = MediatorAgent()
            consensus = mediator.get_consensus(
                quant_agent.get_complete_response(),
                qual_agent.get_complete_response()
            )
            
            yield json.dumps({
                'type': 'consensus',
                'content': consensus
            }) + '\n'
            
            # Create tickets from consensus
            tickets_created = []
            current_ticket = {}
            
            for line in consensus.split('\n'):
                line = line.strip()
                if not line:
                    if current_ticket and all(k in current_ticket for k in ['title', 'description', 'hours', 'role']):
                        ticket = create_ticket(current_ticket, staff)
                        if ticket:
                            tickets_created.append(ticket)
                    current_ticket = {}
                elif line.startswith('Title:'):
                    if current_ticket and all(k in current_ticket for k in ['title', 'description', 'hours', 'role']):
                        ticket = create_ticket(current_ticket, staff)
                        if ticket:
                            tickets_created.append(ticket)
                    current_ticket = {'title': line[6:].strip()}
                elif line.startswith('Description:'):
                    current_ticket['description'] = line[12:].strip()
                elif line.startswith('Hours:'):
                    try:
                        hours = float(line[6:].strip())
                        current_ticket['hours'] = hours
                        current_ticket['estimated_hours'] = hours
                        current_ticket['buffer_hours'] = hours * 0.2  # 20% buffer
                    except ValueError:
                        pass
                elif line.startswith('Role:'):
                    current_ticket['role'] = line[5:].strip()
                elif line.startswith('Priority:'):
                    current_ticket['priority'] = line[9:].strip().lower()
            
            # Create the last ticket if exists
            if current_ticket and all(k in current_ticket for k in ['title', 'description', 'hours', 'role']):
                ticket = create_ticket(current_ticket, staff)
                if ticket:
                    tickets_created.append(ticket)
            
            # Send completion status
            yield json.dumps({
                'type': 'status',
                'message': f'Analysis complete. Created {len(tickets_created)} tickets.'
            }) + '\n'
            
            yield json.dumps({
                'type': 'complete'
            }) + '\n'

        except Exception as e:
            # Clean up on error
            if 'requirement' in locals():
                db.session.delete(requirement)
                db.session.commit()
            
            yield json.dumps({
                'type': 'error',
                'message': str(e)
            }) + '\n'

    return Response(stream_with_context(generate()), mimetype='application/x-ndjson')

def create_ticket(ticket_data, available_staff):
    """Helper function to create a ticket with appropriate assignee"""
    if not all(k in ticket_data for k in ['title', 'description', 'estimated_hours', 'role']):
        return None
        
    # Find appropriate staff member for the role
    assignee = None
    for staff in available_staff:
        if staff.role.lower() == ticket_data['role'].lower():
            assignee = staff
            break
            
    # Calculate dates
    start_date = datetime.utcnow()
    total_hours = ticket_data['estimated_hours'] + ticket_data.get('buffer_hours', 0)
    due_date = start_date + timedelta(hours=total_hours)
    
    ticket = Ticket(
        title=ticket_data['title'],
        description=ticket_data['description'],
        estimated_hours=ticket_data['estimated_hours'],
        buffer_hours=ticket_data.get('buffer_hours', 0),
        priority=ticket_data.get('priority', 'medium'),
        assignee=assignee,
        start_date=start_date,
        due_date=due_date
    )
    
    db.session.add(ticket)
    db.session.commit()
    return ticket

@app.route('/backup', methods=['POST'])
def backup():
    backup_database()
    return jsonify({'success': True})

@app.route('/requirements', methods=['GET'])
def get_requirements():
    requirements = UserRequirement.query.order_by(UserRequirement.created_at.desc()).all()
    return jsonify([{
        'id': req.id,
        'content': req.content,
        'created_at': req.created_at.isoformat()
    } for req in requirements])

@app.route('/requirements/<int:id>', methods=['GET'])
def get_requirement(id):
    requirement = UserRequirement.query.get_or_404(id)
    return jsonify({
        'id': requirement.id,
        'content': requirement.content,
        'created_at': requirement.created_at.isoformat()
    })

@app.route('/requirements/<int:id>', methods=['PUT'])
def update_requirement(id):
    requirement = UserRequirement.query.get_or_404(id)
    data = request.json
    
    if 'content' in data:
        requirement.content = data['content']
        db.session.commit()
        
    return jsonify({
        'id': requirement.id,
        'content': requirement.content,
        'created_at': requirement.created_at.isoformat()
    })

@app.route('/requirements/<int:id>', methods=['DELETE'])
def delete_requirement(id):
    requirement = UserRequirement.query.get_or_404(id)
    db.session.delete(requirement)
    db.session.commit()
    return jsonify({'success': True})

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        # restore_database()  # Comment out automatic restore
    app.run(debug=True, host='0.0.0.0', port=15000)

# Add signal handler for graceful shutdown
import atexit
@atexit.register
def backup_on_shutdown():
    with app.app_context():
        backup_database() 