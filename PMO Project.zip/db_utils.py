import os
import json
from datetime import datetime
from models import db, Staff, ProjectMemory, UserRequirement

def backup_database():
    """Backup database to JSON file"""
    data = {
        'staff': [],
        'project_memory': [],
        'user_requirements': []
    }
    
    # Backup Staff
    for staff in Staff.query.all():
        data['staff'].append({
            'name': staff.name,
            'role': staff.role,
            'is_active': staff.is_active,
            'created_at': staff.created_at.isoformat()
        })
    
    # Backup ProjectMemory
    for memory in ProjectMemory.query.all():
        data['project_memory'].append({
            'content': memory.content,
            'type': memory.type,
            'is_active': memory.is_active,
            'created_at': memory.created_at.isoformat()
        })
    
    # Backup UserRequirement
    for req in UserRequirement.query.all():
        data['user_requirements'].append({
            'content': req.content,
            'created_at': req.created_at.isoformat()
        })
    
    # Save to file
    with open('db_backup.json', 'w') as f:
        json.dump(data, f, indent=2)

def restore_database():
    """Restore database from JSON file"""
    if not os.path.exists('db_backup.json'):
        return
    
    with open('db_backup.json', 'r') as f:
        data = json.load(f)
    
    # Clear existing data
    Staff.query.delete()
    ProjectMemory.query.delete()
    UserRequirement.query.delete()
    db.session.commit()
    
    # Restore Staff
    for staff_data in data.get('staff', []):
        staff = Staff(
            name=staff_data['name'],
            role=staff_data['role'],
            is_active=staff_data['is_active'],
            created_at=datetime.fromisoformat(staff_data['created_at'])
        )
        db.session.add(staff)
    
    # Restore ProjectMemory
    for memory_data in data.get('project_memory', []):
        memory = ProjectMemory(
            content=memory_data['content'],
            type=memory_data['type'],
            is_active=memory_data['is_active'],
            created_at=datetime.fromisoformat(memory_data['created_at'])
        )
        db.session.add(memory)
    
    # Restore UserRequirement
    for req_data in data.get('user_requirements', []):
        req = UserRequirement(
            content=req_data['content'],
            created_at=datetime.fromisoformat(req_data['created_at'])
        )
        db.session.add(req)
    
    db.session.commit() 