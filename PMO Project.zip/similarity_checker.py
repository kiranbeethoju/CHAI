from agents import QuantitativeAgent

class SimilarityChecker:
    def __init__(self):
        self.agent = QuantitativeAgent()  # Reusing the existing agent infrastructure
    
    def check_similarity(self, text1, text2):
        """
        Check semantic similarity between two texts using LLM.
        Returns a tuple of (similarity_score, explanation)
        """
        prompt = f"""
        Compare the following two requirements and determine their semantic similarity.
        Analyze if they are essentially asking for the same thing, even if worded differently.
        
        Requirement 1:
        {text1}
        
        Requirement 2:
        {text2}
        
        Please provide:
        1. A similarity score between 0 and 1 (where 1 means identical in meaning)
        2. A brief explanation of why they are similar or different
        
        Format your response exactly as:
        Score: [number between 0 and 1]
        Explanation: [your explanation]
        """
        
        response = self.agent.analyze(prompt)
        
        try:
            # Parse the response
            lines = response.strip().split('\n')
            score_line = next(line for line in lines if line.startswith('Score:'))
            explanation_line = next(line for line in lines if line.startswith('Explanation:'))
            
            score = float(score_line.split(':')[1].strip())
            explanation = explanation_line.split(':')[1].strip()
            
            return score, explanation
        except (ValueError, StopIteration):
            # Fallback in case of parsing errors
            return 0.0, "Error processing similarity check" 