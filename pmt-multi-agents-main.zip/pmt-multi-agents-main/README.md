# Healthcare Automation Multi-Agent System

A flexible and scalable multi-agent system for healthcare automation that processes clinical notes based on user-defined usecases and rules.

## Features

- Modular LLM service architecture supporting multiple providers (OpenAI, DeepInfra, etc.)
- Autonomous agents for different aspects of processing
- Comprehensive logging
- Validation at multiple stages
- Flexible workflow management
- Easy to extend and scale

## System Architecture

### Components

1. **LLM Service Layer**
   - Abstract base class for LLM services
   - OpenAI implementation included
   - Easy to add new providers

2. **Agent System**
   - UseCaseValidator: Validates input usecase structure
   - StepExecutor: Executes individual steps
   - ResultValidator: Validates final output
   - WorkflowManager: Orchestrates the entire process

3. **Data Models**
   - UseCase: Structured representation of a workflow
   - Step: Individual processing steps
   - Rules: Validation and processing rules

## Usage

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Set up your environment variables:
```bash
export OPENAI_API_KEY=your_api_key_here
```

3. Run the test connection:
```bash
python test_connection.py
```

4. Create a new usecase:
```python
usecase = UseCase(
    name="Your Usecase Name",
    steps=[
        {
            "step": 1,
            "description": "Step description",
            "prompt": "Step-specific prompt"
        }
    ],
    rules={
        "format": "JSON",
        "required_fields": ["field1", "field2"],
        "validation_rules": "Your validation rules"
    },
    clinical_note="Your clinical note here"
)
```

5. Execute the workflow:
```python
workflow_manager = WorkflowManager(llm_service)
result = await workflow_manager.execute_workflow(usecase)
```

## Adding New LLM Providers

To add a new LLM provider:

1. Create a new class inheriting from `LLMService`
2. Implement the required methods:
   - `generate_response()`
   - `validate_response()`
3. Update the configuration to use the new provider

## Logging

The system uses `loguru` for comprehensive logging. Logs include:
- Agent initialization
- Step execution
- Validation results
- Errors and exceptions

## Error Handling

The system includes robust error handling at multiple levels:
- LLM service errors
- Step execution errors
- Validation errors
- Workflow management errors

## Scaling

The system is designed to be scalable in several ways:
- Horizontal scaling of agents
- Multiple LLM providers
- Async/await for concurrent processing
- Modular architecture for easy extension 