import re
import json
from collections import defaultdict
import os
from typing import List, Dict, Any, Tuple

# Flag to control whether to use LLM or not
USE_LLM = os.environ.get("USE_LLM", "true").lower() == "true"

def parse_icd_code(code):
    """Parse an ICD code into its components for comparison."""
    # Handle multiple codes (e.g., "N17.9, N18.9")
    if ',' in code:
        return [parse_icd_code(c.strip()) for c in code.split(',')]
    
    # Parse single code
    match = re.match(r'([A-Z])(\d+)\.?(\d*)', code)
    if match:
        letter, number, decimal = match.groups()
        return {
            'letter': letter,
            'number': int(number),
            'decimal': int(decimal) if decimal else None,
            'original': code
        }
    return {'original': code}

def is_more_specific(code1, code2):
    """Determine if code1 is more specific than code2."""
    # Handle multiple codes
    if isinstance(code1, list) or isinstance(code2, list):
        return False  # Complex case, handle separately
    
    # Same code is not more specific
    if code1['original'] == code2['original']:
        return False
    
    # If codes have the same letter and number but one has a decimal and the other doesn't
    if (code1['letter'] == code2['letter'] and 
        code1['number'] == code2['number']):
        # Code with decimal is more specific than without
        if code1['decimal'] is not None and code2['decimal'] is None:
            return True
        # Higher decimal number generally indicates more specificity
        if (code1['decimal'] is not None and code2['decimal'] is not None):
            # .9 is typically "unspecified" in ICD-10, so anything else is more specific
            if code2['decimal'] == 9 and code1['decimal'] != 9:
                return True
    
    return False

def simple_similarity(term1, term2):
    """Calculate a simple similarity score between two terms."""
    # Convert to lowercase and split into words
    words1 = set(term1.lower().split())
    words2 = set(term2.lower().split())
    
    # Calculate Jaccard similarity: intersection / union
    intersection = len(words1.intersection(words2))
    union = len(words1.union(words2))
    
    if union == 0:
        return 0
    
    return intersection / union

def has_clinical_similarity(term1, term2):
    """Check if two terms have clinical similarity based on keywords."""
    # Normalize terms for comparison
    term1 = term1.lower()
    term2 = term2.lower()
    
    # Check if terms refer to the same condition with different terminology
    if "kidney" in term1 and "renal" in term2:
        return True
    if "renal" in term1 and "kidney" in term2:
        return True
    
    # Common word substitutions that indicate similar clinical concepts
    replacements = {
        "failure": ["injury", "disease"],
        "injury": ["failure", "disease"],
        "disease": ["failure", "injury"],
        "acute": ["sudden"],
        "chronic": ["long-term"],
    }
    
    # Check each key word in replacements
    for key, alternatives in replacements.items():
        if key in term1:
            for alt in alternatives:
                if alt in term2:
                    return True
        if key in term2:
            for alt in alternatives:
                if alt in term1:
                    return True
    
    # Calculate simple similarity
    if simple_similarity(term1, term2) > 0.6:
        return True
    
    return False

def is_parent_of(code1, code2):
    """Check if code1 is a parent code of code2."""
    if isinstance(code1, list) or isinstance(code2, list):
        return False
    
    # Same category but more general (e.g., N17 is parent of N17.1)
    if (code1['letter'] == code2['letter'] and 
        code1['number'] == code2['number'] and
        code1['decimal'] is None and code2['decimal'] is not None):
        return True
    
    # Unspecified codes (ending in .9) can be considered parent codes
    if (code1['letter'] == code2['letter'] and 
        code1['number'] == code2['number'] and
        code1['decimal'] == 9 and code2['decimal'] is not None and
        code2['decimal'] != 9):
        return True
    
    return False

def identify_duplicate_entities(group):
    """Identify duplicate entities based on exact code matches or clinical similarity."""
    duplicates = []
    for i in range(len(group)):
        for j in range(i + 1, len(group)):
            entity1 = group[i]
            entity2 = group[j]
            
            # Skip if already marked as duplicate
            if entity1 in duplicates or entity2 in duplicates:
                continue
            
            # Exact code match
            if entity1['icd_code'] == entity2['icd_code']:
                # Keep the more detailed term (usually longer)
                if len(entity1['icd_term']) >= len(entity2['icd_term']):
                    duplicates.append(entity2)
                else:
                    duplicates.append(entity1)
            
            # Clinical similarity with same ICD codes but different terms
            # Example: "Acute kidney failure" vs "Acute renal failure" with same code
            elif has_clinical_similarity(entity1['icd_term'], entity2['icd_term']):
                # Prioritize keeping the more standard terminology
                if "unspecified" in entity1['icd_term'].lower():
                    duplicates.append(entity1)
                elif "unspecified" in entity2['icd_term'].lower():
                    duplicates.append(entity2)
                # Otherwise keep the longer, more descriptive term
                elif len(entity1['icd_term']) >= len(entity2['icd_term']):
                    duplicates.append(entity2)
                else:
                    duplicates.append(entity1)
    
    return duplicates

def group_codes_by_hierarchy(entities):
    """Group codes based on ICD code hierarchy and clinical similarity."""
    # First create groups by ICD letter and number
    initial_groups = defaultdict(list)
    
    for entity in entities:
        code_parsed = parse_icd_code(entity['icd_code'])
        
        # Handle multiple codes
        if isinstance(code_parsed, list):
            # Create a composite key
            composite_keys = []
            for code in code_parsed:
                if 'letter' in code and 'number' in code:
                    composite_keys.append(f"{code['letter']}{code['number']}")
            
            if composite_keys:
                composite_key = "_".join(sorted(composite_keys))
                initial_groups[composite_key].append(entity)
            else:
                # Fallback for unparseable codes
                initial_groups[entity['icd_code']].append(entity)
        else:
            # Single code
            if 'letter' in code_parsed and 'number' in code_parsed:
                key = f"{code_parsed['letter']}{code_parsed['number']}"
                initial_groups[key].append(entity)
            else:
                # Fallback for unparseable codes
                initial_groups[entity['icd_code']].append(entity)
    
    # Merge groups that have clinical similarity
    merged_groups = []
    processed_keys = set()
    
    for key1, group1 in initial_groups.items():
        if key1 in processed_keys:
            continue
        
        merged_group = group1.copy()
        processed_keys.add(key1)
        
        # Check other groups for clinical similarity
        for key2, group2 in initial_groups.items():
            if key2 in processed_keys or key1 == key2:
                continue
            
            # Check if any entity in group1 has clinical similarity with any entity in group2
            has_similarity = False
            for entity1 in group1:
                for entity2 in group2:
                    # Check header first
                    if entity1['header'] != entity2['header']:
                        continue
                        
                    if has_clinical_similarity(entity1['icd_term'], entity2['icd_term']):
                        has_similarity = True
                        break
                if has_similarity:
                    break
            
            if has_similarity:
                merged_group.extend(group2)
                processed_keys.add(key2)
        
        merged_groups.append(merged_group)
    
    # Special handling for "Septic shock" and Sepsis codes
    sepsis_group = None
    shock_group = None
    
    for group in merged_groups:
        for entity in group:
            if "septic shock" in entity['icd_term'].lower():
                shock_group = group
            elif "sepsis" in entity['icd_term'].lower() and "shock" not in entity['icd_term'].lower():
                sepsis_group = group
    
    # Merge sepsis and septic shock if they're in different groups
    if sepsis_group is not None and shock_group is not None and sepsis_group != shock_group:
        # Find indices
        sepsis_idx = merged_groups.index(sepsis_group)
        shock_idx = merged_groups.index(shock_group)
        
        # Merge the groups
        merged_groups[sepsis_idx].extend(shock_group)
        merged_groups.pop(shock_idx)
    
    return merged_groups

def filter_codes_in_group(group):
    """Filter codes in a group to keep only the most specific ones."""
    to_keep = group.copy()
    to_remove = []
    
    # First, identify and remove duplicates
    duplicates = identify_duplicate_entities(group)
    for dup in duplicates:
        if dup in to_keep:
            to_keep.remove(dup)
            to_remove.append(dup)
    
    # Then identify parent-child relationships
    for i, entity1 in enumerate(group):
        if entity1 in to_remove:
            continue
            
        code1_parsed = parse_icd_code(entity1['icd_code'])
        
        for j, entity2 in enumerate(group):
            if i == j or entity2 in to_remove:
                continue
                
            code2_parsed = parse_icd_code(entity2['icd_code'])
            
            # Skip if complex code (comma-separated)
            if isinstance(code1_parsed, list) or isinstance(code2_parsed, list):
                continue
            
            # If entity1 is more specific than entity2, remove entity2
            if is_more_specific(code1_parsed, code2_parsed) or is_parent_of(code2_parsed, code1_parsed):
                if entity2 in to_keep:
                    to_keep.remove(entity2)
                    to_remove.append(entity2)
    
    # Special case: Handle 'unspecified' codes
    for entity in group:
        if entity in to_remove:
            continue
            
        # If there's a specific code available, remove unspecified ones
        if "unspecified" in entity['icd_term'].lower():
            # Check if there are any more specific alternatives in the group
            has_specific_alternative = False
            for other in group:
                if (other != entity and other not in to_remove and 
                    "unspecified" not in other['icd_term'].lower()):
                    # Parse and compare codes
                    entity_code = parse_icd_code(entity['icd_code'])
                    other_code = parse_icd_code(other['icd_code'])
                    
                    if not isinstance(entity_code, list) and not isinstance(other_code, list):
                        if (entity_code['letter'] == other_code['letter'] and 
                            entity_code['number'] == other_code['number']):
                            has_specific_alternative = True
                            break
            
            if has_specific_alternative and entity in to_keep:
                to_keep.remove(entity)
                to_remove.append(entity)
    
    return to_keep, to_remove

def clean_icd_codes(entities: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """
    Main function to clean ICD codes using rule-based approach.
    
    Args:
        entities: List of ICD code entities
        
    Returns:
        Tuple of (clean_array, removed_array)
    """
    # Group similar codes by hierarchy
    groups = group_codes_by_hierarchy(entities)
    
    # Filter each group to keep only the most specific codes
    clean_array = []
    removed_array = []
    
    for group in groups:
        keep, remove = filter_codes_in_group(group)
        clean_array.extend(keep)
        removed_array.extend(remove)
    
    # Add reasons for removal if not present
    for entity in removed_array:
        if "reason" not in entity:
            if "unspecified" in entity["icd_term"].lower():
                entity["reason"] = "Unspecified code with more specific alternatives available"
            else:
                entity["reason"] = "Removed due to code redundancy or clinical similarity"
    
    return clean_array, removed_array

def process_icd_codes(entities: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """
    Process ICD codes using LLM if enabled, otherwise use rule-based approach.
    
    Args:
        entities: List of ICD code entities
        
    Returns:
        Tuple of (clean_array, removed_array)
    """
    if USE_LLM:
        try:
            # Import LLM integration module
            from llm_integration import process_with_llm_fallback
            return process_with_llm_fallback(entities)
        except ImportError:
            print("LLM integration module not found, using rule-based approach")
            return clean_icd_codes(entities)
        except Exception as e:
            print(f"Error using LLM: {str(e)}. Falling back to rule-based approach")
            return clean_icd_codes(entities)
    else:
        # Use rule-based approach directly
        return clean_icd_codes(entities)

def main():
    try:
        # Load the entities from a file or input
        with open('entities.json', 'r') as f:
            entities = json.load(f)
        
        clean_array, removed_array = process_icd_codes(entities)
        
        print("Clean Array:")
        for entity in clean_array:
            print(entity)
        
        print("\nRemoved Array:")
        for entity in removed_array:
            print(entity)
        
        # Save results to files
        with open('clean_entities.json', 'w') as f:
            json.dump(clean_array, f, indent=2)
            
        with open('removed_entities.json', 'w') as f:
            json.dump(removed_array, f, indent=2)
            
        print(f"\nProcessed {len(entities)} entities")
        print(f"Kept {len(clean_array)} entities")
        print(f"Removed {len(removed_array)} entities")
        
    except Exception as e:
        print(f"Error: {str(e)}")

if __name__ == "__main__":
    main() 