#!/bin/bash

# Install dependencies
pip install -r requirements.txt

# Set environment variables for LLM integration
# By default, we use DeepInfra, but you can configure for Azure OpenAI
export LLM_PROVIDER="deepinfra"  # Options: "deepinfra", "azure", "openai"
export LLM_API_KEY="MnkQNNp6hECvauZrUPUMdBPJLKfdddwt"  # DeepInfra API key
export LLM_ENDPOINT="https://api.deepinfra.com/v1/openai"
export LLM_MODEL="meta-llama/Llama-4-Maverick-17B-128E-Instruct-FP8"

# If you want to use Azure OpenAI, uncomment and set these variables
# export LLM_PROVIDER="azure"
# export LLM_API_KEY="your_azure_api_key"
# export LLM_ENDPOINT="your_azure_endpoint"
# export LLM_MODEL="your_azure_model_name"
# export AZURE_API_VERSION="2023-05-15"

# Control whether to use LLM by default
export USE_LLM="true"  # Options: "true", "false"

# Run the Flask server
echo "Starting ICD Code Cleaner with LLM integration..."
echo "LLM Provider: $LLM_PROVIDER"
echo "LLM Usage: $USE_LLM"
echo "Server will be available at http://localhost:5000"
python api.py 