from flask import Flask, request, jsonify
from flask_cors import CORS
import json
import os
from icd_code_cleaner import process_icd_codes

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

@app.route('/api/process', methods=['POST'])
def process_codes():
    """Process ICD codes via API endpoint."""
    try:
        # Get the entities from the request
        data = request.json
        if not data or not isinstance(data, list):
            return jsonify({'error': 'Invalid input. Expected JSON array of entities.'}), 400
        
        # Check if LLM should be used
        use_llm = request.args.get('use_llm', 'true').lower() == 'true'
        
        # Set environment variable for LLM usage
        os.environ['USE_LLM'] = str(use_llm).lower()
        
        # Process the entities
        clean_array, removed_array = process_icd_codes(data)
        
        # Return the results
        return jsonify({
            'clean_array': clean_array,
            'removed_array': removed_array,
            'stats': {
                'total': len(data),
                'kept': len(clean_array),
                'removed': len(removed_array)
            },
            'used_llm': use_llm
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/')
def index():
    """Serve the HTML interface."""
    with open('app.html', 'r') as f:
        return f.read()

if __name__ == '__main__':
    app.run(debug=True, port=5000) 