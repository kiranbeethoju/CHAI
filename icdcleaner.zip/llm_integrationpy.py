import json
import os
from typing import List, Dict, Any, Optional, Tuple

# Default to DeepInfra but allow easy switching to Azure OpenAI
LLM_PROVIDER = os.environ.get("LLM_PROVIDER", "deepinfra")
LLM_API_KEY = os.environ.get("LLM_API_KEY", "MnkQNNp6hECvauZrUPUMdBPJLKfdddwt")
LLM_ENDPOINT = os.environ.get(
    "LLM_ENDPOINT", 
    "https://api.deepinfra.com/v1/openai" if LLM_PROVIDER == "deepinfra" else None
)
LLM_MODEL = os.environ.get("LLM_MODEL", "meta-llama/Llama-4-Maverick-17B-128E-Instruct-FP8")

# Initialize client based on provider
def get_llm_client():
    """Get LLM client based on configured provider."""
    try:
        from openai import OpenAI
        
        if LLM_PROVIDER == "deepinfra":
            return OpenAI(
                api_key=LLM_API_KEY,
                base_url=LLM_ENDPOINT,
            )
        elif LLM_PROVIDER == "azure":
            # Azure OpenAI requires additional configuration
            return OpenAI(
                api_key=LLM_API_KEY,
                api_version=os.environ.get("AZURE_API_VERSION", "2023-05-15"),
                azure_endpoint=LLM_ENDPOINT,
            )
        else:
            # Standard OpenAI
            return OpenAI(api_key=LLM_API_KEY)
    except ImportError:
        print("OpenAI package not installed. Please install with: pip install openai>=1.0.0")
        return None
    except Exception as e:
        print(f"Error initializing LLM client: {str(e)}")
        return None

def analyze_icd_codes_with_llm(entities: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """
    Use LLM to analyze ICD codes for better clinical understanding and grouping.
    
    Args:
        entities: List of ICD code entities
        
    Returns:
        Dictionary with cleaned and removed entities, or None if LLM call fails
    """
    client = get_llm_client()
    if not client:
        print("LLM client initialization failed, falling back to rule-based approach")
        return None
    
    try:
        # Construct a prompt that guides the LLM to analyze the codes
        prompt = construct_llm_prompt(entities)
        
        # Make the API call
        response = client.chat.completions.create(
            model=LLM_MODEL,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1,  # Low temperature for more deterministic results
            max_tokens=4000,
        )
        
        # Extract and parse the response
        llm_response = response.choices[0].message.content
        result = parse_llm_response(llm_response)
        
        # Print token usage if available
        if hasattr(response, 'usage'):
            print(f"Token usage - Prompt: {response.usage.prompt_tokens}, Completion: {response.usage.completion_tokens}")
        
        return result
    except Exception as e:
        print(f"LLM API call failed: {str(e)}")
        return None

def construct_llm_prompt(entities: List[Dict[str, Any]]) -> str:
    """
    Construct a detailed prompt for the LLM to analyze ICD codes.
    
    Args:
        entities: List of ICD code entities
        
    Returns:
        Formatted prompt string
    """
    # Format the entities for the prompt
    entities_str = json.dumps(entities, indent=2)
    
    prompt = f"""
You are a clinical coding expert specializing in ICD-10 codes. I have a list of ICD-10 codes from clinical notes that need to be cleaned and organized. 
Your task is to analyze these codes to:

1. Identify duplicate codes with different terminologies or phrasings
2. Identify parent-child relationships between codes (e.g., general vs specific conditions)
3. Determine which codes should be kept and which should be removed based on clinical relevance

Here are the important rules to follow:
- Keep more specific codes over unspecified ones (e.g., keep "Sepsis due to E. coli" over "Sepsis, unspecified")
- When terms refer to the same clinical concept with different wording (e.g., "kidney failure" vs "renal failure"), keep the more standard clinical terminology
- When a condition has both acute and chronic versions, typically keep both as they represent different clinical states
- Terms with the same ICD code should be deduplicated, keeping the more detailed or standard term
- For codes with decimal extensions, more specific extensions are preferred over ".9" (unspecified)

CRITICAL RULE: When multiple different terms have the exact same ICD code (like "Uremia" and "Hyperlactatemia" both having R79.89), you MUST choose only one to keep based on:
1. Clinical specificity - keep the term that refers to a more specific clinical condition
2. Standard medical terminology - keep the term that uses more standard clinical language
3. Clinical relevance - keep the term that is more clinically significant in the context of the patient's condition

For example, if both "Uremia" and "Hyperlactatemia" have code R79.89, you must keep only one and remove the other, explaining which is more clinically specific or appropriate.

Analyze this list of ICD codes:
{entities_str}

Provide your response in the following JSON format:
{{
  "clean_array": [
    // List of entities to keep
  ],
  "removed_array": [
    // List of entities to remove, with reason for removal
  ],
  "groupings": [
    // List of identified code groups with explanations
  ]
}}

Be sure to maintain the original structure of each entity, including "icd_term", "icd_code", and "header" fields. For removed entities, add a "reason" field explaining why it was removed.

IMPORTANT: Check your final result to ensure no duplicate ICD codes remain in the clean_array.
"""
    
    return prompt

def parse_llm_response(response_text: str) -> Dict[str, Any]:
    """
    Parse the LLM's response to extract the structured data.
    
    Args:
        response_text: Text response from the LLM
        
    Returns:
        Dictionary with clean_array, removed_array, and groupings
    """
    try:
        # Extract JSON from the response
        json_start = response_text.find('{')
        json_end = response_text.rfind('}') + 1
        
        if json_start == -1 or json_end == 0:
            raise ValueError("No JSON found in response")
            
        json_str = response_text[json_start:json_end]
        result = json.loads(json_str)
        
        # Ensure expected keys are present
        required_keys = ["clean_array", "removed_array"]
        if not all(key in result for key in required_keys):
            missing = [key for key in required_keys if key not in result]
            raise ValueError(f"Missing required keys in LLM response: {missing}")
        
        # Check for duplicate ICD codes in the clean array
        clean_array = result.get("clean_array", [])
        removed_array = result.get("removed_array", [])
        
        # Find duplicate ICD codes in the clean array
        seen_codes = {}
        duplicates = []
        
        for i, item in enumerate(clean_array):
            code = item.get("icd_code")
            if code in seen_codes:
                # Keep the first occurrence, mark the second as duplicate
                duplicates.append(i)
            else:
                seen_codes[code] = i
        
        # Remove duplicates from clean array and add to removed array
        for idx in sorted(duplicates, reverse=True):
            dup_item = clean_array.pop(idx)
            dup_item["reason"] = f"Duplicate ICD code {dup_item['icd_code']} found in clean array, keeping first occurrence"
            removed_array.append(dup_item)
        
        # Add reasons to removed array if not present
        for item in result.get("removed_array", []):
            if "reason" not in item:
                item["reason"] = "Removed by LLM analysis"
                
        return result
    except json.JSONDecodeError as e:
        print(f"Failed to parse LLM response as JSON: {str(e)}")
        raise ValueError("LLM response did not contain valid JSON")
    except Exception as e:
        print(f"Error parsing LLM response: {str(e)}")
        raise

def process_with_llm_fallback(entities: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """
    Process ICD codes using LLM with fallback to rule-based approach.
    
    Args:
        entities: List of ICD code entities
        
    Returns:
        Tuple of (clean_array, removed_array)
    """
    try:
        # Try LLM approach first
        llm_result = analyze_icd_codes_with_llm(entities)
        
        if llm_result and "clean_array" in llm_result and "removed_array" in llm_result:
            print("Successfully processed with LLM")
            return llm_result["clean_array"], llm_result["removed_array"]
    except Exception as e:
        print(f"LLM processing failed: {str(e)}")
    
    # Fallback: use rule-based approach by importing here to avoid circular imports
    print("Falling back to rule-based processing")
    from icd_code_cleaner import clean_icd_codes
    return clean_icd_codes(entities) 