# ICD Code Cleaner

This script identifies and groups ICD-10 codes with similar parent-child relationships, removes duplicate and less specific codes, and returns a clean list of clinically relevant codes.

## Features

- Groups related ICD codes based on hierarchy and clinical similarity
- Identifies parent-child relationships between codes
- Removes duplicate codes with similar clinical meanings
- Removes unspecified codes when more specific alternatives exist
- Special handling for common clinical terms (kidney/renal, failure/injury, etc.)
- LLM-enhanced analysis for better clinical context understanding
- Web interface for easy visualization

## Requirements

- Python 3.6+
- Required packages: numpy, flask, flask-cors, openai>=1.0.0

## Installation

1. Clone this repository or download the script files
2. Install required packages:

```bash
pip install -r requirements.txt
```

## Usage

### Command Line

1. Prepare your ICD codes in a JSON file named `entities.json` with the following format:

```json
[
  {
    "icd_term": "Acute kidney failure, unspecified",
    "icd_code": "N17.9",
    "header": "assessment"
  },
  ...
]
```

2. Run the script:

```bash
python icd_code_cleaner.py
```

3. The script will output:
   - Clean array of codes (also saved to `clean_entities.json`)
   - Removed codes (also saved to `removed_entities.json`)
   - Statistics about the processing

### Web Interface

1. Start the web server:

```bash
./start.sh
```

2. Open your browser and navigate to http://localhost:5000
3. Paste your ICD codes in JSON format and click "Process ICD Codes"
4. Toggle the LLM switch to enable/disable LLM-enhanced analysis
5. The interface will display grouped results, clean codes, and removed codes

## LLM Integration

The system can use LLM (Large Language Model) to enhance the analysis of ICD codes by better understanding clinical contexts and relationships. This provides more accurate grouping and filtering.

### Configuration

By default, the system uses DeepInfra's API, but you can configure it to use Azure OpenAI by setting these environment variables:

```
LLM_PROVIDER=azure
LLM_API_KEY=your_azure_api_key
LLM_ENDPOINT=your_azure_endpoint
LLM_MODEL=your_azure_model_name
AZURE_API_VERSION=your_azure_api_version
```

You can also disable LLM usage entirely by setting:

```
USE_LLM=false
```

## How It Works

1. **Code Parsing**: Parses ICD codes into components (letter, number, decimal)
2. **Grouping**: Groups codes based on parent-child relationships and clinical similarity
3. **Filtering**: Removes duplicates and less specific codes within each group
4. **Special Handling**: Applies clinical knowledge for special cases like "unspecified" codes
5. **LLM Analysis** (when enabled): Uses an LLM to provide enhanced clinical understanding

## Examples

- Keeps "Acute kidney failure with tubular necrosis" (N17.0) over "Acute kidney failure, unspecified" (N17.9)
- Identifies that "Acute kidney failure" and "Acute renal failure" refer to the same clinical concept
- Handles complex cases like "Acute kidney failure on chronic kidney disease" (multiple codes)
- When using LLM, can identify less obvious clinical relationships and duplications

## API

The web interface includes a simple API endpoint:

- **POST /api/process**: Process a list of ICD entities
  - Request body: JSON array of ICD entities
  - Query parameters: 
    - `use_llm`: Set to "true" or "false" to control LLM usage
  - Response: JSON object with clean_array, removed_array, stats, and used_llm flag 