from flask import Flask, render_template, jsonify, request
from flask_socketio import SocketIO, emit
import json
import asyncio
import threading
from agents import UseCase, WorkflowManager
from llm_service import OpenAIService, DeepInfraService, AzureOpenAIService
from openai import OpenAI, AzureOpenAI
import os
from dotenv import load_dotenv
import traceback

# Load environment variables
load_dotenv()

# LLM Provider Configuration
LLM_PROVIDER = os.getenv('LLM_PROVIDER', 'deepinfra')  # Options: 'openai', 'deepinfra', 'azure'

# Provider-specific configurations
LLM_CONFIGS = {
    'openai': {
        'api_key': os.getenv('OPENAI_API_KEY'),
        'model': os.getenv('OPENAI_MODEL', 'gpt-4'),
    },
    'deepinfra': {
        'api_key': os.getenv('DEEPINFRA_API_KEY', 'MnkQNNp6hECvauZrUPUMdBPJLKfdddwt'),
        'base_url': os.getenv('DEEPINFRA_BASE_URL', 'https://api.deepinfra.com/v1/openai'),
        'model': os.getenv('DEEPINFRA_MODEL', 'meta-llama/Llama-4-Maverick-17B-128E-Instruct-FP8'),
    },
    'azure': {
        'api_key': os.getenv('AZURE_OPENAI_API_KEY'),
        'azure_endpoint': os.getenv('AZURE_OPENAI_ENDPOINT'),
        'api_version': os.getenv('AZURE_OPENAI_API_VERSION', '2023-05-15'),
        'deployment': os.getenv('AZURE_OPENAI_DEPLOYMENT'),
    }
}

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'

# Ensure static JS directory is properly served
app.static_folder = 'static'
app.static_url_path = '/static'

# Initialize SocketIO with correct configuration
socketio = SocketIO(app, 
                   cors_allowed_origins="*",  # Allow all origins for development
                   async_mode='threading',    # Use threading mode
                   logger=False,             # Disable socket.io logger
                   engineio_logger=False)    # Disable engineio logger

# Store active workflows
active_workflows = {}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/update_llm_settings', methods=['POST'])
def update_llm_settings():
    """Update LLM settings."""
    try:
        data = request.json
        provider = data.get('provider')
        
        # Validate provider
        if provider not in ['openai', 'deepinfra', 'azure']:
            return jsonify({'status': 'error', 'message': 'Invalid provider'}), 400
        
        # Update global provider setting
        global LLM_PROVIDER
        LLM_PROVIDER = provider
        
        # Update provider-specific settings
        if provider == 'openai':
            if 'api_key' in data and data['api_key']:
                LLM_CONFIGS['openai']['api_key'] = data['api_key']
            if 'model' in data and data['model']:
                LLM_CONFIGS['openai']['model'] = data['model']
                
        elif provider == 'deepinfra':
            if 'api_key' in data and data['api_key']:
                LLM_CONFIGS['deepinfra']['api_key'] = data['api_key']
            if 'model' in data and data['model']:
                LLM_CONFIGS['deepinfra']['model'] = data['model']
                
        elif provider == 'azure':
            if 'api_key' in data and data['api_key']:
                LLM_CONFIGS['azure']['api_key'] = data['api_key']
            if 'api_base' in data and data['api_base']:
                LLM_CONFIGS['azure']['azure_endpoint'] = data['api_base']
            if 'api_version' in data and data['api_version']:
                LLM_CONFIGS['azure']['api_version'] = data['api_version']
            if 'api_type' in data and data['api_type']:
                LLM_CONFIGS['azure']['api_type'] = data['api_type']
            if 'deployment' in data and data['deployment']:
                LLM_CONFIGS['azure']['deployment'] = data['deployment']
        
        return jsonify({'status': 'success', 'message': f'Updated LLM provider to {provider}'})
    
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

def send_progress_update(workflow_id, progress_data):
    """Send progress updates through WebSocket."""
    socketio.emit('progress', {
        'workflow_id': workflow_id,
        'data': progress_data
    })

def send_log(workflow_id, level, message):
    """Send log messages through WebSocket."""
    print(f"Sending log: {level} - {message}")  # Debug print
    socketio.emit('log', {
        'level': level,
        'message': message
    })

def send_result(workflow_id, step_id, result):
    """Send step results through WebSocket."""
    socketio.emit('result', {
        'workflow_id': workflow_id,
        'step_id': step_id,
        'data': {
            'content': result.content,
            'raw_content': result.metadata.get('raw_content', result.content),
            'error': result.error if hasattr(result, 'error') else None
        }
    })

def init_llm_service(provider=None):
    """Initialize the appropriate LLM service based on configuration."""
    if not provider:
        provider = LLM_PROVIDER
    
    provider = provider.lower()
    config = LLM_CONFIGS.get(provider, {})
    
    if provider == 'openai':
        client = OpenAI(api_key=config['api_key'])
        return OpenAIService({"client": client, "model": config['model']})
    
    elif provider == 'deepinfra':
        client = OpenAI(
            api_key=config['api_key'],
            base_url=config['base_url']
        )
        return OpenAIService({"client": client, "model": config['model']})
    
    elif provider == 'azure':
        # For Azure, we'll still create a client for backward compatibility
        # but the service will use the direct openai module approach
        client = AzureOpenAI(
            api_key=config['api_key'],
            azure_endpoint=config['azure_endpoint'],
            api_version=config.get('api_version', '2023-05-15'),
            api_type=config.get('api_type', 'azure')
        )
        
        # Pass all required configuration
        return AzureOpenAIService({
            "client": client,  # Keep for backward compatibility
            "api_key": config['api_key'],
            "azure_endpoint": config['azure_endpoint'],
            "api_version": config.get('api_version', '2023-05-15'),
            "api_type": config.get('api_type', 'azure'),
            "deployment": config.get('deployment')
        })
    
    else:
        # Default to OpenAI
        client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
        return OpenAIService({"client": client, "model": "gpt-4"})

async def execute_workflow_async(workflow_id, config):
    try:
        send_log(workflow_id, 'info', 'Initializing workflow...')
        
        # Use provider from request if specified
        request_provider = config.get('llm_provider')
        provider = request_provider if request_provider else LLM_PROVIDER
        
        # Initialize LLM service based on provider configuration
        llm_service = init_llm_service(provider)
        send_log(workflow_id, 'info', f'Using LLM provider: {provider}')
        
        # Log the workflow configuration
        send_log(workflow_id, 'info', f'Workflow Configuration: {json.dumps(config, indent=2)}')
        
        send_log(workflow_id, 'info', 'Setting up workflow configuration...')
        
        # Create UseCase object from config
        steps = []
        for idx, step in enumerate(config['steps']):
            step_config = {
                "id": step['id'],
                "step": idx + 1,
                "description": step['description'],
                "prompt": step['prompt'],
                "dependencies": step.get('dependencies', []),
                "parallel_group": step.get('parallel_group', ''),
                "include_clinical_note": step.get('include_clinical_note', False)
            }
            
            # Log the prompt for each step
            send_log(workflow_id, 'info', f"\n=== Step {step['id']} Prompt ===\n" + 
                    f"System Description: {step['description']}\n" +
                    f"User Prompt: {step['prompt']}\n")
            
            if step_config["include_clinical_note"]:
                step_config["prompt"] = f"Clinical Note:\n{config['clinical_note']}\n\nTask:\n{step_config['prompt']}"
                send_log(workflow_id, 'info', f"Clinical Note included in prompt:\n{step_config['prompt']}\n")
            
            steps.append(step_config)
        
        usecase = UseCase(
            name=config['name'],
            clinical_note=config['clinical_note'],
            steps=steps
        )
        
        # Initialize workflow manager
        workflow_manager = WorkflowManager(llm_service)
        total_steps = len(steps)
        
        send_progress_update(workflow_id, {
            'completed_steps': 0,
            'total_steps': total_steps
        })
        
        # Execute workflow
        send_log(workflow_id, 'info', f"Executing workflow with {total_steps} steps...")
        results = await workflow_manager.execute_workflow(usecase)
        
        # Process results one by one
        completed_steps = 0
        for step in steps:
            step_id = step['id']
            if step_id in results:
                completed_steps += 1
                result = results[step_id]
                
                # Log the result content
                send_log(workflow_id, 'info', f"\n=== Step {step_id} Response ===\n{result.content}\n")
                
                # Send individual step result
                send_result(workflow_id, step_id, result)
                
                # Update progress
                send_progress_update(workflow_id, {
                    'completed_steps': completed_steps,
                    'total_steps': total_steps
                })
                
                send_log(workflow_id, 'info', f"Step {step_id} completed successfully")
        
        send_log(workflow_id, 'info', 'Workflow completed successfully')
        socketio.emit('complete', {
            'workflow_id': workflow_id,
            'status': 'success'
        })
        
    except Exception as e:
        error_message = f"Error: {str(e)}\nTraceback: {traceback.format_exc()}"
        send_log(workflow_id, 'error', error_message)
        socketio.emit('complete', {
            'workflow_id': workflow_id,
            'status': 'error',
            'message': error_message
        })
    
    finally:
        if workflow_id in active_workflows:
            del active_workflows[workflow_id]

def run_async_workflow(workflow_id, config):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(execute_workflow_async(workflow_id, config))
    loop.close()

@socketio.on('start_workflow')
def handle_start_workflow(data):
    """Handle workflow start request."""
    workflow_id = data.get('workflow_id')
    config = data.get('config')
    
    if not workflow_id or not config:
        return jsonify({'error': 'Missing workflow_id or config'}), 400
    
    if workflow_id in active_workflows:
        return jsonify({'error': 'Workflow already running'}), 400
    
    # Start workflow execution in a separate thread
    thread = threading.Thread(
        target=run_async_workflow,
        args=(workflow_id, config)
    )
    active_workflows[workflow_id] = thread
    thread.start()
    
    return jsonify({'status': 'started'})

@socketio.on('stop_workflow')
def handle_stop_workflow(data):
    """Handle workflow stop request."""
    workflow_id = data.get('workflow_id')
    
    if not workflow_id or workflow_id not in active_workflows:
        return jsonify({'error': 'Invalid workflow_id'}), 400
    
    # Note: This is a simple implementation. In a production environment,
    # you would want a more sophisticated way to stop workflows gracefully
    if workflow_id in active_workflows:
        del active_workflows[workflow_id]
        send_log(workflow_id, 'info', 'Workflow stopped by user')
        socketio.emit('complete', {
            'workflow_id': workflow_id,
            'status': 'stopped'
        })
    
    return jsonify({'status': 'stopped'})

if __name__ == '__main__':
    try:
        port = 8000
        print(f"Starting server on http://localhost:{port}")
        print("NOTE: No workflows will be started automatically. Please use the UI to start a workflow.")
        socketio.run(app, 
                    host='0.0.0.0',     # Use all interfaces
                    port=port,          # Specify port 
                    debug=True,         # Enable debug mode
                    use_reloader=False) # Disable reloader to avoid duplicate processes
    except Exception as e:
        print(f"Error starting server: {e}") 