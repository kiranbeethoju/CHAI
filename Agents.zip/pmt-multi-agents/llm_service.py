from abc import ABC, abstractmethod
from typing import Dict, Any
from loguru import logger

class LLMService(ABC):
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        logger.info(f"Initializing {self.__class__.__name__}")

    @abstractmethod
    async def generate_response(self, prompt: str, **kwargs) -> str:
        pass

    @abstractmethod
    async def validate_response(self, response: str, rules: Dict[str, Any]) -> bool:
        pass

class OpenAIService(LLMService):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.client = config.get("client")
        self.model = config.get("model", "gpt-4")

    async def generate_response(self, prompt: str, **kwargs) -> str:
        try:
            response = self.client.responses.create(
                model=self.model,
                input=prompt
            )
            return response.output_text
        except Exception as e:
            logger.error(f"Error generating response: {str(e)}")
            raise

    async def validate_response(self, response: str, rules: Dict[str, Any]) -> bool:
        # Implement validation logic based on rules
        validation_prompt = f"""
        Validate the following response according to these rules:
        Response: {response}
        Rules: {rules}
        """
        try:
            validation_result = await self.generate_response(validation_prompt)
            return "VALID" in validation_result.upper()
        except Exception as e:
            logger.error(f"Error validating response: {str(e)}")
            return False 