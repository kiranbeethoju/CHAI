import asyncio
import os
from dotenv import load_dotenv
from openai import OpenAI
from llm_service import OpenAIService
from agents import UseCase, WorkflowManager

# Load environment variables
load_dotenv()

async def test_openai_connection():
    # Initialize OpenAI client with API key from environment
    client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
    
    # Test simple completion
    try:
        response = client.responses.create(
            model="gpt-4",
            input="Write a one-sentence bedtime story about a unicorn."
        )
        print("OpenAI Connection Test Successful!")
        print(f"Response: {response.output_text}")
        return True
    except Exception as e:
        print(f"OpenAI Connection Test Failed: {str(e)}")
        return False

async def test_workflow():
    # Initialize OpenAI client and service with API key from environment
    client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
    llm_service = OpenAIService({"client": client, "model": "gpt-4"})
    
    # Create a sample usecase
    usecase = UseCase(
        name="Clinical Note Analysis",
        steps=[
            {
                "step": 1,
                "description": "Extract patient symptoms",
                "prompt": "List all symptoms mentioned in the clinical note"
            },
            {
                "step": 2,
                "description": "Generate diagnosis",
                "prompt": "Based on the symptoms, suggest possible diagnoses"
            }
        ],
        rules={
            "format": "JSON",
            "required_fields": ["symptoms"],
            "validation_rules": "Must include at least 2 symptoms and 1 diagnosis"
        },
        clinical_note="Patient presents with fever and cough for 3 days. Temperature 101°F."
    )
    
    # Initialize and run workflow
    workflow_manager = WorkflowManager(llm_service)
    try:
        result = await workflow_manager.execute_workflow(usecase)
        print("\nWorkflow Test Successful!")
        print(f"Results: {result}")
        return True
    except Exception as e:
        print(f"\nWorkflow Test Failed: {str(e)}")
        return False

if __name__ == "__main__":
    async def run_tests():
        print("Running OpenAI Connection Test...")
        await test_openai_connection()
        
        print("\nRunning Workflow Test...")
        await test_workflow()
    
    asyncio.run(run_tests()) 