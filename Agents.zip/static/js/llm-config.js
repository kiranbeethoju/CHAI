// Handle LLM provider configuration
document.addEventListener('DOMContentLoaded', function() {
    // Set up the provider selection change handler
    const providerSelect = document.getElementById('llmProvider');
    if (providerSelect) {
        providerSelect.addEventListener('change', function() {
            updateProviderConfigVisibility();
        });
        
        // Initial visibility setup
        updateProviderConfigVisibility();
        updateActiveLLMIndicator();
    }
});

// Update which provider config section is visible
function updateProviderConfigVisibility() {
    const providerSelect = document.getElementById('llmProvider');
    const selectedProvider = providerSelect.value;
    
    // Hide all provider configs
    document.querySelectorAll('.provider-config').forEach(config => {
        config.style.display = 'none';
    });
    
    // Show the selected provider config
    const selectedConfig = document.getElementById(`${selectedProvider}Config`);
    if (selectedConfig) {
        selectedConfig.style.display = 'block';
    }
    
    // Update the active provider indicator
    updateActiveLLMIndicator();
}

// Update LLM settings on the server
function updateLLMSettings() {
    const provider = document.getElementById('llmProvider').value;
    let settings = {
        provider: provider
    };
    
    // Get provider-specific settings
    if (provider === 'openai') {
        settings.api_key = document.getElementById('openaiApiKey').value;
        settings.model = document.getElementById('openaiModel').value;
    }
    else if (provider === 'deepinfra') {
        settings.api_key = document.getElementById('deepinfraApiKey').value;
        settings.model = document.getElementById('deepinfraModel').value;
    }
    else if (provider === 'azure') {
        settings.api_key = document.getElementById('azureApiKey').value;
        settings.api_base = document.getElementById('azureApiBase').value;
        settings.api_version = document.getElementById('azureApiVersion').value;
        settings.api_type = document.getElementById('azureApiType').value;
        settings.deployment = document.getElementById('azureDeployment').value;
        
        // Validate that all required fields are filled
        if (!settings.api_key || !settings.api_base || !settings.deployment) {
            showNotification('Please fill in all required Azure OpenAI fields', 'error');
            return;
        }
    }
    
    // Send the settings to the server
    fetch('/update_llm_settings', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(settings),
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showNotification('LLM settings updated successfully', 'success');
            updateActiveLLMIndicator();
        } else {
            showNotification(`Error: ${data.message}`, 'error');
        }
    })
    .catch(error => {
        showNotification(`Error: ${error.message}`, 'error');
    });
}

// Add this to your showNotification function if it doesn't exist
function showNotification(message, type = 'info') {
    const notification = document.getElementById('notification');
    if (!notification) {
        console.error('Notification element not found');
        alert(message); // Fallback
        return;
    }
    
    const messageElement = notification.querySelector('.notification-message');
    notification.className = `notification ${type}`;
    messageElement.textContent = message;
    notification.classList.remove('hidden');
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
        notification.classList.add('hidden');
    }, 5000);
}

// Add a visual indicator for the active LLM provider
function updateActiveLLMIndicator() {
    const provider = document.getElementById('llmProvider').value;
    
    // Remove existing badge
    const existingBadge = document.querySelector('.provider-badge');
    if (existingBadge) {
        existingBadge.remove();
    }
    
    // Create the badge
    const badge = document.createElement('span');
    badge.className = `provider-badge ${provider}`;
    
    // Set the badge text
    let badgeText = 'Unknown';
    if (provider === 'openai') {
        badgeText = 'OpenAI';
    } else if (provider === 'deepinfra') {
        badgeText = 'DeepInfra Llama 4';
    } else if (provider === 'azure') {
        badgeText = 'Azure OpenAI';
    }
    badge.textContent = badgeText;
    
    // Add the badge to the page
    const providerLabel = document.querySelector('label[for="llmProvider"]');
    if (providerLabel) {
        providerLabel.appendChild(badge);
    }
} 