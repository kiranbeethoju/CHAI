// Throttle function to limit how often a function can be called
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Utility to show browser notifications
function notifyUser(title, message) {
    if (!('Notification' in window)) return;
    if (Notification.permission === 'granted') {
        new Notification(title, {body: message});
    } else if (Notification.permission !== 'denied') {
        Notification.requestPermission().then(permission => {
            if (permission === 'granted') {
                new Notification(title, {body: message});
            }
        });
    }
}

// Function to add step result with compact formatting
function addStepResult(stepId, resultData) {
    const resultsContainer = document.getElementById('resultsContainer');
    
    // Remove stray markdown fences in raw content
    if (resultData.raw_content) {
        resultData.raw_content = resultData.raw_content.replace(/^```.*$/gm, '').replace(/```$/gm, '');
    }
    
    // Create container for this step's result
    const resultCard = document.createElement('div');
    resultCard.className = 'card';
    resultCard.setAttribute('data-step-id', stepId);
    
    // Find the corresponding step card to get its color
    const stepCard = document.querySelector(`.step-card[data-step-id="${stepId}"]`);
    if (stepCard) {
        // Get the group value
        const groupValue = stepCard.getAttribute('data-group') || '';
        resultCard.setAttribute('data-group', groupValue);
        
        // If step has a background color, apply a matching subtle color to the result card
        if (groupValue) {
            // Use custom attribute for CSS targeting
            resultCard.setAttribute('data-result-group', groupValue);
        }
    }
    
    // Create card header
    const cardHeader = document.createElement('div');
    cardHeader.className = 'card-header d-flex justify-content-between align-items-center py-1 px-2';
    
    // Add step info to header
    const stepTitle = document.createElement('h6');
    stepTitle.className = 'mb-0 small';
    stepTitle.textContent = `Step ${stepId} Result`;
    
    // Add collapse/expand button
    const toggleButton = document.createElement('button');
    toggleButton.className = 'btn btn-sm btn-outline-secondary py-0 px-1';
    toggleButton.innerHTML = '<i class="bi bi-chevron-up"></i>';
    toggleButton.addEventListener('click', function() {
        const body = this.closest('.card').querySelector('.card-body');
        if (body.style.display === 'none') {
            body.style.display = '';
            this.innerHTML = '<i class="bi bi-chevron-up"></i>';
        } else {
            body.style.display = 'none';
            this.innerHTML = '<i class="bi bi-chevron-down"></i>';
        }
    });
    
    cardHeader.appendChild(stepTitle);
    cardHeader.appendChild(toggleButton);
    resultCard.appendChild(cardHeader);
    
    // Create card body
    const cardBody = document.createElement('div');
    cardBody.className = 'card-body p-1';
    
    // Process result content
    let contentHtml = '';
    
    if (resultData.error) {
        contentHtml = `<div class="result-error">Error: ${resultData.error}</div>`;
    } else {
        // Check if raw_content is available (full output from LLM including explanations)
        if (resultData.raw_content) {
            // Process the raw content, which may contain markdown
            const rawContentDiv = document.createElement('div');
            rawContentDiv.className = 'raw-content';
            
            // Replace newlines with <br> tags for better readability
            const formattedText = resultData.raw_content
                .replace(/\n\n/g, '<br><br>')
                .replace(/\n/g, '<br>')
                // Format code blocks with syntax highlighting
                .replace(/```json\s*([\s\S]*?)```/g, '<pre class="code-block"><code class="language-json">$1</code></pre>')
                .replace(/```python\s*([\s\S]*?)```/g, '<pre class="code-block"><code class="language-python">$1</code></pre>')
                .replace(/```([a-z]*)\s*([\s\S]*?)```/g, '<pre class="code-block"><code>$2</code></pre>');
            
            rawContentDiv.innerHTML = formattedText;
            contentHtml = rawContentDiv.outerHTML;
        } 
        // Also try to extract and format JSON if present
        else if (resultData.content) {
            try {
                // Try to parse as JSON
                const jsonObj = JSON.parse(resultData.content);
                contentHtml = formatJsonCompact(jsonObj);
            } catch (e) {
                // If not JSON, display as text
                contentHtml = `<div class="result-text">${resultData.content}</div>`;
            }
        }
    }
    
    cardBody.innerHTML = contentHtml;
    resultCard.appendChild(cardBody);
    
    // Append to results container
    const existingResult = resultsContainer.querySelector(`[data-step-id="${stepId}"]`);
    if (existingResult) {
        resultsContainer.replaceChild(resultCard, existingResult);
    } else {
        resultsContainer.appendChild(resultCard);
    }
    
    // Send a push notification for this update
    notifyUser(`Step ${stepId} Result`, 'New result received');
}

// Format JSON in a more compact way with syntax highlighting
function formatJsonCompact(jsonObj) {
    const pre = document.createElement('pre');
    pre.className = 'json-content';
    
    // Format JSON with very compact indentation
    const formattedJson = JSON.stringify(jsonObj, null, 1); // Use minimal indent
    
    // Advanced syntax highlighting with colors matching group colors
    const highlightedJson = formattedJson
        // Keys
        .replace(/"([^"]+)":/g, '<span class="json-key">"$1"</span>:')
        // String values
        .replace(/: "([^"]+)"/g, ': <span class="json-value">"$1"</span>')
        // Number values
        .replace(/: ([0-9.]+)([,\n])/g, ': <span class="json-value">$1</span>$2')
        // Boolean values
        .replace(/: (true|false)([,\n])/g, ': <span class="json-value">$1</span>$2')
        // Null values
        .replace(/: (null)([,\n])/g, ': <span class="json-value">$1</span>$2')
        // Array brackets
        .replace(/\[/g, '<span class="json-bracket">[</span>')
        .replace(/\]/g, '<span class="json-bracket">]</span>')
        // Object braces
        .replace(/\{/g, '<span class="json-brace">{</span>')
        .replace(/\}/g, '<span class="json-brace">}</span>');
    
    pre.innerHTML = highlightedJson;
    
    return pre.outerHTML;
}

// Function to clear all results
function clearAllResults() {
    document.getElementById('resultsContainer').innerHTML = '';
}

// Register socket event handler for step results if not already done
if (typeof socket !== 'undefined' && !socket._resultsHandlerAdded) {
    // Use throttled handler to prevent excessive updates
    const throttledAddStepResult = throttle(function(data) {
        addStepResult(data.step_id, data.data);
    }, 100); // Limit to once per 100ms
    
    socket.on('result', throttledAddStepResult);
    socket._resultsHandlerAdded = true;
} 