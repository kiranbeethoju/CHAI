// Define a palette of light colors for parallel groups
const parallelGroupColors = {
    // Default is white/transparent
    '': '',
    // Light pastel colors
    'group1': '#E6F7FF', // light blue
    'group2': '#F0F9EB', // light green
    'group3': '#FFF7E6', // light orange
    'group4': '#FCF2F2', // light red
    'group5': '#F6EFFB', // light purple
    'group6': '#F0FCFF', // light cyan
    'group7': '#FEFEF2', // light yellow
    'group8': '#F2F6FC', // light indigo
    'group9': '#FFF1F0', // light pink
    'group10': '#F7F7F7' // light gray
};

// Global map to keep track of group colors
const usedGroupColors = new Map();

// Global reference to the input observer
let inputObserver;

// Add a throttle function at the top of the file
// Throttle function to limit how often a function can be called
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Function to update a single step card color
function updateStepCardColor(card) {
    if (!card || !card.classList || !card.classList.contains('step-card')) {
        return; // Not a valid step card
    }
    
    const groupInput = card.querySelector('.step-group');
    if (!groupInput) return;
    
    const groupValue = groupInput.value ? groupInput.value.trim() : '';
    
    // Always set the data-group attribute (to enable CSS targeting)
    card.setAttribute('data-group', groupValue);
    
    // Reset to default if group is empty
    if (!groupValue) {
        card.style.backgroundColor = '';
        
        // Remove any group indicators
        const indicator = card.querySelector('.group-indicator');
        if (indicator) {
            indicator.remove();
        }
        return;
    }
    
    // Check if we've already assigned a color to this group
    let color;
    if (usedGroupColors.has(groupValue)) {
        color = usedGroupColors.get(groupValue);
    } else {
        // If it's a predefined group (group1, group2, etc.)
        if (parallelGroupColors[groupValue]) {
            color = parallelGroupColors[groupValue];
        } else {
            // For dynamic group names, assign a color based on the hash
            const groupIndex = Math.abs(hashString(groupValue) % 10) + 1;
            color = parallelGroupColors[`group${groupIndex}`];
        }
        // Store the color assignment
        usedGroupColors.set(groupValue, color);
    }
    
    // Apply the color - both via style and data attribute for CSS backup
    card.style.backgroundColor = color;
    
    // If this is a header/title section, adjust text color if needed
    const headerSection = card.querySelector('.card-header');
    if (headerSection) {
        headerSection.style.backgroundColor = 'transparent';
    }
}

// Function to update all step cards - limit how often this can run
const updateStepCardColorsThrottled = throttle(function() {
    const stepCards = document.querySelectorAll('.step-card');
    
    // Reset used colors to ensure consistency
    usedGroupColors.clear();
    
    // First build the color map for all groups
    stepCards.forEach(card => {
        const groupInput = card.querySelector('.step-group');
        if (groupInput && groupInput.value.trim()) {
            const groupValue = groupInput.value.trim();
            if (!usedGroupColors.has(groupValue)) {
                // Assign a color from the palette or generate one
                if (parallelGroupColors[groupValue]) {
                    usedGroupColors.set(groupValue, parallelGroupColors[groupValue]);
                } else {
                    const groupIndex = Math.abs(hashString(groupValue) % 10) + 1;
                    usedGroupColors.set(groupValue, parallelGroupColors[`group${groupIndex}`]);
                }
            }
        }
    });
    
    // Now update all cards
    stepCards.forEach(card => updateStepCardColor(card));
    
    // Group cards with the same parallel group visually
    highlightSameGroupCards();
}, 500); // Throttle to once per 500ms

// Original function will now call the throttled version
function updateStepCardColors() {
    updateStepCardColorsThrottled();
}

// Function to visually highlight cards in the same group
function highlightSameGroupCards() {
    // Create a map of group values to card elements
    const groupMap = new Map();
    
    // First pass: collect all cards by group
    document.querySelectorAll('.step-card').forEach(card => {
        const groupInput = card.querySelector('.step-group');
        if (!groupInput) return;
        
        const groupValue = groupInput.value.trim();
        if (!groupValue) return;
        
        if (!groupMap.has(groupValue)) {
            groupMap.set(groupValue, []);
        }
        groupMap.get(groupValue).push(card);
    });
    
    // Second pass: add group indicator if more than one card in the group
    groupMap.forEach((cards, groupValue) => {
        if (cards.length > 1) {
            cards.forEach(card => {
                // Add or update group indicator
                let indicator = card.querySelector('.group-indicator');
                if (!indicator) {
                    indicator = document.createElement('span');
                    indicator.className = 'group-indicator badge bg-success ms-2';
                    const titleElement = card.querySelector('.step-title');
                    if (titleElement) {
                        titleElement.appendChild(indicator);
                    }
                }
                indicator.textContent = `Group: ${groupValue}`;
            });
        }
    });
}

// Simple hash function for strings
function hashString(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        hash = ((hash << 5) - hash) + str.charCodeAt(i);
        hash |= 0; // Convert to 32bit integer
    }
    return hash;
}

// Handle real-time input on group fields - optimize this handler
function setupRealTimeColorUpdates() {
    // Create a custom event that can be triggered
    const parallelGroupChangeEvent = new CustomEvent('parallelGroupChange');
    
    // Use a debounced handler for input events
    const handleGroupInputChange = throttle(function(event) {
        if (event.target.classList.contains('step-group')) {
            // Update this specific card immediately
            const card = event.target.closest('.step-card');
            if (card) {
                // Set the data-group attribute immediately
                const groupValue = event.target.value ? event.target.value.trim() : '';
                card.setAttribute('data-group', groupValue);
                
                // Then update the color
                updateStepCardColor(card);
                
                // Then update all cards to ensure consistency - throttled
                updateStepCardColors();
                
                // Dispatch a custom event that workflow.js can listen for
                document.dispatchEvent(parallelGroupChangeEvent);
            }
        }
    }, 250); // Limit to once per 250ms
    
    // Direct input event listener
    document.addEventListener('input', handleGroupInputChange);
    
    // Also listen for any programmatic changes to the input values
    document.addEventListener('change', handleGroupInputChange);
    
    // Optimize MutationObserver behavior
    inputObserver = new MutationObserver(function(mutations) {
        let shouldUpdate = false;
        
        mutations.forEach(mutation => {
            if (mutation.type === 'attributes' && 
                mutation.attributeName === 'value' && 
                mutation.target.classList.contains('step-group')) {
                shouldUpdate = true;
            }
        });
        
        if (shouldUpdate) {
            // Use throttled update instead of calling multiple times
            updateStepCardColors();
        }
    });
    
    // Start observing all step group inputs
    document.querySelectorAll('.step-group').forEach(input => {
        inputObserver.observe(input, { 
            attributes: true, 
            attributeFilter: ['value'] 
        });
    });
}

// Initialize all step cards with appropriate data-group attributes
function initializeGroupAttributes() {
    document.querySelectorAll('.step-card').forEach(card => {
        const groupInput = card.querySelector('.step-group');
        if (groupInput) {
            const groupValue = groupInput.value ? groupInput.value.trim() : '';
            card.setAttribute('data-group', groupValue);
            
            // Add a direct onchange handler
            groupInput.onchange = function() {
                const newValue = this.value ? this.value.trim() : '';
                const cardElement = this.closest('.step-card');
                if (cardElement) {
                    cardElement.setAttribute('data-group', newValue);
                    
                    // Force refresh all colors
                    updateStepCardColors();
                }
            };
        }
    });
}

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize data attributes first
    initializeGroupAttributes();
    
    // Then setup colors
    updateStepCardColors();
    setupRealTimeColorUpdates();
    
    // Handle dynamic additions to the DOM
    const stepsContainer = document.getElementById('stepsContainer');
    if (stepsContainer) {
        // Create a mutation observer to detect new steps - with optimization
        const observer = new MutationObserver(throttle(function(mutations) {
            let shouldUpdate = false;
            let newInputs = [];
            
            mutations.forEach(mutation => {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    shouldUpdate = true;
                    
                    // Find any new step-group inputs in the added nodes
                    mutation.addedNodes.forEach(node => {
                        if (node.nodeType === 1) { // Element node
                            // If it's a step card itself
                            if (node.classList && node.classList.contains('step-card')) {
                                const groupInput = node.querySelector('.step-group');
                                if (groupInput) {
                                    newInputs.push(groupInput);
                                }
                            }
                            // Or if it contains step cards (e.g., a container)
                            const childInputs = node.querySelectorAll('.step-group');
                            if (childInputs.length > 0) {
                                newInputs = [...newInputs, ...childInputs];
                            }
                        }
                    });
                }
            });
            
            if (shouldUpdate) {
                updateStepCardColors();
                
                // Observe any new step-group inputs for attribute changes
                if (newInputs.length > 0 && inputObserver) {
                    newInputs.forEach(input => {
                        inputObserver.observe(input, { 
                            attributes: true, 
                            attributeFilter: ['value'] 
                        });
                    });
                }
            }
        }, 500)); // Throttle MutationObserver callback to run at most once per 500ms
        
        // Start observing
        observer.observe(stepsContainer, { 
            childList: true,
            subtree: true
        });
    }
    
    // Also listen for the addNewStep function if it exists
    if (typeof addNewStep === 'function') {
        const originalAddNewStep = addNewStep;
        window.addNewStep = function() {
            originalAddNewStep.apply(this, arguments);
            // Update colors after a short delay to ensure the DOM is updated
            setTimeout(updateStepCardColors, 50);
        };
    }
    
    // Listen for socket events if socket.io is available - optimize socket event handlers
    if (typeof socket !== 'undefined') {
        // Use throttled event handlers for socket events
        const throttledColorUpdate = throttle(updateStepCardColors, 1000);
        
        // Update on workflow progress events
        socket.on('progress', function(data) {
            // Throttle the updates to avoid excessive updates
            throttledColorUpdate();
        });
        
        // Also update on workflow start
        socket.on('start', throttledColorUpdate);
        
        // And on workflow completion
        socket.on('complete', throttledColorUpdate);
    }
}); 