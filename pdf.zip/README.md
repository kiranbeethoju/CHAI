# No-Nitro PDF Editor - Angular Component

A PDF editor component built with Angular that allows users to load PDFs, add redactions, and save the edited document. This application uses PDF.js for rendering PDFs, Fabric.js for the drawing capabilities, and jsPDF for saving the edited documents.

## Features

- Load and view PDF files
- Free-hand drawing tool for precise redactions
- Rectangle tool for covering larger areas
- Color selection for redaction marks
- Navigation between PDF pages
- Save the edited PDF
- Interactive first-time user guide

## Integration Guide for Existing Angular Applications

### Prerequisites

- Angular (version 13+)
- Node.js (>= 14.x)
- npm (>= 6.x)

### Step 1: Install Required Dependencies

```bash
npm install pdfjs-dist@3.11.174 fabric@5.3.1 jspdf@2.5.1
```

### Step 2: Configure PDF.js Worker

Update your `angular.json` file to include the PDF.js worker files in your assets:

```json
"assets": [
  "src/favicon.ico",
  "src/assets",
  {
    "glob": "**/*",
    "input": "./node_modules/pdfjs-dist/build/",
    "output": "/assets/pdfjs/"
  }
]
```

### Step 3: Add External Libraries to index.html

Add the following scripts to your `index.html` file:

```html
<!-- PDF.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>

<!-- Fabric.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.1/fabric.min.js"></script>

<!-- jsPDF -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
```

### Step 4: Create Required Folders and Files

Create the following directory structure in your Angular project:

```
src/
├── app/
│   ├── components/
│   │   ├── pdf-editor/
│   │   │   ├── pdf-editor.component.ts
│   │   │   ├── pdf-editor.component.html
│   │   │   └── pdf-editor.component.css
│   │   └── user-guide/
│   │       ├── user-guide.component.ts
│   │       ├── user-guide.component.html
│   │       └── user-guide.component.css
│   └── services/
│       └── pdf.service.ts
```

### Step 5: Copy Component Files

Copy the provided component files to their respective folders:

1. **PDF Service**: `src/app/services/pdf.service.ts`
2. **PDF Editor Component**:
   - `src/app/components/pdf-editor/pdf-editor.component.ts`
   - `src/app/components/pdf-editor/pdf-editor.component.html`
   - `src/app/components/pdf-editor/pdf-editor.component.css`
3. **User Guide Component**:
   - `src/app/components/user-guide/user-guide.component.ts`
   - `src/app/components/user-guide/user-guide.component.html`
   - `src/app/components/user-guide/user-guide.component.css`

### Step 6: Register Components in Your Module

Add the components and service to your Angular module:

```typescript
// app.module.ts
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

// Import your existing components and modules
import { AppComponent } from './app.component';

// Import PDF Editor components and service
import { PdfEditorComponent } from './components/pdf-editor/pdf-editor.component';
import { UserGuideComponent } from './components/user-guide/user-guide.component';
import { PdfService } from './services/pdf.service';

@NgModule({
  declarations: [
    AppComponent,
    // Your existing components
    PdfEditorComponent,
    UserGuideComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    // Your existing imports
  ],
  providers: [
    // Your existing services
    PdfService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
```

### Step 7: Include Global Styles (Optional)

If you want to use the provided global styles, add the contents of the provided `styles.css` to your global styles file, or import it as needed.

### Step 8: Use the PDF Editor Component

Now you can use the PDF Editor component in your templates:

```html
<app-pdf-editor></app-pdf-editor>
```

You can wrap it in a container element to control its positioning and size:

```html
<div class="pdf-editor-container">
  <h2>PDF Editor</h2>
  <app-pdf-editor></app-pdf-editor>
</div>
```

### Step 9: Adding the User Guide Component (Optional)

If you want to include the user guide:

```html
<app-user-guide></app-user-guide>
<app-pdf-editor></app-pdf-editor>
```

## Customization Options

### Changing the Default Colors

You can modify the theme colors by editing the CSS variables in your global styles:

```css
:root {
  --primary-bg: #1a1a1a;         /* Background color */
  --secondary-bg: #2d2d2d;       /* Secondary background */
  --accent-color: #ffffff;        /* Accent color */
  --text-primary: #ffffff;        /* Primary text color */
  --text-secondary: #b3b3b3;      /* Secondary text color */
  --border-color: #404040;        /* Border color */
  --hover-color: #404040;         /* Hover state color */
  --button-active: #666666;       /* Active button color */
  --danger-color: #ff4444;        /* Accent color for important actions */
}
```

### Modifying the Tour Steps

You can customize the user guide tour steps by editing the `tourSteps` array in `user-guide.component.ts`.

## Troubleshooting

### Common Issues

1. **PDF.js Worker Not Found**: Make sure you've correctly configured the assets path in `angular.json`.

2. **Fabric.js or jsPDF not defined**: Check that the scripts are correctly loaded in your `index.html` file.

3. **Component Styling Issues**: If the component styles don't apply correctly, make sure your global styles don't conflict with the component styles.

### Type Definition Errors

If you encounter TypeScript errors related to missing types, install the following type definitions:

```bash
npm install --save-dev @types/pdfjs-dist
```

## Implementation Details

- **PDF Rendering**: Uses PDF.js to render PDF pages to a canvas
- **Drawing Tools**: Implements Fabric.js for interactive drawing and shapes
- **State Management**: Maintains the state of each page to preserve edits when navigating
- **Saving**: Uses jsPDF to create a new PDF with the edits applied

## Browser Compatibility

This component has been tested and works with:
- Chrome (latest)
- Firefox (latest)
- Edge (latest)
- Safari (latest)

## License

This project is open-source and available under the MIT License. 