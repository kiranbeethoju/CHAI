import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { PdfEditorComponent } from './components/pdf-editor/pdf-editor.component';
import { UserGuideComponent } from './components/user-guide/user-guide.component';
import { PdfService } from './services/pdf.service';

@NgModule({
  declarations: [
    AppComponent,
    PdfEditorComponent,
    UserGuideComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [PdfService],
  bootstrap: [AppComponent]
})
export class AppModule { } 