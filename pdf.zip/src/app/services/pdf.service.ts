import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

// Import types but use dynamic loading to avoid bundle size issues
import * as pdfjsLib from 'pdfjs-dist';
import { PDFDocumentProxy, PDFPageProxy } from 'pdfjs-dist';

@Injectable({
  providedIn: 'root'
})
export class PdfService {
  private pdfDocSubject = new BehaviorSubject<PDFDocumentProxy | null>(null);
  public pdfDoc$ = this.pdfDocSubject.asObservable();

  private currentPageSubject = new BehaviorSubject<number>(1);
  public currentPage$ = this.currentPageSubject.asObservable();

  private totalPagesSubject = new BehaviorSubject<number>(0);
  public totalPages$ = this.totalPagesSubject.asObservable();

  // Store page states
  private pageStates: { [pageNumber: number]: any } = {};

  constructor() {
    // Configure PDF.js worker
    const pdfjsWorkerSrc = 'assets/pdfjs/pdf.worker.min.js';
    pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorkerSrc;
  }

  /**
   * Load a PDF file
   */
  async loadPdf(file: File): Promise<void> {
    if (!file) return;

    try {
      const arrayBuffer = await file.arrayBuffer();
      const typedArray = new Uint8Array(arrayBuffer);
      const loadingTask = pdfjsLib.getDocument(typedArray);
      
      const pdfDoc = await loadingTask.promise;
      
      // Reset state
      this.pdfDocSubject.next(pdfDoc);
      this.totalPagesSubject.next(pdfDoc.numPages);
      this.currentPageSubject.next(1);
      this.pageStates = {};
      
      return Promise.resolve();
    } catch (error) {
      console.error('Error loading PDF:', error);
      return Promise.reject(error);
    }
  }

  /**
   * Get the current PDF document
   */
  getPdfDocument(): PDFDocumentProxy | null {
    return this.pdfDocSubject.value;
  }

  /**
   * Navigate to a specific page
   */
  goToPage(pageNumber: number): void {
    const totalPages = this.totalPagesSubject.value;
    
    if (pageNumber < 1) {
      pageNumber = 1;
    } else if (pageNumber > totalPages) {
      pageNumber = totalPages;
    }
    
    this.currentPageSubject.next(pageNumber);
  }

  /**
   * Go to the next page
   */
  nextPage(): void {
    const currentPage = this.currentPageSubject.value;
    const totalPages = this.totalPagesSubject.value;
    
    if (currentPage < totalPages) {
      this.currentPageSubject.next(currentPage + 1);
    }
  }

  /**
   * Go to the previous page
   */
  prevPage(): void {
    const currentPage = this.currentPageSubject.value;
    
    if (currentPage > 1) {
      this.currentPageSubject.next(currentPage - 1);
    }
  }

  /**
   * Get the current page number
   */
  getCurrentPage(): number {
    return this.currentPageSubject.value;
  }

  /**
   * Get the total number of pages
   */
  getTotalPages(): number {
    return this.totalPagesSubject.value;
  }

  /**
   * Save page state (edited content)
   */
  savePageState(pageNumber: number, state: any): void {
    this.pageStates[pageNumber] = {
      ...state,
      timestamp: Date.now()
    };
  }

  /**
   * Get saved page state
   */
  getPageState(pageNumber: number): any {
    return this.pageStates[pageNumber] || null;
  }

  /**
   * Get a specific page from the PDF
   */
  async getPage(pageNumber: number): Promise<PDFPageProxy | null> {
    const pdfDoc = this.pdfDocSubject.value;
    
    if (!pdfDoc) {
      return null;
    }
    
    try {
      return await pdfDoc.getPage(pageNumber);
    } catch (error) {
      console.error(`Error getting page ${pageNumber}:`, error);
      return null;
    }
  }
} 