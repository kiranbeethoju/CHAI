import { Component, OnInit, AfterViewInit, ElementRef, ViewChild, NgZone, OnDestroy } from '@angular/core';
import { PdfService } from '../../services/pdf.service';
import { Subscription } from 'rxjs';

// Using declare instead of import to avoid bundling issues
declare const fabric: any;
declare const jspdf: any;

@Component({
  selector: 'app-pdf-editor',
  templateUrl: './pdf-editor.component.html',
  styleUrls: ['./pdf-editor.component.css']
})
export class PdfEditorComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('pdfCanvas') pdfCanvasElement!: ElementRef;
  
  // UI state
  currentPage = 1;
  totalPages = 0;
  currentColor = '#ffffff';
  currentMode: 'free' | 'rectangle' = 'free';
  
  // Drawing state
  private canvas: any = null;
  private isDrawing = false;
  private startPoint: any = null;
  private subscriptions: Subscription[] = [];

  constructor(
    private pdfService: PdfService,
    private ngZone: NgZone
  ) {}

  ngOnInit(): void {
    // Subscribe to PDF service observables
    this.subscriptions.push(
      this.pdfService.currentPage$.subscribe(page => {
        this.currentPage = page;
      })
    );

    this.subscriptions.push(
      this.pdfService.totalPages$.subscribe(total => {
        this.totalPages = total;
      })
    );
  }

  ngAfterViewInit(): void {
    // Initialize Fabric.js canvas
    this.initializeCanvas();
    
    // Set up event listeners for the canvas
    this.setupCanvasEventListeners();
  }

  ngOnDestroy(): void {
    // Clean up subscriptions
    this.subscriptions.forEach(sub => sub.unsubscribe());
    
    // Clean up canvas
    if (this.canvas) {
      this.canvas.dispose();
    }
  }

  /**
   * Initialize the canvas with Fabric.js
   */
  private initializeCanvas(): void {
    // Create Fabric.js canvas
    this.canvas = new fabric.Canvas(this.pdfCanvasElement.nativeElement, {
      isDrawingMode: true,
      perPixelTargetFind: true,
      targetFindTolerance: 5
    });

    // Set initial canvas size
    this.canvas.setWidth(800);
    this.canvas.setHeight(1100);

    // Initialize brush
    this.canvas.freeDrawingBrush = new fabric.PencilBrush(this.canvas);
    this.canvas.freeDrawingBrush.width = 20;
    this.canvas.freeDrawingBrush.color = this.currentColor;
  }

  /**
   * Set up event listeners for the canvas
   */
  private setupCanvasEventListeners(): void {
    if (!this.canvas) return;

    // Canvas drawing events
    this.canvas.on('mouse:down', (e: any) => this.startDrawing(e));
    this.canvas.on('mouse:move', (e: any) => this.drawing(e));
    this.canvas.on('mouse:up', (e: any) => this.endDrawing(e));

    // Canvas object events
    this.canvas.on('object:modified', () => {
      setTimeout(() => this.saveCurrentPageState(), 50);
    });

    this.canvas.on('object:added', () => {
      setTimeout(() => this.saveCurrentPageState(), 50);
    });

    this.canvas.on('object:removed', () => {
      setTimeout(() => this.saveCurrentPageState(), 50);
    });

    this.canvas.on('path:created', () => {
      setTimeout(() => this.saveCurrentPageState(), 50);
    });
  }

  /**
   * Load PDF when file is selected
   */
  onFileSelected(event: Event): void {
    const fileInput = event.target as HTMLInputElement;
    if (fileInput.files && fileInput.files.length > 0) {
      this.pdfService.loadPdf(fileInput.files[0])
        .then(() => this.renderCurrentPage())
        .catch(error => console.error('Error loading PDF:', error));
    }
  }

  /**
   * Render the current page of the PDF
   */
  async renderCurrentPage(): Promise<void> {
    const pdfDoc = this.pdfService.getPdfDocument();
    if (!pdfDoc) return;

    try {
      // Save current page state before switching
      this.saveCurrentPageState();

      // Get current page
      const page = await this.pdfService.getPage(this.currentPage);
      if (!page) return;

      const viewport = page.getViewport({ scale: 1.5 });

      // Reset canvas
      if (this.canvas) {
        this.canvas.off();
        this.canvas.clear();
        this.canvas.dispose();
      }

      // Create new canvas
      this.initializeCanvas();
      this.setupCanvasEventListeners();

      // Update canvas dimensions
      this.canvas.setWidth(viewport.width);
      this.canvas.setHeight(viewport.height);

      // Create temporary canvas for PDF rendering
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = viewport.width;
      tempCanvas.height = viewport.height;

      // Render PDF page to temp canvas
      await page.render({
        canvasContext: tempCanvas.getContext('2d'),
        viewport
      }).promise;

      // Create background image from temp canvas
      const backgroundImage = new fabric.Image(tempCanvas);

      // Set background and render
      this.canvas.setBackgroundImage(backgroundImage, this.canvas.renderAll.bind(this.canvas));

      // Configure brush
      this.canvas.freeDrawingBrush = new fabric.PencilBrush(this.canvas);
      this.canvas.freeDrawingBrush.width = 20;
      this.canvas.freeDrawingBrush.color = this.currentColor;

      // Make objects deletable
      this.makeObjectsDeletable();

      // Restore any saved content for this page
      const savedState = this.pdfService.getPageState(this.currentPage);
      if (savedState && savedState.objects) {
        this.canvas.loadFromJSON(savedState.objects, () => {
          this.makeObjectsDeletable();
          this.canvas.renderAll();
        });
      }

      // Set correct drawing mode
      this.setMode(this.currentMode);
      
    } catch (error) {
      console.error(`Error rendering page ${this.currentPage}:`, error);
    }
  }

  /**
   * Navigate to the previous page
   */
  prevPage(): void {
    this.pdfService.prevPage();
    this.renderCurrentPage();
  }

  /**
   * Navigate to the next page
   */
  nextPage(): void {
    this.pdfService.nextPage();
    this.renderCurrentPage();
  }

  /**
   * Handle direct page input
   */
  onPageInputChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    const pageNumber = parseInt(input.value, 10);
    
    if (!isNaN(pageNumber)) {
      this.pdfService.goToPage(pageNumber);
      this.renderCurrentPage();
    }
  }

  /**
   * Set drawing mode (free draw or rectangle)
   */
  setMode(mode: 'free' | 'rectangle'): void {
    this.currentMode = mode;
    
    if (!this.canvas) return;
    
    this.canvas.isDrawingMode = mode === 'free';
    this.canvas.selection = mode === 'rectangle';
    
    // Update object properties
    this.canvas.forEachObject(function(obj: any) {
      obj.selectable = mode === 'rectangle';
      obj.evented = mode === 'rectangle';
    });
    
    // Update brush color
    if (mode === 'free') {
      this.canvas.freeDrawingBrush.color = this.currentColor;
    }
  }

  /**
   * Update drawing color
   */
  onColorChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.currentColor = input.value;
    
    if (this.canvas && this.canvas.freeDrawingBrush) {
      this.canvas.freeDrawingBrush.color = this.currentColor;
    }
  }

  /**
   * Start drawing (mouse down)
   */
  private startDrawing(e: any): void {
    if (!this.canvas.isDrawingMode && this.currentMode === 'rectangle') {
      this.isDrawing = true;
      this.startPoint = this.canvas.getPointer(e.e);
    }
  }

  /**
   * Continue drawing (mouse move)
   */
  private drawing(e: any): void {
    if (!this.isDrawing) return;
    
    const pointer = this.canvas.getPointer(e.e);
    
    if (this.currentMode === 'rectangle') {
      // Remove any temporary rectangle during drawing
      const activeObj = this.canvas.getActiveObject();
      if (activeObj && (activeObj as any)._tempDrawingRect) {
        this.canvas.remove(activeObj);
      }
      
      // Create new rectangle
      const rect = new fabric.Rect({
        left: Math.min(this.startPoint.x, pointer.x),
        top: Math.min(this.startPoint.y, pointer.y),
        width: Math.abs(pointer.x - this.startPoint.x),
        height: Math.abs(pointer.y - this.startPoint.y),
        fill: this.currentColor,
        selectable: true,
        evented: true,
        _tempDrawingRect: true
      });
      
      this.canvas.add(rect);
      this.canvas.setActiveObject(rect);
      this.canvas.renderAll();
    }
  }

  /**
   * End drawing (mouse up)
   */
  private endDrawing(e: any): void {
    if (this.isDrawing && this.currentMode === 'rectangle') {
      const activeObj = this.canvas.getActiveObject();
      if (activeObj) {
        // Remove the temp flag
        delete (activeObj as any)._tempDrawingRect;
        
        // Add delete control
        this.addDeleteControl(activeObj);
        this.canvas.renderAll();
        
        // Save the state
        setTimeout(() => this.saveCurrentPageState(), 100);
      }
    }
    
    this.isDrawing = false;
  }

  /**
   * Save the current page state
   */
  private saveCurrentPageState(): void {
    if (!this.canvas) return;
    
    try {
      const objects = this.canvas.getObjects();
      
      if (objects.length > 0) {
        const jsonData = this.canvas.toJSON(['deleteControl', 'selectable', 'evented', '_tempDrawingRect']);
        
        this.pdfService.savePageState(this.currentPage, {
          objects: jsonData,
          background: this.canvas.backgroundImage ? this.canvas.backgroundImage.toObject() : null,
          pageNumber: this.currentPage
        });
      } else {
        // If no objects, remove any saved state
        this.pdfService.savePageState(this.currentPage, null);
      }
    } catch (err) {
      console.error(`Error saving state for page ${this.currentPage}:`, err);
    }
  }

  /**
   * Add delete control to an object
   */
  private addDeleteControl(obj: any): void {
    if (obj.deleteControl) return;
    
    obj.deleteControl = true;
    obj.hasBorders = true;
    obj.hasControls = true;
    obj.cornerStyle = 'circle';
    obj.cornerColor = '#2196F3';
    obj.transparentCorners = false;
    
    // Add custom delete control
    obj.controls.deleteControl = new fabric.Control({
      x: 0.5,
      y: -0.5,
      offsetY: -16,
      offsetX: 16,
      cursorStyle: 'pointer',
      mouseUpHandler: (eventData: any, transform: any) => this.deleteObject(eventData, transform),
      render: (ctx: any, left: number, top: number, styleOverride: any, fabricObject: any) => 
        this.renderDeleteIcon(ctx, left, top, styleOverride, fabricObject),
      cornerSize: 24
    });
    
    // Make sure the object is selectable
    obj.set({
      borderColor: '#2196F3',
      cornerColor: '#2196F3',
      cornerSize: 8,
      transparentCorners: false,
      hasRotatingPoint: false
    });
    
    this.canvas.requestRenderAll();
  }

  /**
   * Delete object handler
   */
  private deleteObject(eventData: any, transform: any): boolean {
    const target = transform.target;
    this.canvas.remove(target);
    this.canvas.requestRenderAll();
    setTimeout(() => this.saveCurrentPageState(), 50);
    return true;
  }

  /**
   * Render the delete icon
   */
  private renderDeleteIcon(ctx: any, left: number, top: number, styleOverride: any, fabricObject: any): void {
    const size = 24;
    ctx.save();
    ctx.translate(left, top);
    
    // Draw circle background
    ctx.beginPath();
    ctx.arc(0, 0, size/2, 0, 2 * Math.PI);
    ctx.fillStyle = 'red';
    ctx.fill();
    
    // Draw X
    ctx.beginPath();
    ctx.moveTo(-size/4, -size/4);
    ctx.lineTo(size/4, size/4);
    ctx.moveTo(-size/4, size/4);
    ctx.lineTo(size/4, -size/4);
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 2;
    ctx.stroke();
    
    ctx.restore();
  }

  /**
   * Make all objects deletable
   */
  private makeObjectsDeletable(): void {
    if (!this.canvas) return;
    
    this.canvas.forEachObject(obj => {
      if (!obj.deleteControl) {
        this.addDeleteControl(obj);
      }
      
      obj.selectable = this.currentMode === 'rectangle';
      obj.evented = this.currentMode === 'rectangle';
    });
    
    this.canvas.requestRenderAll();
  }

  /**
   * Save the edited PDF
   */
  async savePDF(): Promise<void> {
    const pdfDoc = this.pdfService.getPdfDocument();
    if (!pdfDoc) {
      alert('Please load a PDF first');
      return;
    }
    
    try {
      // Save current page state
      this.saveCurrentPageState();
      
      // Remember current page
      const currentPageNum = this.currentPage;
      
      // Create new jsPDF instance
      const { jsPDF } = jspdf;
      
      // Get the first page to determine PDF dimensions
      const firstPage = await this.pdfService.getPage(1);
      if (!firstPage) return;
      
      const viewport = firstPage.getViewport({ scale: 1.0 });
      
      // Create PDF with original document's dimensions
      const pdf = new jsPDF({
        orientation: viewport.width > viewport.height ? 'landscape' : 'portrait',
        unit: 'pt',
        format: [viewport.width, viewport.height]
      });
      
      // Process each page
      for (let i = 1; i <= this.totalPages; i++) {
        // Go to the page and render it
        this.pdfService.goToPage(i);
        await this.renderCurrentPage();
        
        // Allow time for rendering
        await new Promise(resolve => setTimeout(resolve, 800));
        
        // Export the canvas to image data
        const imgData = this.canvas.toDataURL('image/png', 1.0);
        
        // Add a new page in PDF (except for the first page)
        if (i > 1) {
          pdf.addPage([viewport.width, viewport.height]);
        }
        
        // Add the image to the PDF
        pdf.addImage(imgData, 'PNG', 0, 0, viewport.width, viewport.height);
      }
      
      // Restore the original page
      this.pdfService.goToPage(currentPageNum);
      await this.renderCurrentPage();
      
      // Save the PDF
      pdf.save('edited-pdf.pdf');
      
    } catch (error) {
      console.error('Error saving PDF:', error);
      alert('Error saving PDF. Please check console for details.');
    }
  }
} 