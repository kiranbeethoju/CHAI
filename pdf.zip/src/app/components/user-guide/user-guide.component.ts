import { Component, OnInit, ElementRef, Renderer2 } from '@angular/core';

interface TourStep {
  target: string;
  title: string;
  content: string;
  position: 'top' | 'bottom' | 'left' | 'right';
  arrow: 'up' | 'down' | 'left' | 'right';
}

@Component({
  selector: 'app-user-guide',
  templateUrl: './user-guide.component.html',
  styleUrls: ['./user-guide.component.css']
})
export class UserGuideComponent implements OnInit {
  showOverlay = false;
  currentStep = 0;
  tooltips: HTMLElement[] = [];
  
  // Tour steps configuration
  tourSteps: TourStep[] = [
    {
      target: 'input[type="file"]',
      title: 'Step 1: Load a PDF',
      content: 'Click here to select and upload a PDF file from your computer.',
      position: 'bottom',
      arrow: 'up'
    },
    {
      target: '.tool-btn:first-child',
      title: 'Step 2: Free Draw Mode',
      content: 'Click and drag on the PDF to draw with free-form lines to cover text or images.',
      position: 'bottom',
      arrow: 'up'
    },
    {
      target: '.tool-btn:nth-child(2)',
      title: 'Step 3: Rectangle Mode',
      content: 'Create solid rectangular shapes to cover larger areas of content.',
      position: 'bottom',
      arrow: 'up'
    },
    {
      target: 'input[type="color"]',
      title: 'Step 4: Change Color',
      content: 'Select a color for your drawing tools. White is recommended for redactions.',
      position: 'bottom',
      arrow: 'up'
    },
    {
      target: '.pagination',
      title: 'Step 5: Navigate Pages',
      content: 'Once your PDF is loaded, use these controls to move between pages.',
      position: 'top',
      arrow: 'down'
    },
    {
      target: '.save-btn',
      title: 'Final Step: Save Your Work',
      content: 'When finished editing, click here to save your redacted PDF.',
      position: 'bottom',
      arrow: 'up'
    }
  ];

  constructor(private el: ElementRef, private renderer: Renderer2) { }

  ngOnInit(): void {
    // Check if user has seen the tour before
    const hasSeenTour = localStorage.getItem('hasSeenTour') === 'true';
    
    if (!hasSeenTour) {
      // Show the initial overlay
      this.showOverlay = true;
    }
  }

  /**
   * Start the tour
   */
  startTour(): void {
    this.showOverlay = false;
    this.currentStep = 0;
    
    // Wait for overlay to hide before showing first step
    setTimeout(() => {
      this.showTourStep(this.currentStep);
    }, 300);
  }

  /**
   * Skip the tour
   */
  skipTour(): void {
    this.showOverlay = false;
    localStorage.setItem('hasSeenTour', 'true');
    this.clearTooltips();
  }

  /**
   * Show a specific tour step
   */
  showTourStep(stepIndex: number): void {
    // Clear any existing tooltips
    this.clearTooltips();
    
    if (stepIndex >= this.tourSteps.length) {
      // Tour complete
      localStorage.setItem('hasSeenTour', 'true');
      return;
    }
    
    const step = this.tourSteps[stepIndex];
    const target = document.querySelector(step.target) as HTMLElement;
    
    if (!target) {
      // Skip this step if target doesn't exist
      this.showTourStep(stepIndex + 1);
      return;
    }
    
    // Add highlight to target
    target.classList.add('highlight');
    
    // Create tooltip
    const tooltip = this.renderer.createElement('div') as HTMLElement;
    this.renderer.addClass(tooltip, 'tooltip');
    this.renderer.addClass(tooltip, step.position);
    
    // Add arrow if specified
    if (step.arrow) {
      const arrow = this.renderer.createElement('div') as HTMLElement;
      this.renderer.addClass(arrow, 'guide-arrow');
      this.renderer.addClass(arrow, step.arrow);
      
      // Position arrow
      const targetRect = target.getBoundingClientRect();
      
      switch (step.arrow) {
        case 'up':
          this.renderer.setStyle(arrow, 'left', `${targetRect.left + targetRect.width / 2}px`);
          this.renderer.setStyle(arrow, 'top', `${targetRect.top - 30}px`);
          break;
        case 'down':
          this.renderer.setStyle(arrow, 'left', `${targetRect.left + targetRect.width / 2}px`);
          this.renderer.setStyle(arrow, 'top', `${targetRect.bottom + 10}px`);
          break;
        case 'left':
          this.renderer.setStyle(arrow, 'left', `${targetRect.left - 30}px`);
          this.renderer.setStyle(arrow, 'top', `${targetRect.top + targetRect.height / 2}px`);
          break;
        case 'right':
          this.renderer.setStyle(arrow, 'left', `${targetRect.right + 10}px`);
          this.renderer.setStyle(arrow, 'top', `${targetRect.top + targetRect.height / 2}px`);
          break;
      }
      
      this.renderer.appendChild(document.body, arrow);
      this.tooltips.push(arrow);
    }
    
    // Add content to tooltip
    tooltip.innerHTML = `
      <h3>${step.title}</h3>
      <p>${step.content}</p>
      <div class="tooltip-actions">
        <button class="tooltip-btn next">Next</button>
        <button class="tooltip-btn skip">Skip Tour</button>
      </div>
    `;
    
    this.renderer.appendChild(document.body, tooltip);
    this.tooltips.push(tooltip);
    
    // Position tooltip
    const targetRect = target.getBoundingClientRect();
    
    switch (step.position) {
      case 'top':
        this.renderer.setStyle(tooltip, 'bottom', `${window.innerHeight - targetRect.top + 15}px`);
        this.renderer.setStyle(tooltip, 'left', `${targetRect.left + targetRect.width / 2 - tooltip.offsetWidth / 2}px`);
        break;
      case 'bottom':
        this.renderer.setStyle(tooltip, 'top', `${targetRect.bottom + 15}px`);
        this.renderer.setStyle(tooltip, 'left', `${targetRect.left + targetRect.width / 2 - tooltip.offsetWidth / 2}px`);
        break;
      case 'left':
        this.renderer.setStyle(tooltip, 'right', `${window.innerWidth - targetRect.left + 15}px`);
        this.renderer.setStyle(tooltip, 'top', `${targetRect.top + targetRect.height / 2 - tooltip.offsetHeight / 2}px`);
        break;
      case 'right':
        this.renderer.setStyle(tooltip, 'left', `${targetRect.right + 15}px`);
        this.renderer.setStyle(tooltip, 'top', `${targetRect.top + targetRect.height / 2 - tooltip.offsetHeight / 2}px`);
        break;
    }
    
    // Add event listeners
    const nextBtn = tooltip.querySelector('.next') as HTMLElement;
    nextBtn.addEventListener('click', () => {
      target.classList.remove('highlight');
      this.showTourStep(stepIndex + 1);
    });
    
    const skipBtn = tooltip.querySelector('.skip') as HTMLElement;
    skipBtn.addEventListener('click', () => {
      this.clearTooltips();
      localStorage.setItem('hasSeenTour', 'true');
    });
  }

  /**
   * Clear all tooltips and highlights
   */
  clearTooltips(): void {
    // Remove all highlights
    document.querySelectorAll('.highlight').forEach(el => {
      el.classList.remove('highlight');
    });
    
    // Remove all tooltips
    this.tooltips.forEach(tooltip => {
      if (tooltip.parentNode) {
        this.renderer.removeChild(tooltip.parentNode, tooltip);
      }
    });
    
    this.tooltips = [];
  }
} 