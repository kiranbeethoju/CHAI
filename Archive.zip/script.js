// Initialize PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

// Global variables
let pdfDoc = null;
let pageNum = 1;
let canvas = null;
let currentMode = 'free';
let isDrawing = false;
let startPoint = null;
let pageStates = {};
let tourStep = 0;
let hasShownTour = false;
let tooltips = [];

// Tour steps configuration
const tourSteps = [
    {
        target: '#pdfInput',
        title: 'Step 1: Load a PDF',
        content: 'Click here to select and upload a PDF file from your computer.',
        position: 'bottom',
        arrow: 'up'
    },
    {
        target: '#freeDrawBtn',
        title: 'Step 2: Free Draw Mode',
        content: 'Click and drag on the PDF to draw with free-form lines to cover text or images.',
        position: 'bottom',
        arrow: 'up'
    },
    {
        target: '#rectangleBtn',
        title: 'Step 3: Rectangle Mode',
        content: 'Create solid rectangular shapes to cover larger areas of content.',
        position: 'bottom',
        arrow: 'up'
    },
    {
        target: '#colorPicker',
        title: 'Step 4: Change Color',
        content: 'Select a color for your drawing tools. White is recommended for redactions.',
        position: 'bottom',
        arrow: 'up'
    },
    {
        target: '.pagination',
        title: 'Step 5: Navigate Pages',
        content: 'Once your PDF is loaded, use these controls to move between pages.',
        position: 'top',
        arrow: 'down'
    },
    {
        target: '#saveBtn',
        title: 'Final Step: Save Your Work',
        content: 'When finished editing, click here to save your redacted PDF.',
        position: 'bottom',
        arrow: 'up'
    }
];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Fabric.js canvas
    canvas = new fabric.Canvas('pdfCanvas', {
        isDrawingMode: true,
        perPixelTargetFind: true,
        targetFindTolerance: 5
    });
    
    // Set initial canvas size
    canvas.setWidth(800);
    canvas.setHeight(1100);

    // Initialize brush
    canvas.freeDrawingBrush = new fabric.PencilBrush(canvas);
    canvas.freeDrawingBrush.width = 20;
    canvas.freeDrawingBrush.color = '#ffffff';

    // Event listeners for tools
    document.getElementById('freeDrawBtn').addEventListener('click', () => setMode('free'));
    document.getElementById('rectangleBtn').addEventListener('click', () => setMode('rectangle'));
    document.getElementById('colorPicker').addEventListener('input', updateColor);
    document.getElementById('pdfInput').addEventListener('change', loadPDF);
    document.getElementById('prevPage').addEventListener('click', showPrevPage);
    document.getElementById('nextPage').addEventListener('click', showNextPage);
    document.getElementById('saveBtn').addEventListener('click', savePDF);
    document.getElementById('pageInput').addEventListener('change', handlePageInputChange);

    // Canvas event listeners
    canvas.on('mouse:down', startDrawing);
    canvas.on('mouse:move', drawing);
    canvas.on('mouse:up', endDrawing);
    
    // Add object modification listeners for fabric canvas
    canvas.on('object:modified', function() {
        setTimeout(() => saveCurrentPageState(), 50);
    });
    
    canvas.on('object:added', function() {
        setTimeout(() => saveCurrentPageState(), 50);
    });
    
    canvas.on('object:removed', function() {
        setTimeout(() => saveCurrentPageState(), 50);
    });

    // Critical: Listen for path creation in free drawing
    canvas.on('path:created', function() {
        console.log("Path created, saving state");
        setTimeout(() => saveCurrentPageState(), 50);
    });
    
    // Initialize user guide if it's the first visit
    initUserGuide();
});

// User guide functionality
function initUserGuide() {
    // Check if user has seen the tour before
    hasShownTour = localStorage.getItem('hasSeenTour') === 'true';
    
    if (!hasShownTour) {
        // Show welcome overlay
        const overlay = document.getElementById('userGuideOverlay');
        overlay.classList.add('active');
        
        // Add event listeners to tour buttons
        document.getElementById('startTour').addEventListener('click', startTour);
        document.getElementById('skipTour').addEventListener('click', skipTour);
    }
}

function startTour() {
    // Hide welcome overlay
    document.getElementById('userGuideOverlay').classList.remove('active');
    
    // Start the step-by-step tour
    tourStep = 0;
    showTourStep(tourStep);
}

function skipTour() {
    // Hide overlay and mark as seen
    document.getElementById('userGuideOverlay').classList.remove('active');
    localStorage.setItem('hasSeenTour', 'true');
}

function showTourStep(stepIndex) {
    // Clear any existing tooltips
    clearTooltips();
    
    if (stepIndex >= tourSteps.length) {
        // Tour complete
        localStorage.setItem('hasSeenTour', 'true');
        return;
    }
    
    const step = tourSteps[stepIndex];
    const target = document.querySelector(step.target);
    
    if (!target) {
        // Skip this step if target element doesn't exist
        showTourStep(stepIndex + 1);
        return;
    }
    
    // Add highlight to target element
    target.classList.add('highlight');
    
    // Create tooltip
    const tooltip = document.createElement('div');
    tooltip.className = `tooltip ${step.position}`;
    
    // Add arrow if specified
    if (step.arrow) {
        const arrow = document.createElement('div');
        arrow.className = `guide-arrow ${step.arrow}`;
        document.getElementById('tooltipContainer').appendChild(arrow);
        
        // Position arrow based on target
        const targetRect = target.getBoundingClientRect();
        switch (step.arrow) {
            case 'up':
                arrow.style.left = `${targetRect.left + targetRect.width / 2}px`;
                arrow.style.top = `${targetRect.top - 30}px`;
                break;
            case 'down':
                arrow.style.left = `${targetRect.left + targetRect.width / 2}px`;
                arrow.style.top = `${targetRect.bottom + 10}px`;
                break;
            case 'left':
                arrow.style.left = `${targetRect.left - 30}px`;
                arrow.style.top = `${targetRect.top + targetRect.height / 2}px`;
                break;
            case 'right':
                arrow.style.left = `${targetRect.right + 10}px`;
                arrow.style.top = `${targetRect.top + targetRect.height / 2}px`;
                break;
        }
        
        tooltips.push(arrow);
    }
    
    // Add content to tooltip
    tooltip.innerHTML = `
        <h3>${step.title}</h3>
        <p>${step.content}</p>
        <div class="tooltip-actions">
            <button class="tooltip-btn next">Next</button>
            <button class="tooltip-btn skip">Skip Tour</button>
        </div>
    `;
    
    document.getElementById('tooltipContainer').appendChild(tooltip);
    tooltips.push(tooltip);
    
    // Position tooltip based on target
    const targetRect = target.getBoundingClientRect();
    switch (step.position) {
        case 'top':
            tooltip.style.bottom = `${window.innerHeight - targetRect.top + 15}px`;
            tooltip.style.left = `${targetRect.left + targetRect.width / 2 - tooltip.offsetWidth / 2}px`;
            break;
        case 'bottom':
            tooltip.style.top = `${targetRect.bottom + 15}px`;
            tooltip.style.left = `${targetRect.left + targetRect.width / 2 - tooltip.offsetWidth / 2}px`;
            break;
        case 'left':
            tooltip.style.right = `${window.innerWidth - targetRect.left + 15}px`;
            tooltip.style.top = `${targetRect.top + targetRect.height / 2 - tooltip.offsetHeight / 2}px`;
            break;
        case 'right':
            tooltip.style.left = `${targetRect.right + 15}px`;
            tooltip.style.top = `${targetRect.top + targetRect.height / 2 - tooltip.offsetHeight / 2}px`;
            break;
    }
    
    // Add event listeners to buttons
    tooltip.querySelector('.next').addEventListener('click', () => {
        target.classList.remove('highlight');
        showTourStep(stepIndex + 1);
    });
    
    tooltip.querySelector('.skip').addEventListener('click', () => {
        clearTooltips();
        localStorage.setItem('hasSeenTour', 'true');
    });
}

function clearTooltips() {
    // Remove all tooltips and highlights
    document.querySelectorAll('.highlight').forEach(el => {
        el.classList.remove('highlight');
    });
    
    tooltips.forEach(tooltip => {
        if (tooltip.parentNode) {
            tooltip.parentNode.removeChild(tooltip);
        }
    });
    
    tooltips = [];
}

function addDeleteControl(obj) {
    // Make sure we don't apply delete controls twice
    if (obj.deleteControl) return;
    
    obj.deleteControl = true;
    obj.hasBorders = true;
    obj.hasControls = true;
    obj.cornerStyle = 'circle';
    obj.cornerColor = '#2196F3';
    obj.transparentCorners = false;
    
    // Add custom delete control
    obj.controls.deleteControl = new fabric.Control({
        x: 0.5,
        y: -0.5,
        offsetY: -16,
        offsetX: 16,
        cursorStyle: 'pointer',
        mouseUpHandler: deleteObject,
        render: renderDeleteIcon,
        cornerSize: 24
    });

    // Make sure the object is selectable
    obj.set({
        borderColor: '#2196F3',
        cornerColor: '#2196F3',
        cornerSize: 8,
        transparentCorners: false,
        hasRotatingPoint: false // Disable rotation point since it's not needed for eraser
    });
    
    canvas.requestRenderAll();
}

function deleteObject(eventData, transform) {
    const target = transform.target;
    console.log("Delete control clicked, removing object", target);
    
    // Simply remove the object - the pointer checking was causing issues
    canvas.remove(target);
    canvas.requestRenderAll();
    
    // Save state after removal
    setTimeout(() => saveCurrentPageState(), 50);
    return true;
}

function renderDeleteIcon(ctx, left, top, styleOverride, fabricObject) {
    const size = 24;
    ctx.save();
    ctx.translate(left, top);
    
    // Draw circle background
    ctx.beginPath();
    ctx.arc(0, 0, size/2, 0, 2 * Math.PI);
    ctx.fillStyle = 'red';
    ctx.fill();
    
    // Draw X
    ctx.beginPath();
    ctx.moveTo(-size/4, -size/4);
    ctx.lineTo(size/4, size/4);
    ctx.moveTo(-size/4, size/4);
    ctx.lineTo(size/4, -size/4);
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 2;
    ctx.stroke();
    
    ctx.restore();
}

// Save current page state
function saveCurrentPageState() {
    if (!pdfDoc || !canvas) return;
    
    try {
        // Get all objects from the canvas
        const objects = canvas.getObjects();
        
        // Only save if there are actual objects on the canvas
        if (objects.length > 0) {
            // Create a deep copy of the canvas state
            const jsonData = canvas.toJSON(['deleteControl', 'selectable', 'evented', '_tempDrawingRect']);
            
            // Store the state for the current page
            pageStates[pageNum] = {
                objects: jsonData,
                background: canvas.backgroundImage ? canvas.backgroundImage.toObject() : null,
                timestamp: Date.now(),
                pageNumber: pageNum // Store page number for verification
            };
            
            console.log(`Saved state for page ${pageNum} with ${objects.length} objects`);
        } else {
            // If no objects, remove any saved state for this page
            if (pageStates[pageNum]) {
                delete pageStates[pageNum];
                console.log(`Cleared state for page ${pageNum} as it has no objects`);
            }
        }
    } catch (err) {
        console.error(`Error saving state for page ${pageNum}:`, err);
    }
}

// Restore page state - completely rewritten for reliability
async function restorePageState(num) {
    if (!pageStates[num] || !pageStates[num].objects) {
        console.log(`No state found for page ${num}`);
        return false;
    }
    
    try {
        console.log(`Restoring state for page ${num} with ${pageStates[num].objects.objects.length} objects`);
        
        // Load all objects from the saved state
        return new Promise((resolve) => {
            canvas.loadFromJSON(pageStates[num].objects, () => {
                // Add delete controls to each object
                canvas.forEachObject(obj => {
                    if (!obj.deleteControl) {
                        addDeleteControl(obj);
                    }
                    
                    // Set selection state based on current mode
                    obj.selectable = currentMode === 'rectangle';
                    obj.evented = currentMode === 'rectangle';
                });
                
                canvas.renderAll();
                resolve(true);
            });
        });
    } catch (error) {
        console.error(`Error restoring page ${num}:`, error);
        return false;
    }
}

// Load PDF file
async function loadPDF(e) {
    const file = e.target.files[0];
    if (!file) return;

    const fileReader = new FileReader();
    fileReader.onload = async function() {
        const typedarray = new Uint8Array(this.result);
        pdfDoc = await pdfjsLib.getDocument(typedarray).promise;
        document.getElementById('totalPages').textContent = pdfDoc.numPages;
        document.getElementById('pageInput').max = pdfDoc.numPages;
        pageNum = 1;
        pageStates = {}; // Reset page states when loading new PDF
        renderPage(pageNum);
    };
    fileReader.readAsArrayBuffer(file);
}

// Render PDF page - completely rewritten for reliability
async function renderPage(num) {
    try {
        console.log(`Starting to render page ${num}`);
        
        // Check if PDF is loaded
        if (!pdfDoc) {
            console.error("No PDF document loaded");
            return;
        }
        
        // Save current page state before changing pages
        saveCurrentPageState();
        
        // Get the page
        const page = await pdfDoc.getPage(num);
        const viewport = page.getViewport({ scale: 1.5 });
        
        // IMPORTANT: Clear the canvas COMPLETELY before doing anything else
        if (canvas) {
            // Unsubscribe all event handlers first
            canvas.off();
            canvas.clear();
            canvas.dispose();
        }
        
        // Create a completely new canvas instance every time
        canvas = new fabric.Canvas('pdfCanvas', {
            isDrawingMode: false, // Set drawing mode later
            perPixelTargetFind: true,
            targetFindTolerance: 5
        });
        
        // Set up fresh event listeners
        canvas.on('mouse:down', startDrawing);
        canvas.on('mouse:move', drawing);
        canvas.on('mouse:up', endDrawing);
        
        canvas.on('path:created', function() {
            console.log(`Path created on page ${num}, saving state`);
            setTimeout(() => saveCurrentPageState(), 50);
        });
        
        canvas.on('object:modified', function() {
            console.log(`Object modified on page ${num}, saving state`);
            setTimeout(() => saveCurrentPageState(), 50);
        });
        
        canvas.on('object:added', function() {
            console.log(`Object added to page ${num}, saving state`);
            setTimeout(() => saveCurrentPageState(), 50);
        });
        
        canvas.on('object:removed', function() {
            console.log(`Object removed from page ${num}, saving state`);
            setTimeout(() => saveCurrentPageState(), 50);
        });
        
        // Update canvas dimensions
        canvas.setWidth(viewport.width);
        canvas.setHeight(viewport.height);
        
        // Create temp canvas for PDF rendering
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = viewport.width;
        tempCanvas.height = viewport.height;
        
        // Render PDF to temp canvas
        await page.render({
            canvasContext: tempCanvas.getContext('2d'),
            viewport: viewport
        }).promise;
        
        // Create background image from temp canvas
        const backgroundImage = new fabric.Image(tempCanvas);
        
        // Set the background and wait for it to render
        await new Promise(resolve => {
            canvas.setBackgroundImage(backgroundImage, () => {
                canvas.renderAll();
                resolve();
            });
        });
        
        // Set the page number
        pageNum = num;
        
        // Update page input display
        document.getElementById('pageInput').value = num;
        
        // Configure brush after canvas is initialized
        canvas.freeDrawingBrush = new fabric.PencilBrush(canvas);
        canvas.freeDrawingBrush.width = 20;
        canvas.freeDrawingBrush.color = document.getElementById('colorPicker').value;
        
        // Ensure all objects are properly set up with delete controls and selection settings
        makeObjectsDeletable();
        
        // Now that the background is set, try to restore any saved content for this page
        if (pageStates[num]) {
            console.log(`Restoring saved state for page ${num} (${pageStates[num].objects.objects?.length || 0} objects)`);
            try {
                // Restore objects from saved state
                await new Promise(resolve => {
                    if (pageStates[num].objects && pageStates[num].objects.objects) {
                        canvas.loadFromJSON(pageStates[num].objects, () => {
                            // Make all objects deletable
                            makeObjectsDeletable();
                            canvas.renderAll();
                            resolve();
                        });
                    } else {
                        resolve();
                    }
                });
            } catch (err) {
                console.error(`Error restoring state for page ${num}:`, err);
            }
        } else {
            console.log(`No saved state for page ${num}, starting with clean page`);
        }
        
        // Finally, set the correct drawing mode after everything is set up
        setMode(currentMode);
        
        console.log(`Completed rendering page ${num}`);
    } catch (error) {
        console.error(`Error rendering page ${num}:`, error);
    }
}

// Navigation functions - completely rewritten for reliability
async function showPrevPage() {
    if (!pdfDoc || pageNum <= 1) return;
    
    const newPageNum = pageNum - 1;
    console.log(`Navigating from page ${pageNum} to previous page ${newPageNum}`);
    
    // Render the previous page
    await renderPage(newPageNum);
}

async function showNextPage() {
    if (!pdfDoc || pageNum >= pdfDoc.numPages) return;
    
    const newPageNum = pageNum + 1;
    console.log(`Navigating from page ${pageNum} to next page ${newPageNum}`);
    
    // Render the next page
    await renderPage(newPageNum);
}

async function handlePageInputChange(e) {
    if (!pdfDoc) return;
    
    const newPage = parseInt(e.target.value);
    if (newPage && newPage >= 1 && newPage <= pdfDoc.numPages) {
        console.log(`Direct navigation from page ${pageNum} to page ${newPage}`);
        await renderPage(newPage);
    } else {
        e.target.value = pageNum;
    }
}

// Tool mode functions
function setMode(mode) {
    currentMode = mode;
    
    // Ensure canvas is initialized
    if (!canvas) return;
    
    canvas.isDrawingMode = mode === 'free';
    
    // Enable object selection in rectangle mode
    canvas.selection = mode === 'rectangle';
    
    // Update object properties for the current mode
    canvas.forEachObject(function(obj) {
        obj.selectable = mode === 'rectangle';
        obj.evented = mode === 'rectangle';
    });
    
    // Reset active states in the UI
    document.querySelectorAll('.tool-btn').forEach(btn => btn.classList.remove('active'));
    const activeBtn = document.querySelector(`#${mode}Btn`);
    if (activeBtn) {
        activeBtn.classList.add('active');
    }
    
    // Update brush color when in free draw mode
    if (mode === 'free' && canvas.freeDrawingBrush) {
        const colorPicker = document.getElementById('colorPicker');
        if (colorPicker) {
            canvas.freeDrawingBrush.color = colorPicker.value;
        }
    }
}

function updateColor(e) {
    const color = e.target.value;
    canvas.freeDrawingBrush.color = color;
}

// Drawing functions
function startDrawing(e) {
    if (!canvas.isDrawingMode && currentMode === 'rectangle') {
        isDrawing = true;
        startPoint = canvas.getPointer(e.e);
    }
}

function drawing(e) {
    if (!isDrawing) return;
    
    const pointer = canvas.getPointer(e.e);
    
    if (currentMode === 'rectangle') {
        // Remove any temporary rectangle during drawing
        const activeObj = canvas.getActiveObject();
        if (activeObj && activeObj._tempDrawingRect) {
            canvas.remove(activeObj);
        }
        
        // Create new rectangle
        const rect = new fabric.Rect({
            left: Math.min(startPoint.x, pointer.x),
            top: Math.min(startPoint.y, pointer.y),
            width: Math.abs(pointer.x - startPoint.x),
            height: Math.abs(pointer.y - startPoint.y),
            fill: document.getElementById('colorPicker').value,
            selectable: true,
            evented: true,
            _tempDrawingRect: true // Flag to identify this object during drawing
        });
        canvas.add(rect);
        canvas.setActiveObject(rect);
        canvas.renderAll();
    }
}

function endDrawing(e) {
    if (isDrawing && currentMode === 'rectangle') {
        const activeObj = canvas.getActiveObject();
        if (activeObj) {
            // Remove the temp flag
            delete activeObj._tempDrawingRect;
            
            // Add delete control
            addDeleteControl(activeObj);
            canvas.renderAll();
            
            // Save the state after drawing is complete
            setTimeout(() => saveCurrentPageState(), 100);
        }
    }
    isDrawing = false;
}

// Undo function
async function undo() {
    if (pageStates[pageNum] && pageStates[pageNum].objects) {
        const objects = pageStates[pageNum].objects.objects || [];
        
        if (objects.length > 0) {
            // Remove the last object
            objects.pop();
            
            // Store the background image before clearing
            const backgroundImage = canvas.backgroundImage;
            
            // Clear canvas
            canvas.clear();
            
            // Restore the background image
            if (backgroundImage) {
                canvas.setBackgroundImage(backgroundImage, canvas.renderAll.bind(canvas));
            } else if (pageStates[pageNum].background) {
                await new Promise(resolve => {
                    fabric.util.enlivenObjects([pageStates[pageNum].background], function(objs) {
                        canvas.setBackgroundImage(objs[0], () => {
                            canvas.renderAll();
                            resolve();
                        });
                    });
                });
            }
            
            // Restore objects
            await new Promise(resolve => {
                canvas.loadFromJSON({objects: objects}, () => {
                    canvas.forEachObject(function(obj) {
                        if (!obj.deleteControl) {
                            addDeleteControl(obj);
                        }
                    });
                    canvas.renderAll();
                    resolve();
                });
            });
            
            // Save the updated state
            saveCurrentPageState();
        } else {
            // If no objects left, just re-render the page to ensure PDF is still displayed
            const currentPage = pageNum;
            await renderPage(currentPage);
        }
    }
}

// Save function
async function savePDF() {
    try {
        if (!pdfDoc) {
            alert("Please load a PDF first");
            return;
        }
        
        console.log("Starting PDF save process");
        
        // Save current page state before beginning
        saveCurrentPageState();
        
        // Remember current page to restore later
        const currentPageNum = pageNum;
        
        // Get the jsPDF instance
        const { jsPDF } = window.jspdf;
        
        // Get the first page to determine PDF dimensions
        const firstPage = await pdfDoc.getPage(1);
        const viewport = firstPage.getViewport({ scale: 1.0 });
        
        // Create PDF with original document's dimensions
        const pdf = new jsPDF({
            orientation: viewport.width > viewport.height ? 'landscape' : 'portrait',
            unit: 'pt',
            format: [viewport.width, viewport.height]
        });
        
        console.log(`Processing all ${pdfDoc.numPages} pages with dimensions: ${viewport.width}x${viewport.height}`);
        
        // Process each page
        for (let i = 1; i <= pdfDoc.numPages; i++) {
            console.log(`Processing page ${i} of ${pdfDoc.numPages}`);
            
            // Render the current page with its modifications
            await renderPage(i);
            
            // Allow time for all canvas operations to complete
            await new Promise(resolve => setTimeout(resolve, 800));
            
            // Export the canvas to image data - use high quality
            const imgData = canvas.toDataURL('image/png', 1.0);
            
            // Add a new page in PDF (except for the first page)
            if (i > 1) {
                // For consistency, create each page with the same dimensions
                pdf.addPage([viewport.width, viewport.height]);
            }
            
            // Add the image to the PDF at full size without scaling
            pdf.addImage(imgData, 'PNG', 0, 0, viewport.width, viewport.height);
            
            console.log(`Page ${i} added to PDF at original size`);
        }
        
        // Restore the original page the user was on
        console.log(`Restoring to page ${currentPageNum}`);
        await renderPage(currentPageNum);
        
        // Save the PDF
        pdf.save('edited-pdf.pdf');
        console.log("PDF saved successfully");
    } catch (error) {
        console.error("Error saving PDF:", error);
        alert("Error saving PDF. Please check console for details.");
    }
}

// Ensure all objects are properly set up with delete controls and selection settings
function makeObjectsDeletable() {
    canvas.forEachObject(obj => {
        // Add delete controls if not already present
        if (!obj.deleteControl) {
            addDeleteControl(obj);
        }
        
        // Make sure selection settings are correct
        obj.selectable = currentMode === 'rectangle';
        obj.evented = currentMode === 'rectangle';
    });
    
    canvas.requestRenderAll();
} 