from typing import Dict, Any, List
from loguru import logger
from pydantic import BaseModel

class UseCase(BaseModel):
    name: str
    steps: List[Dict[str, Any]]
    rules: Dict[str, Any]
    clinical_note: str

class Agent:
    def __init__(self, llm_service):
        self.llm_service = llm_service
        logger.info(f"Initializing {self.__class__.__name__}")

    async def process(self, input_data: Any) -> Any:
        raise NotImplementedError

class UseCaseValidator(Agent):
    async def process(self, usecase: UseCase) -> bool:
        prompt = f"""
        Validate the following usecase:
        Name: {usecase.name}
        Steps: {usecase.steps}
        Rules: {usecase.rules}
        Clinical Note: {usecase.clinical_note}
        """
        try:
            validation_result = await self.llm_service.generate_response(prompt)
            return "VALID" in validation_result.upper()
        except Exception as e:
            logger.error(f"Error validating usecase: {str(e)}")
            return False

class StepExecutor(Agent):
    async def process(self, step: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        prompt = f"""
        Execute the following step:
        Step: {step}
        Context: {context}
        """
        try:
            result = await self.llm_service.generate_response(prompt)
            return {"result": result, "status": "success"}
        except Exception as e:
            logger.error(f"Error executing step: {str(e)}")
            return {"result": None, "status": "error", "error": str(e)}

class ResultValidator(Agent):
    async def process(self, result: Dict[str, Any], rules: Dict[str, Any]) -> bool:
        return await self.llm_service.validate_response(result.get("result", ""), rules)

class WorkflowManager:
    def __init__(self, llm_service):
        self.llm_service = llm_service
        self.use_case_validator = UseCaseValidator(llm_service)
        self.step_executor = StepExecutor(llm_service)
        self.result_validator = ResultValidator(llm_service)
        logger.info("Initializing WorkflowManager")

    async def execute_workflow(self, usecase: UseCase) -> Dict[str, Any]:
        # Validate usecase
        if not await self.use_case_validator.process(usecase):
            raise ValueError("Invalid usecase")

        context = {"clinical_note": usecase.clinical_note}
        results = []

        # Execute each step
        for step in usecase.steps:
            step_result = await self.step_executor.process(step, context)
            results.append(step_result)
            context.update(step_result)

        # Validate final result
        final_result = results[-1]
        if not await self.result_validator.process(final_result, usecase.rules):
            raise ValueError("Final result validation failed")

        return {
            "status": "success",
            "results": results,
            "final_result": final_result
        } 