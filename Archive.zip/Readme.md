# Agent Workflow Orchestration Framework

## Overview

The Agent Workflow Orchestration Framework is a powerful system for creating and executing multi-step, parallel AI agent workflows. It provides a visual interface for defining complex task sequences, managing dependencies between steps, and running parallel operations using large language models (LLMs).

## How It Works

### Core Components

1. **Workflow Configuration Interface**: A visual UI where users define a sequence of steps, their dependencies, and execution parameters.

2. **Parallel Group System**: Steps can be grouped to run in parallel for efficiency, with visual color-coding to track related steps.

3. **Agent Execution Engine**: The backend that coordinates the execution of steps, manages dependencies, and processes results.

4. **Results Visualization**: Real-time display of execution progress and results that match the color scheme of their source steps.

### Step-by-Step Workflow

1. **Define the Workflow**:
   - Create a workflow with a name and an optional clinical note (or other context)
   - Add individual steps with descriptions, prompts, and dependencies
   - Organize related steps into parallel groups using the group field
   - Set validation rules for ensuring quality output

2. **Configure Step Parameters**:
   - **Step ID**: Unique identifier for referencing in dependencies
   - **Description**: High-level purpose of the step
   - **Prompt**: Detailed instructions for the LLM
   - **Dependencies**: Steps that must complete before this step runs
   - **Parallel Group**: Optional group name for concurrent execution
   - **Original Note**: Option to include the original clinical note in the context

3. **Execute the Workflow**:
   - Click "Start Workflow" to begin execution
   - The system validates the workflow configuration
   - Steps execute in the correct order based on dependencies
   - Parallel groups execute concurrently for efficiency
   - Progress is displayed in real-time

4. **View Results**:
   - Each step's output appears in the Results panel
   - Results cards are color-coded to match their source step's group
   - JSON outputs are formatted with syntax highlighting
   - Execution logs provide detailed information about the process

## Color Coding System

The framework uses a color-coding system to help visualize relationships between steps:

- **Group 1**: Light blue background (#E6F7FF)
- **Group 2**: Light green background (#F0F9EB)
- **Group 3**: Light orange background (#FFF7E6)

Steps in the same parallel group share the same color, and their result cards match this color scheme. This visual connection helps users understand which results came from which step groups.

## Example Workflow: Dinner Preparation

Let's consider a simple dinner preparation workflow to illustrate how the system works.

### Workflow Name: Family Dinner Preparation

**Original Note:**
"We need to prepare a dinner for 4 people tonight. We have rice, vegetables, chicken, and spices available. We need to serve dinner by 7 PM."

### Steps:

#### Step 1: Rice Cooking Plan (Group: "preparation")
- **Description**: Plan rice cooking process
- **Prompt**: Given the available ingredients, create a detailed plan for cooking rice. Return JSON format: {"ingredients": ["rice", "water"], "cookingTime": "20 minutes", "instructions": ["step1", "step2"]}
- **Dependencies**: None
- **Parallel Group**: preparation

#### Step 2: Curry Cooking Plan (Group: "preparation")
- **Description**: Plan curry cooking process
- **Prompt**: Create a detailed plan for making chicken curry with vegetables. Return JSON format: {"ingredients": ["chicken", "vegetables", "spices"], "cookingTime": "30 minutes", "instructions": ["step1", "step2"]}
- **Dependencies**: None
- **Parallel Group**: preparation

#### Step 3: Rice Execution (Group: "cooking")
- **Description**: Execute rice cooking
- **Prompt**: Follow the rice cooking plan and report on execution. Return JSON format: {"status": "complete", "notes": "any cooking observations", "finishTime": "time completed"}
- **Dependencies**: step1
- **Parallel Group**: cooking

#### Step 4: Curry Execution (Group: "cooking")
- **Description**: Execute curry cooking
- **Prompt**: Follow the curry cooking plan and report on execution. Return JSON format: {"status": "complete", "notes": "any cooking observations", "finishTime": "time completed"}
- **Dependencies**: step2
- **Parallel Group**: cooking

#### Step 5: Dinner Serving
- **Description**: Prepare dinner table and serve food
- **Prompt**: Based on the completed cooking tasks, create a serving plan for the dinner table. Return JSON format: {"tableSetup": ["plates", "cutlery"], "servingOrder": ["rice first", "curry second"], "presentationNotes": "garnish suggestions"}
- **Dependencies**: step3, step4
- **Parallel Group**: None (sequential)

### Workflow Execution

1. **Initial Planning (Parallel)**: 
   - Step 1 (Rice Planning) and Step 2 (Curry Planning) execute simultaneously
   - Both steps are colored light blue (Group: "preparation")
   - Results appear as light blue cards in the Results panel

2. **Cooking Phase (Parallel)**:
   - After planning is complete, Step 3 (Rice Execution) and Step 4 (Curry Execution) run concurrently
   - Both steps are colored light green (Group: "cooking")
   - Results appear as light green cards in the Results panel

3. **Final Serving (Sequential)**:
   - After both cooking steps complete, Step 5 (Dinner Serving) executes
   - This step has no color group as it runs sequentially
   - The result appears in the default card color

4. **Final Outcome**:
   - All results are visible in the browser
   - We can see the entire process from planning to serving
   - Color-coding makes it easy to identify which results belong to which phase

### Parallel Group Benefits

This workflow demonstrates the power of parallel grouping:
- Planning steps run concurrently, saving time
- Cooking steps execute in parallel once their dependencies (planning) are complete
- The final serving step waits for all cooking to finish before executing
- The color scheme visually connects related steps and their outputs

## Best Practices

1. **Group Design**: Create logical parallel groups for tasks that can run simultaneously
   - Use clear, descriptive group names
   - Group related steps that don't depend on each other

2. **Dependencies**: Carefully define step dependencies to ensure proper execution order
   - Make sure parallel steps don't have circular dependencies
   - Consider data flow between steps when setting dependencies

3. **Prompt Design**: Write clear prompts with specific output formats
   - Use JSON format for structured outputs
   - Include examples in prompts when possible

4. **Validation**: Set validation rules to ensure quality outputs
   - Define required fields
   - Specify expected data types

## Advanced Features

- **Validation Rules**: Define validation criteria for each step's output
- **Error Handling**: Automatic error detection and reporting
- **Progress Tracking**: Real-time progress visualization
- **Result Formatting**: Automatic JSON formatting and syntax highlighting

---

This framework provides a powerful way to orchestrate complex, multi-step AI agent workflows with visual feedback and parallel execution capabilities. The color-coding system makes it easy to understand the relationships between steps and their outputs, while the dependency system ensures that steps execute in the correct order.
