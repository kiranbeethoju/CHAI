function getWorkflowConfig() {
    try {
        const name = document.getElementById('workflow_name').value;
        const clinical_note = document.getElementById('clinical_note').value;
        const steps = [];
        
        // Get all step containers
        document.querySelectorAll('.step-container').forEach((stepContainer, index) => {
            const stepId = `step${index + 1}`;
            const description = stepContainer.querySelector('.step-description').value;
            const prompt = stepContainer.querySelector('.step-prompt').value;
            
            // Safely parse dependencies
            let dependencies = [];
            try {
                const depsInput = stepContainer.querySelector('.step-dependencies').value;
                if (depsInput.trim()) {
                    // Handle both comma-separated strings and JSON arrays
                    dependencies = depsInput.includes('[') ? 
                        JSON.parse(depsInput) : 
                        depsInput.split(',').map(d => d.trim());
                }
            } catch (depError) {
                throw new Error(`Invalid dependencies format for ${stepId}: Please use comma-separated values or valid JSON array`);
            }

            // Safely parse validation fields
            let validation = {};
            try {
                const validationInput = stepContainer.querySelector('.step-validation').value;
                if (validationInput.trim()) {
                    validation = JSON.parse(validationInput);
                }
            } catch (validationError) {
                throw new Error(`Invalid validation format for ${stepId}: Please use valid JSON format`);
            }

            steps.push({
                id: stepId,
                description: description,
                prompt: prompt,
                dependencies: dependencies,
                validation: validation,
                include_clinical_note: stepContainer.querySelector('.include-clinical-note').checked
            });
        });

        return {
            name: name,
            clinical_note: clinical_note,
            steps: steps
        };
    } catch (error) {
        showNotification(error.message, 'error');
        return null;
    }
}

function startWorkflow() {
    const config = getWorkflowConfig();
    if (!config) {
        return; // Error already shown in notification
    }

    const workflow_id = generateWorkflowId();
    
    // Disable start button and enable stop button
    document.getElementById('start-btn').disabled = true;
    document.getElementById('stop-btn').disabled = false;
    
    // Clear previous logs
    clearLogs();
    
    // Start the workflow
    socket.emit('start_workflow', {
        workflow_id: workflow_id,
        config: config
    });
}

// Add this helper function for notifications
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-message">${message}</span>
            <button class="close-btn" onclick="this.parentElement.parentElement.remove()">&times;</button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
} 