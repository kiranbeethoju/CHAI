let workflowRunning = false;
let workflowSocket = null;

// Add a global variable to track completed steps
let completedSteps = new Set();

// Add template workflows for different domains
const templateWorkflows = {
    "clinical_diagnosis": {
        name: "Clinical Diagnosis Workflow",
        clinicalNote: "Patient presents with severe headache lasting for 3 days, accompanied by nausea and sensitivity to light. Medical history includes hypertension and is currently on lisinopril. Patient has known allergies to penicillin.",
        steps: [
            {
                id: 'step1',
                description: 'Extract Patient Symptoms',
                prompt: 'Given the clinical note, extract all symptoms mentioned. Return in JSON format: {"symptoms": ["headache", "nausea"], "duration": "3 days", "severity": "severe"}',
                dependencies: [],
                parallel_group: 'group1',
                include_clinical_note: true,
                rules: {
                    required_fields: ['symptoms', 'duration', 'severity'],
                    validation_rules: {
                        symptoms: 'array',
                        duration: 'string',
                        severity: 'string'
                    }
                }
            },
            {
                id: 'step2',
                description: 'Extract Medical History',
                prompt: 'Extract patient medical history from the clinical note. Return in JSON format: {"previous_conditions": ["hypertension"], "medications": ["lisinopril"], "allergies": ["penicillin"]}',
                dependencies: [],
                parallel_group: 'group1',
                include_clinical_note: true,
                rules: {
                    required_fields: ['previous_conditions', 'medications', 'allergies'],
                    validation_rules: {
                        previous_conditions: 'array',
                        medications: 'array',
                        allergies: 'array'
                    }
                }
            },
            {
                id: 'step3',
                description: 'Generate Diagnosis',
                prompt: 'Based on the symptoms and medical history, generate a diagnosis. Return in JSON format: {"diagnosis": "Migraine", "confidence": 0.85, "recommended_tests": ["MRI", "Blood Test"]}',
                dependencies: ['step1', 'step2'],
                parallel_group: 'group2',
                include_clinical_note: true,
                rules: {
                    required_fields: ['diagnosis', 'confidence', 'recommended_tests'],
                    validation_rules: {
                        diagnosis: 'string',
                        confidence: 'number',
                        recommended_tests: 'array'
                    }
                }
            }
        ]
    },
    "legal_document_analysis": {
        name: "Legal Document Analysis Workflow",
        clinicalNote: "AGREEMENT OF PURCHASE AND SALE between John Smith (Buyer) and Jane Doe (Seller) for the property at 123 Main Street. Purchase price: $500,000. Closing date: December 15, 2023. Contingent on home inspection. Deposit of $25,000 to be paid within 3 business days. Both parties agree to the terms and conditions set forth in this agreement.",
        steps: [
            {
                id: 'step1',
                description: 'Extract Parties',
                prompt: 'Extract the parties involved in this legal document. Return in JSON format: {"buyers": ["John Smith"], "sellers": ["Jane Doe"]}',
                dependencies: [],
                parallel_group: 'extraction',
                include_clinical_note: true,
                rules: {
                    required_fields: ['buyers', 'sellers'],
                    validation_rules: {
                        buyers: 'array',
                        sellers: 'array'
                    }
                }
            },
            {
                id: 'step2',
                description: 'Extract Property Details',
                prompt: 'Extract details about the property in this agreement. Return in JSON format: {"address": "123 Main Street", "purchase_price": 500000}',
                dependencies: [],
                parallel_group: 'extraction',
                include_clinical_note: true,
                rules: {
                    required_fields: ['address', 'purchase_price'],
                    validation_rules: {
                        address: 'string',
                        purchase_price: 'number'
                    }
                }
            },
            {
                id: 'step3',
                description: 'Extract Key Dates',
                prompt: 'Extract important dates from the agreement. Return in JSON format: {"closing_date": "2023-12-15", "deposit_due": "within 3 business days"}',
                dependencies: [],
                parallel_group: 'extraction',
                include_clinical_note: true,
                rules: {
                    required_fields: ['closing_date'],
                    validation_rules: {
                        closing_date: 'string'
                    }
                }
            },
            {
                id: 'step4',
                description: 'Identify Contingencies',
                prompt: 'Identify any contingencies in the agreement. Return in JSON format: {"contingencies": ["home inspection"]}',
                dependencies: [],
                parallel_group: 'extraction',
                include_clinical_note: true,
                rules: {
                    required_fields: ['contingencies'],
                    validation_rules: {
                        contingencies: 'array'
                    }
                }
            },
            {
                id: 'step5',
                description: 'Generate Summary',
                prompt: 'Based on the extracted information, generate a summary of the agreement. Return in JSON format: {"summary": "This is an agreement between...", "key_points": ["Purchase price is $500,000", "Closing on December 15, 2023"], "risks": ["Contingent on home inspection"]}',
                dependencies: ['step1', 'step2', 'step3', 'step4'],
                parallel_group: 'analysis',
                include_clinical_note: true,
                rules: {
                    required_fields: ['summary', 'key_points', 'risks'],
                    validation_rules: {
                        summary: 'string',
                        key_points: 'array',
                        risks: 'array'
                    }
                }
            }
        ]
    },
    "customer_service": {
        name: "Customer Support Workflow",
        clinicalNote: "Customer contacted support about their recent order #12345. They received the package yesterday but the product was damaged during shipping. This is their first time contacting support and they're requesting either a refund or a replacement. The customer has been with us for 2 years and has made 12 previous purchases with no issues.",
        steps: [
            {
                id: 'step1',
                description: 'Extract Customer Information',
                prompt: 'Extract customer information from the note. Return in JSON format: {"order_number": "12345", "customer_tenure": "2 years", "previous_purchases": 12, "previous_issues": 0}',
                dependencies: [],
                parallel_group: 'information',
                include_clinical_note: true,
                rules: {
                    required_fields: ['order_number', 'customer_tenure'],
                    validation_rules: {
                        order_number: 'string',
                        customer_tenure: 'string'
                    }
                }
            },
            {
                id: 'step2',
                description: 'Identify Issue Type',
                prompt: 'Identify the type of issue the customer is reporting. Return in JSON format: {"issue_type": "damaged product", "issue_category": "shipping damage", "customer_request": ["refund", "replacement"]}',
                dependencies: [],
                parallel_group: 'information',
                include_clinical_note: true,
                rules: {
                    required_fields: ['issue_type', 'issue_category', 'customer_request'],
                    validation_rules: {
                        issue_type: 'string',
                        issue_category: 'string',
                        customer_request: 'array'
                    }
                }
            },
            {
                id: 'step3',
                description: 'Generate Response',
                prompt: 'Based on the customer information and issue, generate an appropriate response. Return in JSON format: {"greeting": "Dear valued customer", "acknowledgment": "We\'re sorry to hear about the damaged product", "solution": "We will send a replacement immediately", "next_steps": ["Replacement will be shipped within 24 hours", "No need to return the damaged item"]}',
                dependencies: ['step1', 'step2'],
                parallel_group: 'response',
                include_clinical_note: true,
                rules: {
                    required_fields: ['greeting', 'acknowledgment', 'solution', 'next_steps'],
                    validation_rules: {
                        greeting: 'string',
                        acknowledgment: 'string',
                        solution: 'string',
                        next_steps: 'array'
                    }
                }
            }
        ]
    },
    "empty": {
        name: "",
        clinicalNote: "",
        steps: []
    }
};

// Replace the sampleSteps variable with the clinical diagnosis template
const sampleSteps = templateWorkflows.clinical_diagnosis.steps;

// Function to create a new step with data
function createStepWithData(stepData) {
    const template = document.getElementById('stepTemplate');
    const stepCard = template.content.cloneNode(true);
    const stepsContainer = document.getElementById('stepsContainer');
    
    // Fill in the step data
    const card = stepCard.querySelector('.step-card');
    card.dataset.stepId = stepData.id;
    
    // Set the parallel group as a data attribute for CSS targeting
    if (stepData.parallel_group) {
        card.dataset.group = stepData.parallel_group;
    }
    
    const inputs = {
        '.step-id': stepData.id,
        '.step-description': stepData.description,
        '.step-prompt': stepData.prompt,
        '.step-dependencies': stepData.dependencies.join(', '),
        '.step-group': stepData.parallel_group,
        '.step-rules': JSON.stringify(stepData.rules, null, 2),
        '.step-include-note': stepData.include_clinical_note
    };
    
    // Set values for all inputs
    Object.entries(inputs).forEach(([selector, value]) => {
        const element = card.querySelector(selector);
        if (element) {
            element.value = value;
            // Enable all fields except step ID
            element.disabled = selector === '.step-id';
        }
    });
    
    // Make sure clinical note status is properly updated based on include_clinical_note value
    const includeNote = stepData.include_clinical_note;
    if (includeNote) {
        // Update the status display and button
        const statusDiv = card.querySelector('.clinical-note-status');
        const toggleButton = card.querySelector('.btn-outline-primary');
        if (statusDiv && toggleButton) {
            statusDiv.style.display = 'block';
            toggleButton.classList.add('active');
            toggleButton.innerHTML = '<i class="bi bi-file-text"></i> Remove Original Note';
        }
    }
    
    stepsContainer.appendChild(stepCard);
    return card;
}

// Initialize UI with sample data
document.addEventListener('DOMContentLoaded', () => {
    // Template selector is already in HTML - don't create a duplicate one
    
    // Add event listener for template selection
    const selector = document.getElementById('templateSelector');
    selector.addEventListener('change', loadTemplate);
    
    // Initialize empty workflow (don't pre-select any template)
    const emptyOption = { target: { value: 'empty' } };
    loadTemplate(emptyOption);
    
    setupDragAndDrop();
    addClearButton();
});

// Function to load a template
function loadTemplate(event) {
    const templateName = event.target.value;
    const template = templateWorkflows[templateName];
    
    // Set the use case name and clinical note
    document.getElementById('useCaseName').value = template.name;
    document.getElementById('clinicalNote').value = template.clinicalNote;
    
    // Clear existing steps
    const stepsContainer = document.getElementById('stepsContainer');
    stepsContainer.innerHTML = '';
    
    // Add template steps if any
    if (template.steps && template.steps.length > 0) {
        template.steps.forEach(stepData => {
            createStepWithData(stepData);
        });
    }
    
    // Update dependency options
    updateDependencyOptions();
    
    // Update step card colors
    if (typeof updateStepCardColors === 'function') {
        setTimeout(updateStepCardColors, 50);
    }
}

// Function to add new blank step
function addNewStep() {
    const template = document.getElementById('stepTemplate');
    const stepCard = template.content.cloneNode(true);
    const stepsContainer = document.getElementById('stepsContainer');
    const stepId = `step${stepsContainer.children.length + 1}`;
    
    stepCard.querySelector('.step-card').dataset.stepId = stepId;
    stepCard.querySelector('.step-id').value = stepId;
    stepCard.querySelector('.step-title').textContent = `Step ${stepId}`;
    
    // Initialize with empty data-group
    stepCard.querySelector('.step-card').dataset.group = '';
    
    stepsContainer.appendChild(stepCard);
    updateDependencyOptions();
    
    // Set up group color handling for the new step
    if (typeof updateStepCardColors === 'function') {
        setTimeout(updateStepCardColors, 50);
    }
    
    return stepsContainer.lastElementChild;
}

// Remove step from workflow
function removeStep(button) {
    const stepCard = button.closest('.step-card');
    stepCard.remove();
    updateDependencyOptions();
}

// Edit step configuration
function editStep(button) {
    const stepCard = button.closest('.step-card');
    const inputs = stepCard.querySelectorAll('input, textarea');
    inputs.forEach(input => input.disabled = !input.disabled);
}

// Update dependency options for all steps
function updateDependencyOptions() {
    const stepElements = document.querySelectorAll('.step-card');
    const stepIds = Array.from(stepElements).map(el => el.getAttribute('data-step-id'));
    
    // Update each step's dependency dropdown
    stepElements.forEach(stepEl => {
        const stepId = stepEl.getAttribute('data-step-id');
        const dependencySelect = stepEl.querySelector('.step-dependencies');
        
        if (!dependencySelect) return;
        
        // Clear current options
        dependencySelect.innerHTML = '';
        
        // Add available steps as options (excluding the current step)
        stepIds.filter(id => id !== stepId).forEach(id => {
            const option = document.createElement('option');
            option.value = id;
            option.textContent = `Step ${id}`;
            dependencySelect.appendChild(option);
        });
        
        // If the step already has dependencies, select them
        const currentDependencies = Array.from(stepEl.querySelectorAll('.selected-dependency'))
            .map(depEl => depEl.getAttribute('data-dependency-id'));
        
        // Select the dependencies in the dropdown
        if (dependencySelect.multiple) {
            currentDependencies.forEach(depId => {
                const option = dependencySelect.querySelector(`option[value="${depId}"]`);
                if (option) option.selected = true;
            });
        }
    });
    
    // Make sure start button is not disabled when dependencies are updated
    const startButton = document.getElementById('startButton');
    if (startButton && startButton.disabled && !workflowRunning) {
        startButton.disabled = false;
    }
}

// Update the event handlers
function handleLogMessage(data) {
    const { level, message } = data;
    addLog(level, message);
}

function handleProgressUpdate(data) {
    try {
        // Safely extract progress data, handling different data structures
        let completed = 0;
        let total = 0;
        
        if (data && data.data) {
            // Standard format: { data: { completed_steps: x, total_steps: y } }
            completed = data.data.completed_steps || 0;
            total = data.data.total_steps || 0;
        } else if (data) {
            // Direct format: { completed_steps: x, total_steps: y }
            completed = data.completed_steps || 0;
            total = data.total_steps || 0;
        }
        
        // If total is still 0, try to get it from the UI
        if (total === 0) {
            total = document.querySelectorAll('.step-card').length;
        }
        
        // Make sure we don't have invalid values
        if (completed > total) {
            completed = total;
        }
        
        // Log progress update for debugging
        console.log(`Progress update: ${completed}/${total}`);
        
        // Update UI
        updateProgress({
            completed_steps: completed,
            total_steps: total
        });
    } catch (error) {
        console.error("Error handling progress update:", error);
    }
}

// Function to handle a step result and update the completed steps tracking
function handleStepResult(data) {
    const { step_id, data: resultData } = data;
    
    // Add this step to the completed steps set
    completedSteps.add(step_id);
    
    // Update progress indicators based on completed steps
    const totalSteps = document.querySelectorAll('.step-card').length;
    updateProgress({
        completed_steps: completedSteps.size,
        total_steps: totalSteps
    });
    
    // Add the result to the UI
    addStepResult(step_id, resultData);
    
    // Log for debugging
    console.log(`Step ${step_id} completed. Progress: ${completedSteps.size}/${totalSteps}`);
}

function handleWorkflowComplete(data) {
    workflowRunning = false;
    updateUIState(false);
    
    // Get the total steps count from the steps container
    const totalSteps = document.querySelectorAll('.step-card').length;
    
    // Ensure the progress indicators show completion
    updateProgress({
        completed_steps: totalSteps,
        total_steps: totalSteps
    });
    
    if (data.status === 'error') {
        addLog('error', data.message);
    } else {
        addLog('info', 'Workflow completed successfully');
    }
}

// Function to clear all results, logs, and progress
function clearAllResults() {
    // Clear results container
    const resultsContainer = document.getElementById('resultsContainer');
    resultsContainer.innerHTML = '';
    
    // Clear logs
    const logContainer = document.getElementById('logContainer');
    logContainer.innerHTML = '';
    
    // Reset progress
    const progressBar = document.getElementById('workflowProgress');
    progressBar.style.width = '0%';
    document.getElementById('completedSteps').textContent = '0';
    document.getElementById('totalSteps').textContent = '0';
    
    // Reset completed steps tracking
    completedSteps.clear();
}

// Add a throttle function at the top of the file
// Throttle function to limit how often a function can be called
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Modify startWorkflow function to properly handle button state
function startWorkflow() {
    // Ensure UI is in correct state before starting
    if (workflowRunning) {
        addLog('warning', 'Workflow is already running');
        return;
    }
    
    // Re-enable the start button in case it was disabled
    document.getElementById('startButton').disabled = false;
    
    const config = getWorkflowConfig();
    if (!validateConfig(config)) {
        addLog('error', 'Invalid workflow configuration. Please fix errors and try again.');
        return;
    }

    // Clear all previous results, logs, and progress
    clearAllResults();
    
    // Get the current LLM provider
    const providerSelect = document.getElementById('llmProvider');
    const provider = providerSelect ? providerSelect.value : 'unknown';
    
    // Add LLM provider info to the workflow configuration
    config.llm_provider = provider;
    
    // Only connect to the socket when explicitly starting a workflow
    workflowSocket = io({
        autoConnect: false, // Prevent automatic connection
        reconnection: false // Don't reconnect automatically
    });
    
    // Connect to socket only when explicitly starting a workflow
    workflowSocket.connect();
    
    workflowSocket.on('connect', () => {
        console.log('Socket connected');
        workflowRunning = true;
        updateUIState(true);
        
        // Add initial log
        addLog('info', 'Starting workflow...');
        
        // Add LLM provider info to the logs
        const providerName = getProviderDisplayName(provider);
        addLog('info', `Using LLM provider: ${providerName}`);
        
        // Generate unique workflow ID
        const workflow_id = 'workflow-' + Date.now();
        
        // Throttle step color updates - only refresh once before starting workflow
        if (typeof updateStepCardColors === 'function') {
            updateStepCardColors();
        }
        
        workflowSocket.emit('start_workflow', {
            workflow_id: workflow_id,
            config: config
        });
    });
    
    // Set up event listeners with throttling
    const throttledProgressUpdate = throttle(handleProgressUpdate, 500); // Limit to once per 500ms
    const throttledUpdateStepColors = throttle(function() {
        if (typeof updateStepCardColors === 'function') {
            updateStepCardColors();
        }
    }, 1000); // Limit to once per 1000ms
    
    // Use the throttled handlers for frequent events
    workflowSocket.on('log', handleLogMessage);
    workflowSocket.on('progress', throttledProgressUpdate);
    workflowSocket.on('result', handleStepResult);
    workflowSocket.on('complete', function(data) {
        handleWorkflowComplete(data);
        // Make sure start button is enabled when workflow completes
        document.getElementById('startButton').disabled = false;
        
        // Disconnect socket when workflow completes
        if (workflowSocket) {
            workflowSocket.disconnect();
        }
    });
    
    // Ensure error handling doesn't leave UI in bad state
    workflowSocket.on('connect_error', (error) => {
        addLog('error', `Connection error: ${error.message}`);
        workflowRunning = false;
        updateUIState(false);
        document.getElementById('startButton').disabled = false;
        
        // Disconnect socket on error
        if (workflowSocket) {
            workflowSocket.disconnect();
        }
    });
}

// Stop workflow execution
function stopWorkflow() {
    if (!workflowRunning || !workflowSocket) return;
    
    workflowSocket.send(JSON.stringify({
        type: 'stop'
    }));
}

// Function to get the current workflow configuration
function getWorkflowConfig() {
    const name = document.getElementById('useCaseName').value;
    const clinical_note = document.getElementById('clinicalNote').value;
    
    const steps = [];
    const stepCards = document.querySelectorAll('.step-card');
    
    try {
        // Process each step card
        stepCards.forEach(stepCard => {
            const id = stepCard.querySelector('.step-id').value;
            const description = stepCard.querySelector('.step-description').value;
            const prompt = stepCard.querySelector('.step-prompt').value;
            
            // Properly parse the include_clinical_note boolean value from the hidden input
            const includeNoteInput = stepCard.querySelector('.step-include-note');
            const includeNote = includeNoteInput ? (includeNoteInput.value === 'true') : false;
            
            const parallel_group = stepCard.querySelector('.step-group').value.trim();
            
            // Parse dependencies - handle both old and new format
            let dependencies = [];
            const depsInput = stepCard.querySelector('.step-dependencies');
            
            // Support both the old text input and the new dropdown select
            if (depsInput) {
                if (depsInput.tagName === 'SELECT' && depsInput.multiple) {
                    // New format: multiple select dropdown
                    dependencies = Array.from(depsInput.selectedOptions).map(option => option.value);
                } else if (depsInput.value) {
                    // Old format: comma-separated text input
                    dependencies = depsInput.value.split(',')
                        .map(dep => dep.trim())
                        .filter(dep => dep.length > 0);
                }
            }
            
            // Parse rules
            let rules = {};
            try {
                const rulesText = stepCard.querySelector('.step-rules').value;
                if (rulesText.trim()) {
                    rules = JSON.parse(rulesText);
                }
            } catch (e) {
                throw new Error(`Invalid JSON in validation rules for step ${id}`);
            }
            
            steps.push({
                id: id,
                description: description,
                prompt: prompt,
                dependencies: dependencies,
                parallel_group: parallel_group,
                include_clinical_note: includeNote,
                rules: rules
            });
        });
        
        return {
            name: name,
            clinical_note: clinical_note,
            steps: steps
        };
    } catch (e) {
        addLog('error', `Error generating workflow configuration: ${e.message}`);
        return null;
    }
}

// Validate workflow configuration
function validateConfig(config) {
    if (!config.name) {
        addLog('error', 'Use case name is required');
        return false;
    }
    
    if (!config.clinical_note) {
        addLog('error', 'Clinical note is required');
        return false;
    }
    
    if (config.steps.length === 0) {
        addLog('error', 'At least one step is required');
        return false;
    }
    
    // Check for circular dependencies
    if (checkForCircularDependencies(config)) {
        addLog('error', 'Circular dependencies detected. Please fix before continuing.');
        return false;
    }
    
    // Validate step configurations
    for (const step of config.steps) {
        if (!step.id) {
            addLog('error', 'Step ID is required for all steps');
            return false;
        }
        
        if (!step.prompt) {
            addLog('error', `Prompt is required for step ${step.id}`);
            return false;
        }
        
        // Ensure all dependencies exist
        if (step.dependencies && step.dependencies.length > 0) {
            const stepIds = config.steps.map(s => s.id);
            const missingDependencies = step.dependencies.filter(dep => !stepIds.includes(dep));
            
            if (missingDependencies.length > 0) {
                // Don't block execution, just log a warning
                console.warn(`Step ${step.id} has missing dependencies: ${missingDependencies.join(', ')}`);
                addLog('warning', `Step ${step.id} has missing dependencies: ${missingDependencies.join(', ')}`);
                // Avoid returning false here so the workflow can still start
            }
        }
        
        // Validate rules JSON
        if (step.rules) {
            try {
                // If rules is a string, try to parse it
                if (typeof step.rules === 'string' && step.rules.trim()) {
                    JSON.parse(step.rules);
                }
                // If it's already an object, no need to validate further
            } catch (e) {
                addLog('error', `Invalid JSON in validation rules for step ${step.id}`);
                return false;
            }
        }
    }
    
    return true;
}

// Add log message to log container
function addLog(level, message) {
    const logContainer = document.getElementById('logContainer');
    const logEntry = document.createElement('div');
    logEntry.className = `log-${level}`;
    // Sanitize or remove markdown fences from log messages
    const sanitizedMessage = message.replace(/^```.*$/gm, '').trim();
    logEntry.textContent = `[${new Date().toLocaleTimeString()}] ${sanitizedMessage}`;
    logContainer.appendChild(logEntry);
    logContainer.scrollTop = logContainer.scrollHeight;
}

// Update progress indicators
function updateProgress(data) {
    const progressBar = document.getElementById('workflowProgress');
    const completedSteps = document.getElementById('completedSteps');
    const totalSteps = document.getElementById('totalSteps');
    
    const percentage = (data.completed_steps / data.total_steps) * 100;
    progressBar.style.width = `${percentage}%`;
    completedSteps.textContent = data.completed_steps;
    totalSteps.textContent = data.total_steps;
}

// Update the result handling function
function addStepResult(stepId, data) {
    const resultsContainer = document.getElementById('resultsContainer');
    
    // Check if result for this step already exists
    const existingResult = document.getElementById(`result-${stepId}`);
    if (existingResult) {
        existingResult.remove(); // Remove existing result if any
    }
    
    // Create new result card
    const resultCard = document.createElement('div');
    resultCard.id = `result-${stepId}`;
    resultCard.className = 'card mb-3';
    
    // Format the content nicely
    const formattedContent = JSON.stringify(data, null, 2);
    
    resultCard.innerHTML = `
        <div class="card-header d-flex justify-content-between align-items-center">
            <h6 class="mb-0">Step ${stepId} Result</h6>
            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="toggleResultCard(this)">
                <i class="bi bi-chevron-down"></i>
            </button>
        </div>
        <div class="card-body">
            <pre class="mb-0"><code>${formattedContent}</code></pre>
        </div>
    `;
    
    // Add to container
    resultsContainer.appendChild(resultCard);
}

// Toggle result card
function toggleResultCard(button) {
    const card = button.closest('.card');
    const cardBody = card.querySelector('.card-body');
    const icon = button.querySelector('i');
    
    if (cardBody.style.display === 'none') {
        cardBody.style.display = 'block';
        icon.classList.remove('bi-chevron-right');
        icon.classList.add('bi-chevron-down');
    } else {
        cardBody.style.display = 'none';
        icon.classList.remove('bi-chevron-down');
        icon.classList.add('bi-chevron-right');
    }
}

// Update UI state based on workflow status
function updateUIState(running) {
    workflowRunning = running;
    
    // When workflow is running, disable form elements in the config section
    const configInputs = document.querySelectorAll('#configSection input, #configSection textarea, #configSection select, #configSection button');
    configInputs.forEach(input => {
        // Only disable controls that are not already disabled and inside the steps container
        if (input.closest('#stepsContainer')) {
            input.disabled = running;
        }
    });
    
    // Always ensure start button has the correct state
    const startButton = document.getElementById('startButton');
    if (startButton) {
        startButton.disabled = running;
    }
    
    // Enable or disable the stop button based on running state
    const stopButton = document.getElementById('stopButton');
    if (stopButton) {
        stopButton.disabled = !running;
    }
    
    // Apply the correct class to step cards for visual feedback
    document.querySelectorAll('.step-card').forEach(card => {
        if (running) {
            card.classList.add('workflow-running');
        } else {
            card.classList.remove('workflow-running');
        }
    });
}

// Clear logs
function clearLogs() {
    document.getElementById('logContainer').innerHTML = '';
}

// Note: Panzoom instance is initialized above with filterKey in DOMContentLoaded to avoid capturing form control events
// No duplicate initialization here

// Collapse/Expand functionality
function toggleCard(header) {
    const card = header.closest('.card');
    card.classList.toggle('collapsed');
}

function togglePanel(header) {
    const panel = header.closest('.workflow-panel, .results-panel');
    panel.classList.toggle('collapsed');
}

function expandAll() {
    document.querySelectorAll('.collapsed').forEach(el => {
        el.classList.remove('collapsed');
    });
}

function collapseAll() {
    document.querySelectorAll('.card, .workflow-panel, .results-panel').forEach(el => {
        el.classList.add('collapsed');
    });
}

// Drag and drop functionality
let draggedElement = null;

function setupDragAndDrop() {
    const container = document.getElementById('stepsContainer');
    
    container.addEventListener('dragstart', (e) => {
        draggedElement = e.target;
        e.target.classList.add('dragging');
    });

    container.addEventListener('dragend', (e) => {
        e.target.classList.remove('dragging');
    });

    container.addEventListener('dragover', (e) => {
        e.preventDefault();
        const afterElement = getDragAfterElement(container, e.clientY);
        const draggable = document.querySelector('.dragging');
        if (afterElement == null) {
            container.appendChild(draggable);
        } else {
            container.insertBefore(draggable, afterElement);
        }
    });
}

function getDragAfterElement(container, y) {
    const draggableElements = [...container.querySelectorAll('.step-card:not(.dragging)')];
    
    return draggableElements.reduce((closest, child) => {
        const box = child.getBoundingClientRect();
        const offset = y - box.top - box.height / 2;
        if (offset < 0 && offset > closest.offset) {
            return { offset: offset, element: child };
        } else {
            return closest;
        }
    }, { offset: Number.NEGATIVE_INFINITY }).element;
}

// Function to toggle step card collapse
function toggleStepCard(button) {
    event.stopPropagation();
    const card = button.closest('.step-card');
    const icon = button.querySelector('i');
    const content = card.querySelector('.step-content');
    
    if (content.style.display === 'none') {
        content.style.display = 'block';
        icon.classList.remove('bi-chevron-right');
        icon.classList.add('bi-chevron-down');
    } else {
        content.style.display = 'none';
        icon.classList.remove('bi-chevron-down');
        icon.classList.add('bi-chevron-right');
    }
}

// Function to delete step
function deleteStep(button) {
    // Prevent the collapse toggle
    event.stopPropagation();
    
    if (confirm('Are you sure you want to delete this step?')) {
        const stepCard = button.closest('.step-card');
        stepCard.remove();
        updateDependencyOptions(); // Update dependencies for remaining steps
    }
}

// Function to collapse all steps
function collapseAllSteps() {
    document.querySelectorAll('.step-card').forEach(card => {
        card.classList.add('collapsed');
        const icon = card.querySelector('.collapse-icon');
        icon.classList.remove('bi-chevron-down');
        icon.classList.add('bi-chevron-right');
    });
}

// Function to expand all steps
function expandAllSteps() {
    document.querySelectorAll('.step-card').forEach(card => {
        card.classList.remove('collapsed');
        const icon = card.querySelector('.collapse-icon');
        icon.classList.remove('bi-chevron-right');
        icon.classList.add('bi-chevron-down');
    });
}

// Add a clear button to the Results section in the HTML
function addClearButton() {
    const resultsHeader = document.querySelector('.results-section .card-header');
    if (resultsHeader) {
        const clearButton = document.createElement('button');
        clearButton.className = 'btn btn-sm btn-secondary';
        clearButton.onclick = clearAllResults;
        clearButton.innerHTML = 'Clear All';
        resultsHeader.appendChild(clearButton);
    }
}

// Add function to toggle clinical note
function toggleClinicalNote(button) {
    // Find the step card that contains this button
    const stepCard = button.closest('.step-card');
    
    // Find the hidden input and status display elements
    const includeNoteInput = stepCard.querySelector('.step-include-note');
    const statusDiv = stepCard.querySelector('.clinical-note-status');
    
    // Get the button (it might be the X button in the status div or the main toggle button)
    const toggleButton = stepCard.querySelector('.btn-outline-primary');
    
    // Check if the current value is 'true' or 'false' and toggle it
    if (includeNoteInput.value === 'true') {
        // Change to NOT include clinical note
        includeNoteInput.value = 'false';
        statusDiv.style.display = 'none';
        toggleButton.classList.remove('active');
        toggleButton.innerHTML = '<i class="bi bi-file-text"></i> Add Original Note';
        
        // Log the change for clarity
        console.log(`Clinical note disabled for step ${stepCard.querySelector('.step-id').value}`);
    } else {
        // Change to include clinical note
        includeNoteInput.value = 'true';
        statusDiv.style.display = 'block';
        toggleButton.classList.add('active');
        toggleButton.innerHTML = '<i class="bi bi-file-text"></i> Remove Original Note';
        
        // Log the change for clarity
        console.log(`Clinical note enabled for step ${stepCard.querySelector('.step-id').value}`);
    }
}

// Add some CSS for the button states
const style = document.createElement('style');
style.textContent = `
    .btn-outline-primary.active {
        background-color: #0d6efd;
        color: white;
    }
    
    .clinical-note-status {
        transition: all 0.3s ease;
    }
    
    .btn-close {
        font-size: 0.8rem;
    }
`;
document.head.appendChild(style);

// Get a display name for the LLM provider
function getProviderDisplayName(provider) {
    switch (provider) {
        case 'openai':
            return 'OpenAI GPT-4';
        case 'deepinfra':
            return 'DeepInfra Llama 4 Maverick';
        case 'azure':
            return 'Azure OpenAI';
        default:
            return provider;
    }
}

// Add function to properly visualize parallel and sequential steps
function updateStepCardColors() {
    const stepCards = document.querySelectorAll('.step-card');
    const groupColors = {};
    let colorIndex = 0;
    const colors = [
        'rgba(86, 140, 245, 0.2)',  // blue
        'rgba(245, 131, 86, 0.2)',  // orange
        'rgba(129, 224, 137, 0.2)', // green
        'rgba(212, 129, 224, 0.2)', // purple
        'rgba(245, 224, 86, 0.2)',  // yellow
        'rgba(224, 86, 142, 0.2)',  // pink
        'rgba(86, 221, 224, 0.2)'   // cyan
    ];
    
    // First, reset all step cards to default
    stepCards.forEach(card => {
        card.style.backgroundColor = '';
        card.style.borderLeft = '';
    });
    
    // Then, assign colors to steps by parallel group
    stepCards.forEach(card => {
        const groupInput = card.querySelector('.step-group');
        if (!groupInput) return;
        
        const group = groupInput.value.trim();
        if (!group) return; // Skip steps without a group
        
        if (!groupColors[group]) {
            groupColors[group] = colors[colorIndex % colors.length];
            colorIndex++;
        }
        
        // Apply group color
        card.style.backgroundColor = groupColors[group];
        card.style.borderLeft = `5px solid ${groupColors[group].replace('0.2', '0.8')}`;
    });
    
    // Add visualization for dependencies
    visualizeDependencies();
}

// Add function to visualize dependencies between steps
function visualizeDependencies() {
    // Remove any existing dependency visualizations
    document.querySelectorAll('.dependency-indicator').forEach(el => el.remove());
    
    const stepsContainer = document.getElementById('stepsContainer');
    const stepCards = document.querySelectorAll('.step-card');
    
    stepCards.forEach(card => {
        const stepId = card.getAttribute('data-step-id');
        const depsInput = card.querySelector('.step-dependencies');
        let dependencies = [];
        
        if (depsInput) {
            if (depsInput.tagName === 'SELECT' && depsInput.multiple) {
                dependencies = Array.from(depsInput.selectedOptions).map(option => option.value);
            } else if (depsInput.value) {
                dependencies = depsInput.value.split(',')
                    .map(dep => dep.trim())
                    .filter(dep => dep.length > 0);
            }
        }
        
        // Skip if no dependencies
        if (dependencies.length === 0) return;
        
        // For each dependency, create a visual indicator
        dependencies.forEach(depId => {
            const depCard = document.querySelector(`.step-card[data-step-id="${depId}"]`);
            if (!depCard) return;
            
            // Create indicator element
            const indicator = document.createElement('div');
            indicator.className = 'dependency-indicator';
            indicator.innerHTML = `<span>${depId} → ${stepId}</span>`;
            indicator.title = `Step ${stepId} depends on Step ${depId}`;
            
            // Position indicator between cards
            const rect1 = depCard.getBoundingClientRect();
            const rect2 = card.getBoundingClientRect();
            
            // Add indicator to container
            stepsContainer.appendChild(indicator);
        });
    });
}

// Add new validation function to check for circular dependencies
function checkForCircularDependencies(config) {
    const graph = {};
    
    // Build dependency graph
    config.steps.forEach(step => {
        graph[step.id] = step.dependencies || [];
    });
    
    // Function to detect cycles using DFS
    function hasCycle(node, visited, recStack) {
        if (!visited[node]) {
            visited[node] = true;
            recStack[node] = true;
            
            for (const neighbor of graph[node]) {
                if (!visited[neighbor] && hasCycle(neighbor, visited, recStack)) {
                    return true;
                } else if (recStack[neighbor]) {
                    return true;
                }
            }
        }
        recStack[node] = false;
        return false;
    }
    
    // Check each node for cycles
    const visited = {};
    const recStack = {};
    
    for (const step of config.steps) {
        if (!visited[step.id] && hasCycle(step.id, visited, recStack)) {
            return true;
        }
    }
    
    return false;
}

// Add CSS for dependency visualization
document.addEventListener('DOMContentLoaded', () => {
    const style = document.createElement('style');
    style.textContent = `
        .step-card {
            position: relative;
            transition: background-color 0.3s ease;
            margin-bottom: 15px;
            border-radius: 5px;
        }
        
        .dependency-indicator {
            position: relative;
            margin: -8px 0;
            text-align: right;
            padding-right: 20px;
            font-size: 0.8em;
            color: #666;
        }
        
        .dependency-indicator span {
            background-color: #f8f9fa;
            padding: 2px 8px;
            border-radius: 12px;
            border: 1px dashed #ccc;
        }
    `;
    document.head.appendChild(style);
}); 