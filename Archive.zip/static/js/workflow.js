let workflowRunning = false;
let workflowSocket = null;

// Sample data for pre-filling steps
const sampleSteps = [
    {
        id: 'step1',
        description: 'Extract Patient Symptoms',
        prompt: 'Given the clinical note, extract all symptoms mentioned. Return in JSON format: {"symptoms": ["headache", "nausea"], "duration": "3 days", "severity": "severe"}',
        dependencies: [],
        parallel_group: 'group1',
        include_clinical_note: true,
        rules: {
            required_fields: ['symptoms', 'duration', 'severity'],
            validation_rules: {
                symptoms: 'array',
                duration: 'string',
                severity: 'string'
            }
        }
    },
    {
        id: 'step2',
        description: 'Extract Medical History',
        prompt: 'Extract patient medical history from the clinical note. Return in JSON format: {"previous_conditions": ["hypertension"], "medications": ["lisinopril"], "allergies": ["penicillin"]}',
        dependencies: [],
        parallel_group: 'group1',
        include_clinical_note: true,
        rules: {
            required_fields: ['previous_conditions', 'medications', 'allergies'],
            validation_rules: {
                previous_conditions: 'array',
                medications: 'array',
                allergies: 'array'
            }
        }
    },
    {
        id: 'step3',
        description: 'Generate Diagnosis',
        prompt: 'Based on the symptoms and medical history, generate a diagnosis. Return in JSON format: {"diagnosis": "Migraine", "confidence": 0.85, "recommended_tests": ["MRI", "Blood Test"]}',
        dependencies: ['step1', 'step2'],
        parallel_group: 'group2',
        include_clinical_note: true,
        rules: {
            required_fields: ['diagnosis', 'confidence', 'recommended_tests'],
            validation_rules: {
                diagnosis: 'string',
                confidence: 'number',
                recommended_tests: 'array'
            }
        }
    }
];

// Function to create a new step with data
function createStepWithData(stepData) {
    const template = document.getElementById('stepTemplate');
    const stepCard = template.content.cloneNode(true);
    const stepsContainer = document.getElementById('stepsContainer');
    
    // Fill in the step data
    const card = stepCard.querySelector('.step-card');
    card.dataset.stepId = stepData.id;
    
    // Set the parallel group as a data attribute for CSS targeting
    if (stepData.parallel_group) {
        card.dataset.group = stepData.parallel_group;
    }
    
    const inputs = {
        '.step-id': stepData.id,
        '.step-description': stepData.description,
        '.step-prompt': stepData.prompt,
        '.step-dependencies': stepData.dependencies.join(', '),
        '.step-group': stepData.parallel_group,
        '.step-rules': JSON.stringify(stepData.rules, null, 2),
        '.step-include-note': stepData.include_clinical_note
    };
    
    // Set values for all inputs
    Object.entries(inputs).forEach(([selector, value]) => {
        const element = card.querySelector(selector);
        if (element) {
            element.value = value;
            // Enable all fields except step ID
            element.disabled = selector === '.step-id';
        }
    });
    
    stepsContainer.appendChild(stepCard);
    return card;
}

// Initialize UI with sample data
document.addEventListener('DOMContentLoaded', () => {
    // Pre-fill use case name and clinical note
    document.getElementById('useCaseName').value = 'Clinical Diagnosis Workflow';
    document.getElementById('clinicalNote').value = 'Patient presents with severe headache lasting for 3 days, accompanied by nausea and sensitivity to light. Medical history includes hypertension and is currently on lisinopril. Patient has known allergies to penicillin.';
    
    // Clear existing steps
    const stepsContainer = document.getElementById('stepsContainer');
    stepsContainer.innerHTML = '';
    
    // Add all sample steps
    sampleSteps.forEach(stepData => {
        createStepWithData(stepData);
    });
    
    // Update dependency options
    updateDependencyOptions();
    
    // Pan-zoom functionality
    panzoom = Panzoom(document.querySelector('.workspace-container'), {
        maxScale: 5,
        minScale: 0.5
    });
    
    setupDragAndDrop();
    
    addClearButton();
});

// Function to add new blank step
function addNewStep() {
    const template = document.getElementById('stepTemplate');
    const stepCard = template.content.cloneNode(true);
    const stepsContainer = document.getElementById('stepsContainer');
    const stepId = `step${stepsContainer.children.length + 1}`;
    
    stepCard.querySelector('.step-card').dataset.stepId = stepId;
    stepCard.querySelector('.step-id').value = stepId;
    stepCard.querySelector('.step-title').textContent = `Step ${stepId}`;
    
    // Initialize with empty data-group
    stepCard.querySelector('.step-card').dataset.group = '';
    
    stepsContainer.appendChild(stepCard);
    updateDependencyOptions();
    
    // Set up group color handling for the new step
    if (typeof updateStepCardColors === 'function') {
        setTimeout(updateStepCardColors, 50);
    }
    
    return stepsContainer.lastElementChild;
}

// Remove step from workflow
function removeStep(button) {
    const stepCard = button.closest('.step-card');
    stepCard.remove();
    updateDependencyOptions();
}

// Edit step configuration
function editStep(button) {
    const stepCard = button.closest('.step-card');
    const inputs = stepCard.querySelectorAll('input, textarea');
    inputs.forEach(input => input.disabled = !input.disabled);
}

// Update dependency options for all steps
function updateDependencyOptions() {
    const steps = document.querySelectorAll('.step-card');
    steps.forEach(step => {
        const stepId = step.dataset.stepId;
        const dependencyInput = step.querySelector('.step-dependencies');
        const availableDeps = Array.from(steps)
            .map(s => s.dataset.stepId)
            .filter(id => id !== stepId);
        
        // Update placeholder with available steps
        dependencyInput.placeholder = `Available: ${availableDeps.join(', ')}`;
    });
}

// Update the event handlers
function handleLogMessage(data) {
    const { level, message } = data;
    addLog(level, message);
}

function handleProgressUpdate(data) {
    const { completed_steps, total_steps } = data.data;
    updateProgress({
        completed_steps: completed_steps,
        total_steps: total_steps
    });
}

function handleStepResult(data) {
    const { step_id, data: resultData } = data;
    addStepResult(step_id, resultData);
}

function handleWorkflowComplete(data) {
    workflowRunning = false;
    updateUIState(false);
    if (data.status === 'error') {
        addLog('error', data.message);
    } else {
        addLog('info', 'Workflow completed successfully');
    }
}

// Function to clear all results, logs, and progress
function clearAllResults() {
    // Clear results container
    const resultsContainer = document.getElementById('resultsContainer');
    resultsContainer.innerHTML = '';
    
    // Clear logs
    const logContainer = document.getElementById('logContainer');
    logContainer.innerHTML = '';
    
    // Reset progress
    const progressBar = document.getElementById('workflowProgress');
    progressBar.style.width = '0%';
    document.getElementById('completedSteps').textContent = '0';
    document.getElementById('totalSteps').textContent = '0';
}

// Update the startWorkflow function to clear everything before starting
function startWorkflow() {
    if (workflowRunning) return;
    
    const config = getWorkflowConfig();
    if (!validateConfig(config)) return;

    // Clear all previous results, logs, and progress
    clearAllResults();
    
    workflowSocket = io();
    
    workflowSocket.on('connect', () => {
        console.log('Socket connected');
        workflowRunning = true;
        updateUIState(true);
        
        // Add initial log
        addLog('info', 'Starting workflow...');
        
        // Generate unique workflow ID
        const workflow_id = 'workflow-' + Date.now();
        
        // Refresh step colors before starting the workflow
        if (typeof updateStepCardColors === 'function') {
            updateStepCardColors();
        }
        
        workflowSocket.emit('start_workflow', {
            workflow_id: workflow_id,
            config: config
        });
    });
    
    // Set up event listeners
    workflowSocket.on('log', handleLogMessage);
    workflowSocket.on('progress', handleProgressUpdate);
    workflowSocket.on('result', handleStepResult);
    workflowSocket.on('complete', handleWorkflowComplete);
    
    // Add error handling
    workflowSocket.on('connect_error', (error) => {
        addLog('error', `Connection error: ${error.message}`);
        workflowRunning = false;
        updateUIState(false);
    });
}

// Stop workflow execution
function stopWorkflow() {
    if (!workflowRunning || !workflowSocket) return;
    
    workflowSocket.send(JSON.stringify({
        type: 'stop'
    }));
}

// Function to get the current workflow configuration
function getWorkflowConfig() {
    const name = document.getElementById('useCaseName').value;
    const clinical_note = document.getElementById('clinicalNote').value;
    
    const steps = [];
    const stepCards = document.querySelectorAll('.step-card');
    
    try {
        // Process each step card
        stepCards.forEach(stepCard => {
            const id = stepCard.querySelector('.step-id').value;
            const description = stepCard.querySelector('.step-description').value;
            const prompt = stepCard.querySelector('.step-prompt').value;
            const includeNote = stepCard.querySelector('.step-include-note').value === 'true';
            const parallel_group = stepCard.querySelector('.step-group').value.trim();
            
            // Parse dependencies (comma-separated list)
            const depsInput = stepCard.querySelector('.step-dependencies').value;
            const dependencies = depsInput.split(',')
                .map(dep => dep.trim())
                .filter(dep => dep.length > 0);
            
            // Parse validation rules if present
            let rules = {};
            try {
                const rulesText = stepCard.querySelector('.step-rules').value;
                if (rulesText.trim()) {
                    rules = JSON.parse(rulesText);
                }
            } catch (e) {
                throw new Error(`Invalid JSON in validation rules for step ${id}`);
            }
            
            steps.push({
                id: id,
                description: description,
                prompt: prompt,
                dependencies: dependencies,
                parallel_group: parallel_group,
                include_clinical_note: includeNote,
                rules: rules
            });
        });
        
        return {
            name: name,
            clinical_note: clinical_note,
            steps: steps
        };
    } catch (e) {
        addLog('error', `Error generating workflow configuration: ${e.message}`);
        return null;
    }
}

// Validate workflow configuration
function validateConfig(config) {
    if (!config.name) {
        addLog('error', 'Use case name is required');
        return false;
    }
    
    if (!config.clinical_note) {
        addLog('error', 'Clinical note is required');
        return false;
    }
    
    if (config.steps.length === 0) {
        addLog('error', 'At least one step is required');
        return false;
    }
    
    // Validate step configurations
    for (const step of config.steps) {
        if (!step.id) {
            addLog('error', 'Step ID is required for all steps');
            return false;
        }
        
        if (!step.prompt) {
            addLog('error', `Prompt is required for step ${step.id}`);
            return false;
        }
        
        try {
            if (step.rules && typeof step.rules === 'string') {
                JSON.parse(step.rules);
            }
        } catch (e) {
            addLog('error', `Invalid JSON in rules for step ${step.id}`);
            return false;
        }
    }
    
    return true;
}

// Add log message to log container
function addLog(level, message) {
    const logContainer = document.getElementById('logContainer');
    const logEntry = document.createElement('div');
    logEntry.className = `log-${level}`;
    logEntry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
    logContainer.appendChild(logEntry);
    logContainer.scrollTop = logContainer.scrollHeight;
}

// Update progress indicators
function updateProgress(data) {
    const progressBar = document.getElementById('workflowProgress');
    const completedSteps = document.getElementById('completedSteps');
    const totalSteps = document.getElementById('totalSteps');
    
    const percentage = (data.completed_steps / data.total_steps) * 100;
    progressBar.style.width = `${percentage}%`;
    completedSteps.textContent = data.completed_steps;
    totalSteps.textContent = data.total_steps;
}

// Update the result handling function
function addStepResult(stepId, data) {
    const resultsContainer = document.getElementById('resultsContainer');
    
    // Check if result for this step already exists
    const existingResult = document.getElementById(`result-${stepId}`);
    if (existingResult) {
        existingResult.remove(); // Remove existing result if any
    }
    
    // Create new result card
    const resultCard = document.createElement('div');
    resultCard.id = `result-${stepId}`;
    resultCard.className = 'card mb-3';
    
    // Format the content nicely
    const formattedContent = JSON.stringify(data, null, 2);
    
    resultCard.innerHTML = `
        <div class="card-header d-flex justify-content-between align-items-center">
            <h6 class="mb-0">Step ${stepId} Result</h6>
            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="toggleResultCard(this)">
                <i class="bi bi-chevron-down"></i>
            </button>
        </div>
        <div class="card-body">
            <pre class="mb-0"><code>${formattedContent}</code></pre>
        </div>
    `;
    
    // Add to container
    resultsContainer.appendChild(resultCard);
}

// Toggle result card
function toggleResultCard(button) {
    const card = button.closest('.card');
    const cardBody = card.querySelector('.card-body');
    const icon = button.querySelector('i');
    
    if (cardBody.style.display === 'none') {
        cardBody.style.display = 'block';
        icon.classList.remove('bi-chevron-right');
        icon.classList.add('bi-chevron-down');
    } else {
        cardBody.style.display = 'none';
        icon.classList.remove('bi-chevron-down');
        icon.classList.add('bi-chevron-right');
    }
}

// Update UI state based on workflow status
function updateUIState(running) {
    document.getElementById('stopButton').disabled = !running;
    document.querySelectorAll('input, textarea, button:not(#stopButton)').forEach(el => {
        el.disabled = running;
    });
    
    if (!running) {
        addLog('info', 'Workflow execution completed');
    }
}

// Clear logs
function clearLogs() {
    document.getElementById('logContainer').innerHTML = '';
}

// Pan-zoom functionality
let panzoom = Panzoom(document.querySelector('.workspace-container'), {
    maxScale: 5,
    minScale: 0.5
});

function zoomIn() {
    panzoom.zoomIn();
}

function zoomOut() {
    panzoom.zoomOut();
}

function resetZoom() {
    panzoom.reset();
}

// Collapse/Expand functionality
function toggleCard(header) {
    const card = header.closest('.card');
    card.classList.toggle('collapsed');
}

function togglePanel(header) {
    const panel = header.closest('.workflow-panel, .results-panel');
    panel.classList.toggle('collapsed');
}

function expandAll() {
    document.querySelectorAll('.collapsed').forEach(el => {
        el.classList.remove('collapsed');
    });
}

function collapseAll() {
    document.querySelectorAll('.card, .workflow-panel, .results-panel').forEach(el => {
        el.classList.add('collapsed');
    });
}

// Drag and drop functionality
let draggedElement = null;

function setupDragAndDrop() {
    const container = document.getElementById('stepsContainer');
    
    container.addEventListener('dragstart', (e) => {
        draggedElement = e.target;
        e.target.classList.add('dragging');
    });

    container.addEventListener('dragend', (e) => {
        e.target.classList.remove('dragging');
    });

    container.addEventListener('dragover', (e) => {
        e.preventDefault();
        const afterElement = getDragAfterElement(container, e.clientY);
        const draggable = document.querySelector('.dragging');
        if (afterElement == null) {
            container.appendChild(draggable);
        } else {
            container.insertBefore(draggable, afterElement);
        }
    });
}

function getDragAfterElement(container, y) {
    const draggableElements = [...container.querySelectorAll('.step-card:not(.dragging)')];
    
    return draggableElements.reduce((closest, child) => {
        const box = child.getBoundingClientRect();
        const offset = y - box.top - box.height / 2;
        if (offset < 0 && offset > closest.offset) {
            return { offset: offset, element: child };
        } else {
            return closest;
        }
    }, { offset: Number.NEGATIVE_INFINITY }).element;
}

// Function to toggle step card collapse
function toggleStepCard(button) {
    event.stopPropagation();
    const card = button.closest('.step-card');
    const icon = button.querySelector('i');
    const content = card.querySelector('.step-content');
    
    if (content.style.display === 'none') {
        content.style.display = 'block';
        icon.classList.remove('bi-chevron-right');
        icon.classList.add('bi-chevron-down');
    } else {
        content.style.display = 'none';
        icon.classList.remove('bi-chevron-down');
        icon.classList.add('bi-chevron-right');
    }
}

// Function to delete step
function deleteStep(button) {
    // Prevent the collapse toggle
    event.stopPropagation();
    
    if (confirm('Are you sure you want to delete this step?')) {
        const stepCard = button.closest('.step-card');
        stepCard.remove();
        updateDependencyOptions(); // Update dependencies for remaining steps
    }
}

// Function to collapse all steps
function collapseAllSteps() {
    document.querySelectorAll('.step-card').forEach(card => {
        card.classList.add('collapsed');
        const icon = card.querySelector('.collapse-icon');
        icon.classList.remove('bi-chevron-down');
        icon.classList.add('bi-chevron-right');
    });
}

// Function to expand all steps
function expandAllSteps() {
    document.querySelectorAll('.step-card').forEach(card => {
        card.classList.remove('collapsed');
        const icon = card.querySelector('.collapse-icon');
        icon.classList.remove('bi-chevron-right');
        icon.classList.add('bi-chevron-down');
    });
}

// Add a clear button to the Results section in the HTML
function addClearButton() {
    const resultsHeader = document.querySelector('.results-section .card-header');
    if (resultsHeader) {
        const clearButton = document.createElement('button');
        clearButton.className = 'btn btn-sm btn-secondary';
        clearButton.onclick = clearAllResults;
        clearButton.innerHTML = 'Clear All';
        resultsHeader.appendChild(clearButton);
    }
}

// Add function to toggle clinical note
function toggleClinicalNote(button) {
    const stepCard = button.closest('.step-card');
    const statusDiv = stepCard.querySelector('.clinical-note-status');
    const includeNoteInput = stepCard.querySelector('.step-include-note');
    const toggleButton = stepCard.querySelector('.btn-outline-primary');
    
    if (includeNoteInput.value === 'false') {
        // Enable clinical note
        includeNoteInput.value = 'true';
        statusDiv.style.display = 'block';
        toggleButton.classList.add('active');
        toggleButton.innerHTML = '<i class="bi bi-file-text"></i> Remove Clinical Note';
    } else {
        // Disable clinical note
        includeNoteInput.value = 'false';
        statusDiv.style.display = 'none';
        toggleButton.classList.remove('active');
        toggleButton.innerHTML = '<i class="bi bi-file-text"></i> Add Clinical Note';
    }
}

// Add some CSS for the button states
const style = document.createElement('style');
style.textContent = `
    .btn-outline-primary.active {
        background-color: #0d6efd;
        color: white;
    }
    
    .clinical-note-status {
        transition: all 0.3s ease;
    }
    
    .btn-close {
        font-size: 0.8rem;
    }
`;
document.head.appendChild(style); 