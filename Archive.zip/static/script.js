let socket = io();

function showNotification(message, type = 'info') {
    const notification = document.getElementById('notification');
    const messageElement = notification.querySelector('.notification-message');
    
    notification.className = `notification ${type}`;
    messageElement.textContent = message;
    notification.classList.remove('hidden');
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
        notification.classList.add('hidden');
    }, 5000);
}

function addLog(level, message) {
    const logsContainer = document.getElementById('logs');
    const logEntry = document.createElement('div');
    logEntry.className = `log-entry ${level}`;
    
    // Handle different message types
    if (message.includes('=== Step')) {
        const parts = message.split('\n');
        const header = parts[0];
        const content = parts.slice(1).join('\n');
        
        // Try to parse and format JSON responses
        if (header.includes('Response')) {
            try {
                const jsonContent = JSON.parse(content);
                const formattedJson = JSON.stringify(jsonContent, null, 2);
                logEntry.innerHTML = `
                    <div class="step-header">${header}</div>
                    <div class="message-block response-message">
                        <pre class="json-content">${formattedJson}</pre>
                    </div>
                `;
            } catch (e) {
                // If not JSON, display as regular content
                logEntry.innerHTML = `
                    <div class="step-header">${header}</div>
                    <div class="message-block">
                        <div class="message-content">${content}</div>
                    </div>
                `;
            }
        } else {
            // Handle prompt messages
            let messageType = '';
            if (content.toLowerCase().includes('system:')) {
                messageType = 'system-message';
            } else if (content.toLowerCase().includes('user:')) {
                messageType = 'user-message';
            } else if (content.toLowerCase().includes('assistant:')) {
                messageType = 'assistant-message';
            }
            
            logEntry.innerHTML = `
                <div class="step-header">${header}</div>
                <div class="message-block ${messageType}">
                    <div class="message-content">${content}</div>
                </div>
            `;
        }
    } else {
        logEntry.textContent = message;
    }
    
    logsContainer.appendChild(logEntry);
    logsContainer.scrollTop = logsContainer.scrollHeight;
}

function clearLogs() {
    document.getElementById('logs').innerHTML = '';
}

// Socket event handlers
socket.on('log', function(data) {
    addLog(data.level, data.message);
});

socket.on('error', function(data) {
    showNotification(data.message, 'error');
});

socket.on('complete', function(data) {
    if (data.status === 'error') {
        showNotification(data.message, 'error');
    } else if (data.status === 'success') {
        showNotification('Workflow completed successfully', 'info');
    }
});

// Add close button functionality for notifications
document.querySelector('.close-btn').addEventListener('click', function() {
    document.getElementById('notification').classList.add('hidden');
});

.json-content {
    background-color: #f8f9fa;
    padding: 10px;
    border-radius: 4px;
    margin: 0;
    white-space: pre-wrap;
    word-wrap: break-word;
    overflow-wrap: break-word;
    font-family: monospace;
    max-width: 100%;
    overflow-x: auto;
}

.message-block {
    padding: 10px;
    margin: 5px 0;
    border-radius: 4px;
    white-space: pre-wrap;
    word-wrap: break-word;
    overflow-wrap: break-word;
    max-width: 100%;
}

.message-content {
    font-family: monospace;
    line-height: 1.4;
    word-wrap: break-word;
    overflow-wrap: break-word;
    max-width: 100%;
}

/* Add this if you have a container for the results */
.results-container {
    max-width: 100%;
    overflow-x: hidden;
} 