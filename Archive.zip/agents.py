from typing import Dict, Any, List, Optional
from loguru import logger
from pydantic import BaseModel
from datetime import datetime
import asyncio
from progress_tracking import WorkflowProgress
import json

class StepInput(BaseModel):
    content: Any
    metadata: Dict[str, Any] = {}

class StepOutput(BaseModel):
    content: Any
    metadata: Dict[str, Any] = {}
    validation_status: bool = False
    validation_message: str = ""

class ValidationRules(BaseModel):
    required_fields: List[str]
    format: str
    min_symptoms: Optional[int] = None

class QualityRules(BaseModel):
    max_length: Optional[int] = None
    language: Optional[str] = None
    min_confidence: Optional[float] = None

class BusinessRules(BaseModel):
    must_include: Optional[List[str]] = None
    exclude_terms: Optional[List[str]] = None

class StepRules(BaseModel):
    validation: Optional[ValidationRules] = None
    quality: Optional[QualityRules] = None
    business: Optional[BusinessRules] = None

class Step(BaseModel):
    id: str
    description: str
    prompt: str
    dependencies: List[str] = []
    parallel_group: Optional[str] = None
    rules: Optional[StepRules] = None
    input: Optional[StepInput] = None
    output: Optional[StepOutput] = None

class UseCase(BaseModel):
    name: str
    steps: List[Step]
    clinical_note: str
    rules: Optional[Dict[str, Any]] = None

class Agent:
    def __init__(self, llm_service):
        self.llm_service = llm_service
        logger.info(f"Initializing {self.__class__.__name__}")

    async def process(self, input_data: Any) -> Any:
        raise NotImplementedError

class UseCaseValidator(Agent):
    async def process(self, usecase: UseCase) -> bool:
        # Skipping usecase validation to ensure workflow always proceeds
        logger.info(f"Skipping usecase validation for usecase: {usecase.name}")
        return True

class StepExecutor(Agent):
    async def process(self, step: Step, context: Dict[str, Any], progress: WorkflowProgress) -> StepOutput:
        logger.info(f"Executing step: {step.id}")
        
        # Prepare input based on dependencies
        input_content = step.input.content if step.input else context.get("clinical_note", "")
        if step.dependencies:
            dependency_outputs = []
            for dep in step.dependencies:
                if dep in context and "output" in context[dep]:
                    dependency_outputs.append(context[dep]["output"].content)
            if dependency_outputs:
                input_content = " ".join(dependency_outputs)
        
        prompt = f"""
        Execute the following step:
        Description: {step.description}
        Input: {input_content}
        Specific Instructions: {step.prompt}

        Return the response in valid JSON format.
        """
        
        try:
            # Get the raw response from LLM
            raw_result = await self.llm_service.generate_response(prompt, keep_raw=True)
            
            # Store JSON-parsed result as content and raw result in metadata
            output = StepOutput(
                content=raw_result,
                metadata={
                    "step_id": step.id, 
                    "timestamp": datetime.now().isoformat(),
                    "raw_content": raw_result
                }
            )
            logger.info(f"Step {step.id} executed successfully")
            return output
        except Exception as e:
            logger.error(f"Error executing step {step.id}: {str(e)}", exc_info=True)
            return StepOutput(
                content=None,
                metadata={"error": str(e)},
                validation_status=False,
                validation_message=f"Execution failed: {str(e)}"
            )

class ResultValidator(Agent):
    async def process(self, output: StepOutput, rules: StepRules) -> bool:
        logger.info("Validating result against rules")
        if not rules:
            logger.info("No rules specified for validation")
            return True

        # First, check if the output is valid JSON
        try:
            # Try to parse the content as JSON
            if isinstance(output.content, str):
                json.loads(output.content)
                logger.info("Output is valid JSON format")
            else:
                logger.warning("Output is not a string, skipping JSON validation")
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON format: {str(e)}")
            output.validation_status = False
            output.validation_message = f"Invalid JSON format: {str(e)}"
            return False

        validation_prompt = f"""
        Validate the following response according to these rules:
        Response: {output.content}
        Rules: {rules}
        
        IMPORTANT: The response MUST be a valid JSON object without any explanations or code. Return ONLY 'VALID' if it meets all rules or 'INVALID: <reason>' if it does not.
        """
        try:
            validation_result = await self.llm_service.generate_response(validation_prompt)
            is_valid = "VALID" in validation_result.upper()
            output.validation_status = is_valid
            output.validation_message = validation_result
            logger.info(f"Validation result: {'Valid' if is_valid else 'Invalid'}")
            return is_valid
        except Exception as e:
            logger.error(f"Error validating result: {str(e)}", exc_info=True)
            return False

class WorkflowManager:
    def __init__(self, llm_service):
        self.llm_service = llm_service
        self.use_case_validator = UseCaseValidator(llm_service)
        self.step_executor = StepExecutor(llm_service)
        self.result_validator = ResultValidator(llm_service)
        self.progress = None
        self.progress_callback = None
        logger.info("Initializing WorkflowManager")

    def _build_dependency_graph(self, steps: List[Step]) -> Dict[str, List[str]]:
        graph = {}
        for step in steps:
            graph[step.id] = step.dependencies
        return graph

    def _get_parallel_groups(self, steps: List[Step]) -> Dict[str, List[Step]]:
        groups = {}
        for step in steps:
            if step.parallel_group:
                if step.parallel_group not in groups:
                    groups[step.parallel_group] = []
                groups[step.parallel_group].append(step)
        return groups

    async def _execute_parallel_group(self, group: List[Step], context: Dict[str, Any]) -> Dict[str, StepOutput]:
        tasks = []
        for step in group:
            tasks.append(self.step_executor.process(step, context, self.progress))
        results = await asyncio.gather(*tasks)
        return {step.id: result for step, result in zip(group, results)}

    async def execute_workflow(self, usecase: UseCase, progress_callback=None) -> Dict[str, StepOutput]:
        logger.info(f"Starting workflow execution for usecase: {usecase.name}")
        self.progress = WorkflowProgress(len(usecase.steps))
        self.progress_callback = progress_callback
        
        try:
            # Validate usecase
            logger.info("Validating usecase...")
            if not await self.use_case_validator.process(usecase):
                raise ValueError("Invalid usecase")
            logger.success("Usecase validation successful")

            # Build dependency graph and identify parallel groups
            graph = self._build_dependency_graph(usecase.steps)
            parallel_groups = self._get_parallel_groups(usecase.steps)
            logger.info(f"Dependency graph built: {graph}")
            logger.info(f"Parallel groups identified: {list(parallel_groups.keys())}")
            
            # Execute steps
            results = {}
            context = {"clinical_note": usecase.clinical_note}
            
            for step in usecase.steps:
                self.progress.current_step = step.id
                
                # Check if step is part of a parallel group
                if step.parallel_group and step.id not in results:
                    logger.info(f"Executing parallel group: {step.parallel_group}")
                    group_results = await self._execute_parallel_group(
                        parallel_groups[step.parallel_group],
                        context
                    )
                    results.update(group_results)
                    
                    # Update progress for all steps in group
                    for group_step_id in group_results:
                        self.progress.update_step_status(group_step_id, "completed")
                        self.progress.update_llm_call(group_step_id, "completed")
                        
                    if self.progress_callback:
                        await self.progress_callback(self.progress.get_progress_summary())
                    
                    continue
                
                # Skip if already executed in parallel
                if step.id in results:
                    continue
                
                # Execute sequential step
                logger.info(f"Executing sequential step {step.id}: {step.description}")
                self.progress.update_step_status(step.id, "started")
                self.progress.update_llm_call(step.id, "started")
                
                if self.progress_callback:
                    await self.progress_callback(self.progress.get_progress_summary())
                
                try:
                    # Execute step
                    step_result = await self.step_executor.process(step, context, self.progress)
                    
                    # Validate result if rules exist
                    if step.rules:
                        logger.info(f"Validating step {step.id} results...")
                        is_valid = await self.result_validator.process(step_result, step.rules)
                        if not is_valid:
                            raise ValueError(f"Step {step.id} failed validation")
                        logger.success(f"Step {step.id} validation successful")
                    
                    # Update progress and context
                    self.progress.update_step_status(step.id, "completed")
                    self.progress.update_llm_call(step.id, "completed")
                    logger.success(f"Step {step.id} completed successfully")
                    
                    results[step.id] = step_result
                    context[step.id] = {"output": step_result}
                    
                    if self.progress_callback:
                        await self.progress_callback(self.progress.get_progress_summary())
                        
                except Exception as e:
                    logger.error(f"Error in step {step.id}: {str(e)}", exc_info=True)
                    self.progress.update_step_status(step.id, "failed")
                    self.progress.update_llm_call(step.id, "failed")
                    raise
            
            logger.success("Workflow execution completed successfully")
            return results
            
        except Exception as e:
            logger.error(f"Workflow execution failed: {str(e)}", exc_info=True)
            raise 