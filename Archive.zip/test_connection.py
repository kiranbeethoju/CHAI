import asyncio
from llm_service import get_llm_service
from agents import UseCase, Step, StepRules, ValidationRules, QualityRules, BusinessRules, WorkflowManager, StepInput
from logger_config import setup_logger
from loguru import logger
import time

# Setup logger before any other operations
setup_logger()

async def monitor_progress(progress_summary: dict):
    """Display real-time progress updates"""
    logger.info("\n" + "="*50)
    logger.info("REAL-TIME WORKFLOW PROGRESS")
    logger.info("="*50)
    logger.info(f"Current Step: {progress_summary['current_step']}")
    logger.info(f"Progress: {progress_summary['completed_steps']}/{progress_summary['total_steps']} steps completed")
    logger.info(f"Failed Steps: {progress_summary['failed_steps']}")
    logger.info(f"Pending Steps: {progress_summary['pending_steps']}")
    logger.info("\nLLM Call Statistics:")
    logger.info(f"Total Calls: {progress_summary['llm_calls']['total']}")
    logger.info(f"Completed: {progress_summary['llm_calls']['completed']}")
    logger.info(f"Failed: {progress_summary['llm_calls']['failed']}")
    logger.info(f"In Progress: {progress_summary['llm_calls']['in_progress']}")
    logger.info(f"\nTime Statistics:")
    logger.info(f"Elapsed Time: {progress_summary['elapsed_time']}")
    logger.info(f"Estimated Time Remaining: {progress_summary['estimated_time_remaining']}")
    logger.info("="*50 + "\n")

async def test_workflow():
    logger.info("Starting workflow test")
    # Get LLM service
    llm_service = get_llm_service()
    
    # Create a sample usecase with rules that matches the diagram
    logger.debug("Creating test usecase")
    usecase = UseCase(
        name="Clinical Note Analysis",
        steps=[
            Step(
                id="step1",
                description="Extract patient symptoms",
                prompt="List all symptoms mentioned in the clinical note. Return in JSON format with symptoms and severity.",
                dependencies=[],
                input=StepInput(content="Patient presents with fever and cough for 3 days. Temperature 101°F."),
                rules=StepRules(
                    validation=ValidationRules(
                        required_fields=["symptoms", "severity"],
                        format="JSON",
                        min_symptoms=1
                    ),
                    quality=QualityRules(
                        max_length=500,
                        language="medical"
                    )
                )
            ),
            Step(
                id="step2",
                description="Extract patient history",
                prompt="Extract patient medical history. Return in JSON format with conditions and treatments.",
                dependencies=[],
                parallel_group="group1",
                input=StepInput(content="Patient presents with fever and cough for 3 days. Temperature 101°F."),
                rules=StepRules(
                    validation=ValidationRules(
                        required_fields=["conditions", "treatments"],
                        format="JSON"
                    )
                )
            ),
            Step(
                id="step3",
                description="Generate final diagnosis",
                prompt="Based on symptoms and history, generate a diagnosis. Return in JSON format with diagnosis, confidence, ICD10 codes, and severity levels.",
                dependencies=["step1", "step2"],
                rules=StepRules(
                    validation=ValidationRules(
                        required_fields=["diagnosis", "confidence"],
                        format="JSON"
                    ),
                    quality=QualityRules(
                        min_confidence=0.7
                    ),
                    business=BusinessRules(
                        must_include=["ICD10_codes", "severity_levels"]
                    )
                )
            )
        ],
        clinical_note="Patient presents with fever and cough for 3 days. Temperature 101°F."
    )
    
    # Initialize and run workflow
    logger.info("Initializing workflow manager")
    workflow_manager = WorkflowManager(llm_service)
    try:
        logger.info("Executing workflow")
        logger.info("\nStarting workflow execution...")
        results = await workflow_manager.execute_workflow(usecase, progress_callback=monitor_progress)
        logger.success("Workflow Test Successful!")
        
        # Display results in the order of execution
        logger.info("\nWorkflow Results:")
        logger.info("="*50)
        
        # Step 1 (Sequential)
        if "step1" in results:
            logger.info("\nStep 1 (Extract Symptoms):")
            step1_result = results["step1"]
            logger.info(f"Status: {step1_result.validation_status}")
            logger.info(f"Output: {step1_result.content}")
        
        # Step 2 (Parallel)
        if "step2" in results:
            logger.info("\nStep 2 (Extract History - Parallel):")
            step2_result = results["step2"]
            logger.info(f"Status: {step2_result.validation_status}")
            logger.info(f"Output: {step2_result.content}")
        
        # Step 3 (Sequential, depends on 1 & 2)
        if "step3" in results:
            logger.info("\nStep 3 (Final Diagnosis):")
            step3_result = results["step3"]
            logger.info(f"Status: {step3_result.validation_status}")
            logger.info(f"Output: {step3_result.content}")
        
        logger.info("="*50)
        return True
    except Exception as e:
        logger.error(f"Workflow Test Failed: {str(e)}")
        return False

if __name__ == "__main__":
    async def run_tests():
        logger.info("Starting test suite")
        await test_workflow()
    
    asyncio.run(run_tests()) 