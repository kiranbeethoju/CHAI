from flask import Flask, request, jsonify, render_template
import requests
import json # Import json for error handling

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    api_key = data['api_key']
    endpoint = data['endpoint']
    model = data['model']
    version = data['version']
    temperature = data['temperature']
    user_messages = data['messages'] # These are from the chat history
    system_prompt = data.get('system_prompt', '') # Get system_prompt, default to empty

    headers = {
        "api-key": api_key,
        "Content-Type": "application/json"
    }

    # Construct messages payload including system prompt if provided
    messages_payload = []
    if system_prompt and system_prompt.strip():
        messages_payload.append({"role": "system", "content": system_prompt})
    messages_payload.extend(user_messages)

    payload = {
        "messages": messages_payload,
        "temperature": temperature,
        "max_tokens": 2000, # Increased for potentially longer system prompts and responses
        "top_p": 1,
        "frequency_penalty": 0,
        "presence_penalty": 0
    }
    # Ensure the model name in the URL is the deployment name, not necessarily the base model name
    # For Azure, 'model' from the frontend is typically the deployment name.
    url = f"{endpoint}/openai/deployments/{model}/chat/completions?api-version={version}"

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=60) # Increased timeout
        response.raise_for_status()  # Will raise an HTTPError for bad responses (4xx or 5xx)
        result = response.json()
        
        if 'choices' not in result or not result['choices']:
            # Handle cases where 'choices' might be missing or empty, though rare with raise_for_status
            return jsonify({"error": "Invalid response format from Azure OpenAI."}), 500
            
        reply = result['choices'][0]['message']['content']
        return jsonify({"reply": reply})
    except requests.exceptions.HTTPError as http_err:
        # Try to parse the error response from Azure for more details
        error_details = f"HTTP error occurred: {http_err}"
        try:
            error_content = http_err.response.json()
            if "error" in error_content and "message" in error_content["error"]:
                 error_details = f"Azure OpenAI Error: {error_content['error']['message']}"
            elif "error" in error_content:
                 error_details = f"Azure OpenAI Error: {json.dumps(error_content['error'])}"

        except ValueError: # If response is not JSON
            error_details = f"HTTP error occurred: {http_err}. Response: {http_err.response.text}"
        return jsonify({"error": error_details}), http_err.response.status_code
    except requests.exceptions.RequestException as req_err: # Catch other request exceptions like timeout, connection error
        return jsonify({"error": f"Request failed: {req_err}"}), 500
    except Exception as e:
        # General error catch
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(debug=True)