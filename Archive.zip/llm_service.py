from abc import ABC, abstractmethod
from typing import Dict, Any
from loguru import logger
import yaml
import os
from openai import OpenAI, AzureOpenAI
import json

class LLMService(ABC):
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        # Create a clean config for logging that doesn't include non-serializable objects
        log_config = {k: v for k, v in config.items() if k not in ['api_key', 'client']}
        logger.info(f"Initializing {self.__class__.__name__} with config: {json.dumps(log_config, indent=2)}")

    @abstractmethod
    async def generate_response(self, prompt: str, **kwargs) -> str:
        pass

    @abstractmethod
    async def validate_response(self, response: str, rules: Dict[str, Any]) -> bool:
        pass

class OpenAIService(LLMService):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        logger.debug("Setting up OpenAI client")
        self.client = config.get("client")
        self.model = config.get("model", "gpt-4")
        self.max_tokens = config.get("max_tokens", 1000)
        self.temperature = config.get("temperature", 0.7)
        logger.info(f"OpenAI service initialized with model: {self.model}")

    async def generate_response(self, prompt: str, **kwargs) -> str:
        logger.info(f"Generating response for prompt: {prompt[:100]}...")
        try:
            logger.debug(f"Making API call to OpenAI with model: {self.model}")
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a helpful AI assistant. Provide detailed stepwise explanations. When returning JSON, format it correctly within the response."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=kwargs.get("max_tokens", self.max_tokens),
                temperature=kwargs.get("temperature", self.temperature)
            )
            logger.info("Successfully received response from OpenAI")
            
            # Get the raw content
            raw_content = response.choices[0].message.content.strip()
            
            # If keep_raw is True, return the raw content
            if kwargs.get("keep_raw", False):
                return raw_content
            
            # Otherwise, extract just the JSON content if possible
            if raw_content.find('{') >= 0 and raw_content.rfind('}') >= 0:
                start = raw_content.find('{')
                end = raw_content.rfind('}') + 1
                content = raw_content[start:end]
                try:
                    # Validate it's proper JSON
                    json.loads(content)
                    return content
                except json.JSONDecodeError:
                    # If not valid JSON, return the raw content
                    return raw_content
            return raw_content
        except Exception as e:
            logger.error(f"Error generating response: {str(e)}", exc_info=True)
            raise

    async def validate_response(self, response: str, rules: Dict[str, Any]) -> bool:
        logger.info("Starting response validation")
        validation_prompt = f"""
        Validate the following response according to these rules:
        Response: {response}
        Rules: {rules}
        """
        try:
            logger.debug("Generating validation response")
            validation_result = await self.generate_response(validation_prompt)
            is_valid = "VALID" in validation_result.upper()
            logger.info(f"Validation result: {'Valid' if is_valid else 'Invalid'}")
            return is_valid
        except Exception as e:
            logger.error(f"Error validating response: {str(e)}", exc_info=True)
            return False

class DeepInfraService(OpenAIService):
    """
    DeepInfra service that uses the OpenAI compatible API
    """
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        logger.info(f"DeepInfra service initialized with model: {self.model}")
    
    # Inherits all methods from OpenAIService since the API is compatible

class AzureOpenAIService(LLMService):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        logger.debug("Setting up Azure OpenAI client")
        
        # Set up the Azure OpenAI client directly using the latest API pattern
        self.client = AzureOpenAI(
            api_key=config.get("api_key"),
            azure_endpoint=config.get("azure_endpoint"),
            api_version=config.get("api_version", "2024-02-01")
        )
        
        # Store other configuration
        self.deployment = config.get("deployment")
        self.max_tokens = config.get("max_tokens", 1000)
        self.temperature = config.get("temperature", 0.7)
        
        logger.info(f"Azure OpenAI service initialized with deployment: {self.deployment}, api_version: {self.client.api_version}")

    async def generate_response(self, prompt: str, **kwargs) -> str:
        logger.info(f"Generating response for prompt: {prompt[:100]}...")
        try:
            # Set up messages
            messages = [
                {"role": "system", "content": "You are a helpful AI assistant. Provide detailed stepwise explanations. When returning JSON, format it correctly within the response."},
                {"role": "user", "content": prompt}
            ]
            
            # Log request details for debugging
            logger.debug(f"Request parameters: deployment={self.deployment}, messages={messages}, max_tokens={kwargs.get('max_tokens', self.max_tokens)}, temperature={kwargs.get('temperature', self.temperature)}")
            
            # Use the client-based approach with model parameter (not engine)
            response = self.client.chat.completions.create(
                model=self.deployment,  # Using model parameter as in the official example
                messages=messages,
                max_tokens=kwargs.get("max_tokens", self.max_tokens),
                temperature=kwargs.get("temperature", self.temperature),
                frequency_penalty=kwargs.get("frequency_penalty", 0),
                presence_penalty=kwargs.get("presence_penalty", 0),
                top_p=kwargs.get("top_p", 1),
                stop=kwargs.get("stop", None)
            )
            
            logger.info("Successfully received response from Azure OpenAI")
            logger.debug(f"Response object: {response}")
            
            # Get the raw content from the response
            raw_content = response.choices[0].message.content.strip()
            
            # If keep_raw is True, return the raw content
            if kwargs.get("keep_raw", False):
                return raw_content
            
            # Otherwise, extract just the JSON content if possible
            if raw_content.find('{') >= 0 and raw_content.rfind('}') >= 0:
                start = raw_content.find('{')
                end = raw_content.rfind('}') + 1
                content = raw_content[start:end]
                try:
                    # Validate it's proper JSON
                    json.loads(content)
                    return content
                except json.JSONDecodeError:
                    # If not valid JSON, return the raw content
                    logger.warning("Response contains JSON-like content but is not valid JSON, returning raw content")
                    return raw_content
            return raw_content
        except Exception as e:
            logger.error(f"Error generating response from Azure OpenAI: {str(e)}", exc_info=True)
            raise

    async def validate_response(self, response: str, rules: Dict[str, Any]) -> bool:
        logger.info("Starting response validation")
        validation_prompt = f"""
        Validate the following response according to these rules:
        Response: {response}
        Rules: {rules}
        """
        try:
            logger.debug("Generating validation response")
            validation_result = await self.generate_response(validation_prompt)
            is_valid = "VALID" in validation_result.upper()
            logger.info(f"Validation result: {'Valid' if is_valid else 'Invalid'}")
            return is_valid
        except Exception as e:
            logger.error(f"Error validating response: {str(e)}", exc_info=True)
            return False

def load_config(config_path: str = "config.yml") -> Dict[str, Any]:
    logger.info(f"Loading configuration from: {config_path}")
    try:
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
        logger.info("Configuration loaded successfully")
        return config["llm_providers"]["openai"]
    except Exception as e:
        logger.error(f"Error loading configuration: {str(e)}", exc_info=True)
        raise

def get_llm_service() -> OpenAIService:
    config = load_config()
    logger.info("Initializing OpenAI service")
    return OpenAIService(config) 