from datetime import datetime, timedelta
from typing import Dict, Any, Optional
from loguru import logger

class WorkflowProgress:
    def __init__(self, total_steps: int):
        self.total_steps = total_steps
        self.completed_steps = 0
        self.failed_steps = 0
        self.pending_steps = total_steps
        self.current_step = None
        self.start_time = datetime.now()
        self.llm_calls = {
            "total": 0,
            "completed": 0,
            "failed": 0,
            "in_progress": 0
        }
        self.parallel_groups = {}
        self.step_status = {}
        logger.info(f"Initialized WorkflowProgress with {total_steps} total steps")

    def update_step_status(self, step_id: str, status: str, result: Optional[Any] = None):
        logger.debug(f"Updating step {step_id} status to {status}")
        self.step_status[step_id] = {
            "status": status,
            "result": result,
            "timestamp": datetime.now()
        }
        if status == "completed":
            self.completed_steps += 1
        elif status == "failed":
            self.failed_steps += 1
        self.pending_steps = self.total_steps - self.completed_steps - self.failed_steps
        logger.info(f"Step {step_id} {status}. Progress: {self.completed_steps}/{self.total_steps}")

    def update_llm_call(self, step_id: str, status: str):
        logger.debug(f"Updating LLM call for step {step_id} to {status}")
        if status == "started":
            self.llm_calls["in_progress"] += 1
            self.llm_calls["total"] += 1
        elif status == "completed":
            self.llm_calls["completed"] += 1
            self.llm_calls["in_progress"] -= 1
        elif status == "failed":
            self.llm_calls["failed"] += 1
            self.llm_calls["in_progress"] -= 1
        logger.info(f"LLM call {status} for step {step_id}. Total calls: {self.llm_calls['total']}")

    def get_progress_summary(self) -> Dict[str, Any]:
        elapsed_time = datetime.now() - self.start_time
        summary = {
            "total_steps": self.total_steps,
            "completed_steps": self.completed_steps,
            "failed_steps": self.failed_steps,
            "pending_steps": self.pending_steps,
            "llm_calls": self.llm_calls,
            "elapsed_time": str(elapsed_time),
            "estimated_time_remaining": self._estimate_time_remaining(),
            "current_step": self.current_step,
            "parallel_groups": self.parallel_groups,
            "step_status": self.step_status
        }
        logger.debug(f"Generated progress summary: {summary}")
        return summary

    def _estimate_time_remaining(self) -> str:
        if self.completed_steps == 0:
            return "Unknown"
        avg_time_per_step = (datetime.now() - self.start_time).total_seconds() / self.completed_steps
        remaining_seconds = avg_time_per_step * self.pending_steps
        return str(timedelta(seconds=int(remaining_seconds)))

    def is_complete(self) -> bool:
        return self.completed_steps + self.failed_steps == self.total_steps 