import requests
import json

# Sample data
payload = {
    "account": "123456",
    "selections": [
        {
            "id": "problems-low-1",
            "checked": True,
            "justification": "Patient has multiple minor problems: seasonal allergies and mild acne"
        },
        {
            "id": "data-low-2",
            "checked": True,
            "justification": "Reviewed previous lab results from last visit"
        },
        {
            "id": "risk-moderate-1",
            "checked": True,
            "justification": "Started patient on new blood pressure medication"
        }
    ]
}

# Send POST request
response = requests.post(
    'http://localhost:5000/api/set_selections',
    json=payload
)

# Print response
print("\nResponse Status:", response.status_code)
print("\nResponse JSON:")
print(json.dumps(response.json(), indent=2)) 