import os
from openai import AzureOpenAI
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize the Azure OpenAI client
client = AzureOpenAI(
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version="2024-02-15-preview",  # Latest stable version
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")
)

def get_completion(prompt: str) -> str:
    """
    Get completion using GPT-3.5 Turbo Instruct
    """
    try:
        completion = client.completions.create(
            model="gpt-35-turbo-instruct",  # Your deployment name
            prompt=prompt,
            max_tokens=1000,
            temperature=0.7
        )
        return completion.choices[0].text.strip()
    except Exception as e:
        print(f"Error in completion: {e}")
        return None

def get_chat_completion(messages: list) -> str:
    """
    Get chat completion using GPT-4
    """
    try:
        chat_completion = client.chat.completions.create(
            model="gpt-4",  # Your deployment name
            messages=messages,
            temperature=0.7,
            max_tokens=1000
        )
        return chat_completion.choices[0].message.content
    except Exception as e:
        print(f"Error in chat completion: {e}")
        return None

def get_embedding(text: str) -> list:
    """
    Get embeddings using text-embedding-3-large
    """
    try:
        embedding = client.embeddings.create(
            model="text-embedding-3-large",  # Your deployment name
            input=text
        )
        return embedding.data[0].embedding
    except Exception as e:
        print(f"Error in embedding: {e}")
        return None

# Example usage
if __name__ == "__main__":
    # Example completion
    prompt = "What is Azure OpenAI?"
    completion_result = get_completion(prompt)
    print("Completion:", completion_result)

    # Example chat completion
    messages = [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "What is Azure OpenAI?"}
    ]
    chat_result = get_chat_completion(messages)
    print("Chat:", chat_result)

    # Example embedding
    text = "Hello, world!"
    embedding_result = get_embedding(text)
    print("Embedding length:", len(embedding_result) if embedding_result else "Error") 